/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const e=o("TreePine",[["path",{d:"m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14",key:"1gxzww"}],["path",{d:"m17 8 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 8",key:"6dtzwm"}],["path",{d:"M12 2v20",key:"t6zm3l"}]]);export{e as default}