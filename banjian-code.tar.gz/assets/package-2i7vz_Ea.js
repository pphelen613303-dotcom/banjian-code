/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as a}from"./index-U8tdsdBT.js";const c=a("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"1e5c7x"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"1h5dwn"}],["path",{d:"M12 22V12",key:"yjxehl"}]]);export{c as default}