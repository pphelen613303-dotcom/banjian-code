/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as e}from"./index-U8tdsdBT.js";const o=e("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmhn2"}]]);export{o as default}