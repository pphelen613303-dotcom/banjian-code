/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const n=o("Wind",[["path",{d:"M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2",key:"1k57wa"}],["path",{d:"M9.6 4.6A2 2 0 1 1 11 8H2",key:"3y8anp"}],["path",{d:"M12.6 19.4A2 2 0 1 0 14 16H2",key:"1t6k8c"}]]);export{n as default}