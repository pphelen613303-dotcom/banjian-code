/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as t}from"./index-U8tdsdBT.js";const n=t("Mountain",[["path",{d:"m8 3 4 8 5-5 5 15H2L8 3z",key:"rdni2n"}]]);export{n as default}