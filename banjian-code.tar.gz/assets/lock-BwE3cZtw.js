/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const c=o("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4n1q"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"1gmqok"}]]);export{c as default}