/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const c=o("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);export{c as default}