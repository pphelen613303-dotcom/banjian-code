/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const c=o("Truck",[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"172yrx"}],["path",{d:"M15 18H9",key:"1oypy3"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"18tj1s"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19u7z1"}]]);export{c as default}