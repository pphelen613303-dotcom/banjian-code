/**
 * @license lucide-react v0.427.0 - ISC
 */
import{c as o}from"./index-U8tdsdBT.js";const c=o("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"1aq2hr"}],["path",{d:"M21 3v5h-5",key:"1q7rc2"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"6nz6fk"}],["path",{d:"M8 16H3v5",key:"18abou"}]]);export{c as default}