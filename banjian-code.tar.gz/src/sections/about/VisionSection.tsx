import { useRef } from 'react';
import { Link } from 'react-router';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function VisionSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const h2Ref = useRef<HTMLHeadingElement>(null);
  const visionRef = useRef<HTMLDivElement>(null);
  const enRef = useRef<HTMLParagraphElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        h2Ref.current,
        { opacity: 0, y: 25 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        visionRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.5,
          delay: 0.4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: visionRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        enRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.4,
          delay: 0.3,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: enRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        lineRef.current,
        { width: 0 },
        {
          width: 60,
          duration: 0.4,
          delay: 0.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: lineRef.current,
            start: 'top 95%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        ctaRef.current,
        { opacity: 0, y: 15 },
        {
          opacity: 1,
          y: 0,
          duration: 0.3,
          delay: 0.3,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: ctaRef.current,
            start: 'top 95%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="w-full bg-[#3D3229] py-16 md:py-24"
    >
      <div className="max-w-[680px] mx-auto px-4 xs:px-6 md:px-8 text-center">
        {/* Title */}
        <h2
          ref={h2Ref}
          className="font-serif-zh text-[#FAF9F7] mb-8"
          style={{
            fontSize: 'clamp(1.75rem, 2.5vw, 2.5rem)',
            lineHeight: 1.25,
            letterSpacing: '0.015em',
          }}
        >
          东方生命观察系统
        </h2>

        {/* Vision Statement */}
        <div ref={visionRef} className="space-y-4 mb-8">
          <p className="text-base font-sans-zh text-[rgba(250,249,247,0.75)] leading-[1.8]">
            半见不只是茶。它是一个以茶为媒介的生命观察系统——从古茶树的生长，到制茶师的手艺，到你身体的感受，再到下一季茶的延续，每一环都被记录、被确认、被看见。
          </p>
          <p className="text-base font-sans-zh text-[rgba(250,249,247,0.75)] leading-[1.8]">
            我们相信，当现代人重新学会等待、停留、恢复和沉淀，就能在快节奏的生活中找回对时间、身体、生态和劳动的真实感知。这是东方智慧对现代生活的回应。
          </p>
        </div>

        {/* English subtitle */}
        <p
          ref={enRef}
          className="text-sm font-sans-zh text-[rgba(250,249,247,0.5)] tracking-[0.03em] mb-8"
        >
          Banjian is a tea-based living archive for observing time, body, ecology,
          and craft.
        </p>

        {/* Decorative line */}
        <div className="flex justify-center mb-8">
          <div
            ref={lineRef}
            className="h-[1px] bg-[rgba(212,168,83,0.3)]"
            style={{ width: 0 }}
          />
        </div>

        {/* CTA */}
        <div ref={ctaRef}>
          <Link
            to="/observe"
            className="inline-flex items-center justify-center px-8 py-3.5 bg-[#D4A853] text-[#3D3229] text-sm font-sans-zh font-medium rounded hover:bg-[#C49A4A] active:scale-[0.98] transition-all duration-200 w-full md:w-auto"
          >
            开始你的观察
          </Link>
        </div>
      </div>
    </section>
  );
}
