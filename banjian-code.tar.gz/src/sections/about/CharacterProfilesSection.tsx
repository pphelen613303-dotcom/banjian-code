import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface CharacterProfile {
  name: string;
  role: string;
  archive?: string;
  responsibility: string;
  description: string;
  confirmed: boolean;
}

const characters: CharacterProfile[] = [
  {
    name: '严庄',
    role: '监匠确认',
    archive: '30年 / 晒青白茶红茶S级',
    responsibility: '确认整批茶的工艺判断与品质边界',
    description:
      '严庄是半见品质系统的最后守门人。30年的制茶经验让他能够在茶叶制作的每一个关键节点做出准确判断。他不是"审评师"，而是"监匠"——他的确认意味着这杯茶的工艺边界已被充分理解。',
    confirmed: true,
  },
];

// Placeholder for future characters
const placeholders = [
  { role: '采摘确认', label: '待品牌方确认' },
  { role: '工艺确认', label: '待品牌方确认' },
  { role: '记录确认', label: '待品牌方确认' },
  { role: '品牌确认', label: '待品牌方确认' },
];

export default function CharacterProfilesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      if (cardRef.current) {
        const eyebrow = cardRef.current.querySelector('.role-eyebrow');
        const name = cardRef.current.querySelector('.char-name');
        const content = cardRef.current.querySelector('.char-content');

        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: cardRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        });

        tl.fromTo(
          cardRef.current,
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' }
        )
          .fromTo(eyebrow, { opacity: 0 }, { opacity: 1, duration: 0.2 }, 0.2)
          .fromTo(name, { opacity: 0 }, { opacity: 1, duration: 0.2 }, 0.3)
          .fromTo(content, { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.4);
      }

      // Placeholder cards subtle pulse
      const placeholders = sectionRef.current?.querySelectorAll('.placeholder-card');
      if (placeholders) {
        placeholders.forEach((el) => {
          gsap.to(el, {
            borderColor: 'rgba(61,50,41,0.15)',
            duration: 1.5,
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut',
          });
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="w-full bg-[#F5F3EF] py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div ref={headerRef} className="mb-6 md:mb-8 text-center">
          <h2
            className="font-serif-zh text-[#3D3229] mb-4"
            style={{
              fontSize: 'clamp(1.75rem, 2.5vw, 2.5rem)',
              lineHeight: 1.25,
              letterSpacing: '0.015em',
            }}
          >
            谁在守护这杯茶
          </h2>
          <p className="text-base font-sans-zh text-[rgba(61,50,41,0.7)] leading-relaxed">
            每一泡茶背后，都有一群人的确认和守护。
          </p>
        </div>

        {/* Character Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Confirmed character card */}
          {characters.map((char) => (
            <div
              key={char.name}
              ref={cardRef}
              className="border-t border-archive-brown-6 py-6 md:py-5 max-w-[480px] mx-auto md:mx-0 transition-all duration-200 hover:border-[rgba(212,168,83,0.3)] hover:shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
            >
              {/* Role eyebrow */}
              <div className="role-eyebrow text-xs font-sans-zh font-medium uppercase tracking-[0.15em] text-[#D4A853] mb-3">
                {char.role}
              </div>

              {/* Name */}
              <h3
                className="char-name font-serif-zh font-semibold text-[#3D3229] mb-2"
                style={{ fontSize: 'clamp(1.25rem, 1.5vw, 1.5rem)', lineHeight: 1.3 }}
              >
                {char.name}
              </h3>

              {/* Archive */}
              {char.archive && (
                <p className="text-xs font-sans-zh text-[rgba(61,50,41,0.5)] mb-4">
                  {char.archive}
                </p>
              )}

              <div className="char-content">
                {/* Responsibility quote */}
                <p className="text-sm font-sans-zh text-[#3D3229] leading-relaxed mb-4 italic border-l-2 border-[#D4A853] pl-3">
                  "{char.responsibility}"
                </p>

                {/* Description */}
                <p className="text-sm font-sans-zh text-[rgba(61,50,41,0.7)] leading-relaxed">
                  {char.description}
                </p>
              </div>
            </div>
          ))}

          {/* Placeholder cards */}
          {placeholders.map((ph) => (
            <div
              key={ph.role}
              className="placeholder-card border-t border-dashed border-archive-brown-12 py-6 md:py-5 flex flex-col items-center justify-center text-center min-h-[200px] transition-all duration-300"
            >
              <span className="text-xs font-sans-zh font-medium uppercase tracking-[0.15em] text-[rgba(61,50,41,0.4)] mb-2">
                {ph.role}
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-sans-zh border border-dashed border-[#999999] text-[#999999]">
                {ph.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
