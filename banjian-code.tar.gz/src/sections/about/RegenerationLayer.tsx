import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { bysValueFlow, bd001ValueFlow, type ValueFlowItem } from '@/data/coCreationData';

gsap.registerPlugin(ScrollTrigger);

// ─── SVG Pie Chart Component ───
function PieChart({ data, total }: { data: ValueFlowItem[]; total: number }) {
  const [hovered, setHovered] = useState<number | null>(null);
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="flex flex-col md:flex-row items-center gap-8">
      <div className="relative w-[200px] h-[200px] shrink-0">
        <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
          {data.map((item, i) => {
            const dashLength = (item.percent / 100) * circumference;
            const dashOffset = -offset;
            offset += dashLength;
            return (
              <circle
                key={i}
                cx="100"
                cy="100"
                r={radius}
                fill="none"
                stroke={item.color}
                strokeWidth="28"
                strokeDasharray={`${dashLength} ${circumference - dashLength}`}
                strokeDashoffset={dashOffset}
                className="transition-all duration-300 cursor-pointer"
                style={{
                  opacity: hovered === null ? 1 : hovered === i ? 1 : 0.4,
                  filter: hovered === i ? 'brightness(1.1)' : 'none',
                }}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
              />
            );
          })}
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-xs font-sans-zh text-archive-brown-50">每泡</span>
          <span className="text-2xl font-mono-data font-bold text-archive-brown">¥{total}</span>
        </div>
      </div>

      {/* Legend */}
      <div className="flex-1 grid grid-cols-2 gap-x-6 gap-y-3">
        {data.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-2 cursor-pointer transition-opacity duration-200"
            style={{ opacity: hovered === null ? 1 : hovered === i ? 1 : 0.4 }}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
            <div>
              <span className="text-xs font-sans-zh text-archive-brown">{item.label}</span>
              <span className="text-[10px] font-mono-data text-archive-brown-50 ml-1">{item.percent}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main ───

export default function RegenerationLayer() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.rl-header > *', { opacity: 0, y: 24 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.rl-header', start: 'top 85%' },
    });
    gsap.fromTo('.rl-person', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.12, ease: 'power2.out',
      scrollTrigger: { trigger: '.rl-people', start: 'top 85%' },
    });
    gsap.fromTo('.rl-pie', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: '.rl-pie', start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="w-full py-16 md:py-24" style={{ backgroundColor: '#FAF9F7' }}>
      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="rl-header text-center mb-12">
          <SectionEyebrow text="REGENERATION SYSTEM" />
          <h3 className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight mt-4 mb-4">
            不是分钱系统，是让系统有能力生产下一泡茶
          </h3>
        </div>

        {/* Divider */}
        <div className="w-full h-[1px] bg-archive-brown-12 mb-12" />

        {/* Value Flow */}
        <div className="rl-pie">
          <p className="text-center text-sm font-serif-zh text-archive-brown mb-6">
            一泡茶的钱，去了该去的地方
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            <div>
              <p className="text-xs font-sans-zh text-archive-brown-50 mb-3 text-center">
                白莺初霁 BYS001
              </p>
              <PieChart data={bysValueFlow} total={36.9} />
            </div>
            <div>
              <p className="text-xs font-sans-zh text-archive-brown-50 mb-3 text-center">
                石界岩手 BD001
              </p>
              <PieChart data={bd001ValueFlow} total={29.9} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
