import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { productionNodes } from '@/data/coCreationData';
import { TreePine, Hand, Flame, Package, Lock, Eye, RefreshCw, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  TreePine, Hand, Flame, Package, Lock, Eye, RefreshCw,
};

export default function ProductionLayer() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.pl-header > *', { opacity: 0, y: 24 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.pl-header', start: 'top 85%' },
    });
    gsap.fromTo('.pl-node', { opacity: 0, scale: 0.8 }, {
      opacity: 1, scale: 1, duration: 0.5, stagger: 0.1, ease: 'back.out(1.5)',
      scrollTrigger: { trigger: '.pl-flow', start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="w-full py-16 md:py-24" style={{ backgroundColor: '#F5F3EF' }}>
      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <div className="pl-header text-center mb-12">
          <SectionEyebrow text="PRODUCTION COMPLETION" />
          <h3 className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight mt-4">
            茶如何被做出来
          </h3>
          <p className="text-sm font-sans-zh text-archive-brown-60 mt-3 max-w-lg mx-auto">
            从山场确认到数字存证，7个被记录的节点
          </p>
        </div>

        {/* Flow — desktop: horizontal, mobile: wrap */}
        <div className="pl-flow flex flex-wrap items-center justify-center gap-2 md:gap-0">
          {productionNodes.map((node, i) => {
            const Icon = iconMap[node.icon] || TreePine;
            return (
              <div key={node.number} className="flex items-center">
                <div className="pl-node flex flex-col items-center text-center px-3 py-4">
                  <div className="w-14 h-14 md:w-16 md:h-16 rounded-full border-2 border-tea-gold/60 flex items-center justify-center bg-warm-white mb-2">
                    <Icon size={22} className="text-tea-gold" />
                  </div>
                  <span className="text-[10px] font-mono-data text-archive-brown-40">{node.number}</span>
                  <span className="text-xs font-sans-zh font-medium text-archive-brown mt-0.5">{node.title}</span>
                </div>
                {i < productionNodes.length - 1 && (
                  <ArrowRight size={16} className="text-archive-brown-20 hidden md:block mx-1 shrink-0" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
