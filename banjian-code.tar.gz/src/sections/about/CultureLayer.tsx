import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { cultureItems } from '@/data/coCreationData';
import { Flame, Users, TreePine, BookOpen } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  Flame, Users, TreePine, BookOpen,
};

export default function CultureLayer() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.cl-header > *', { opacity: 0, y: 24 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.cl-header', start: 'top 85%' },
    });
    gsap.fromTo('.cl-item', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.cl-grid', start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="w-full py-16 md:py-24" style={{ backgroundColor: '#F5F3EF' }}>
      <div className="max-w-5xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <div className="cl-header text-center mb-12">
          <SectionEyebrow text="CULTURAL GROWTH" />
          <h3 className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight mt-4">
            系统最终留下什么
          </h3>
        </div>

        <div className="cl-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
          {cultureItems.map((item) => {
            const Icon = iconMap[item.icon] || Flame;
            return (
              <div key={item.title} className="cl-item flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: 'rgba(61,50,41,0.06)' }}>
                  <Icon size={28} className="text-archive-brown" />
                </div>
                <h4 className="text-base font-serif-zh font-medium text-archive-brown mb-2">
                  {item.title}
                </h4>
                <p className="text-sm font-sans-zh text-archive-brown-60 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
