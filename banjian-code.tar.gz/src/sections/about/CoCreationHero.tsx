import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';

gsap.registerPlugin(ScrollTrigger);

export default function CoCreationHero() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.cch-content > *', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.7, stagger: 0.12, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="relative w-full overflow-hidden" style={{ backgroundColor: '#3D3229' }}>
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'url(/images/banjian-new/brand/mountain-texture-bys.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }} />
      <div className="relative z-10 max-w-4xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 py-20 md:py-28 text-center">
        <div className="cch-content">
          <SectionEyebrow text="CO-CREATION SYSTEM" className="text-warm-white/50 mb-4" />
          <h2 className="text-[clamp(2rem,5vw,3.5rem)] font-serif-zh text-warm-white leading-tight mb-6">
            这不是买卖，是共创
          </h2>
          <p className="text-base md:text-lg font-sans-zh text-warm-white/70 max-w-2xl mx-auto leading-relaxed">
            一杯茶从山场到你手中，经过7个被记录的节点、5个人的共同确认。
            共创不是分钱系统，而是让生产关系、技艺传承和生态延续持续运转的系统。
          </p>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-20" style={{ background: 'linear-gradient(to bottom, transparent, #F5F3EF)' }} />
    </div>
  );
}
