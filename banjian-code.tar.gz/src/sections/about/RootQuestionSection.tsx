import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function RootQuestionSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const h2Ref = useRef<HTMLHeadingElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);
  const reflectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        h2Ref.current,
        { opacity: 0, y: 25 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        dividerRef.current,
        { width: 0 },
        {
          width: 120,
          duration: 0.5,
          delay: 0.3,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: dividerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        reflectionRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.5,
          delay: 0.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: reflectionRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="w-full bg-[#FAF9F7] py-16 md:py-24"
    >
      <div className="max-w-[640px] mx-auto px-4 xs:px-6 md:px-8 text-center">
        <h2
          ref={h2Ref}
          className="font-serif-zh text-[#3D3229] leading-[1.4] tracking-[0.015em]"
          style={{
            fontSize: 'clamp(1.25rem, 3vw, 1.75rem)',
          }}
        >
          为什么现代人越来越难等待、停留、恢复、沉淀和感受细微变化？
        </h2>

        {/* Divider */}
        <div className="flex justify-center my-12">
          <div
            ref={dividerRef}
            className="h-[1px] bg-[rgba(61,50,41,0.1)]"
            style={{ width: 0, maxWidth: 120 }}
          />
        </div>

        {/* Reflection text */}
        <div ref={reflectionRef} className="space-y-4">
          <p className="text-base font-sans-zh text-[rgba(61,50,41,0.7)] leading-[1.75]">
            我们在加速中失去了对时间的体感。越快，越难觉察细微的变化。越追求效率，越无法容忍空白。
          </p>
          <p className="text-base font-sans-zh text-[rgba(61,50,41,0.7)] leading-[1.75]">
            但茶不会加速。它需要水沸腾的时间，需要叶子慢慢展开的空间，需要身体安静下来才能被感受到的变化。
          </p>
          <p className="text-base font-sans-zh text-[rgba(61,50,41,0.7)] leading-[1.75]">
            半见想用一杯茶，作为重新进入慢速体验的入口。不是逃避，而是恢复——恢复观察、等待和感受的能力。
          </p>
        </div>
      </div>
    </section>
  );
}
