import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function EvidenceCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.ecta-content > *', { opacity: 0, y: 24 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="w-full py-16 md:py-20" style={{ backgroundColor: '#3D3229' }}>
      <div className="max-w-3xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 text-center">
        <div className="ecta-content">
          <p className="text-lg md:text-xl font-serif-zh text-warm-white leading-relaxed mb-6">
            每一泡茶都有完整的生命档案
          </p>
          <Link
            to="/origin"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full text-sm font-medium font-sans-zh tracking-[0.05em] transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            style={{ backgroundColor: '#D4A853', color: '#3D3229' }}
          >
            查看七段共创时间轴
            <ArrowRight size={16} strokeWidth={2} />
          </Link>
        </div>
      </div>
    </div>
  );
}
