import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function AboutHeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const h1Ref = useRef<HTMLHeadingElement>(null);
  const enRef = useRef<HTMLParagraphElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        defaults: { ease: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' },
      });

      tl.fromTo(
        h1Ref.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.8 }
      ).fromTo(
        enRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.5 },
        0.5
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="w-full bg-[#3D3229] flex items-center justify-center"
      style={{ minHeight: '50vh' }}
    >
      <div className="max-w-[720px] mx-auto px-4 xs:px-6 md:px-8 py-12 md:py-16 text-center">
        <h1
          ref={h1Ref}
          className="font-serif-zh text-[#FAF9F7] leading-[1.5] tracking-[0.02em]"
          style={{
            fontSize: 'clamp(1.5rem, 4vw, 2.25rem)',
          }}
        >
          半见用一杯茶，帮助现代人重新建立对时间、身体、生态和劳动关系的观察能力。
        </h1>

        <p
          ref={enRef}
          className="text-sm font-sans-zh text-[rgba(250,249,247,0.5)] tracking-[0.05em] mt-5"
        >
          Banjian is a tea-based living archive for observing time, body, ecology,
          and craft.
        </p>
      </div>
    </section>
  );
}
