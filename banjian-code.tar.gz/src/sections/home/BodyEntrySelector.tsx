import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { ArrowRight, Mountain } from 'lucide-react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { bysProduct, bd001Product } from '@/data/archive';

gsap.registerPlugin(ScrollTrigger);

// ───────────────────────────────────────────────
// Types
// ───────────────────────────────────────────────

interface BodyKeyword {
  label: string;
  title: string;
  description: string;
}

// ───────────────────────────────────────────────
// Data: Body state keywords
// ───────────────────────────────────────────────

const bysKeywords: BodyKeyword[] = [
  { label: '轻', title: '身体安静 · 呼吸变长', description: '身体安静·呼吸变长' },
  { label: '缓', title: '时间变慢 · 节奏柔和', description: '时间变慢·节奏柔和' },
  { label: '透', title: '思绪放松 · 内在清明', description: '思绪放松·内在清明' },
];

const bd001Keywords: BodyKeyword[] = [
  { label: '稳', title: '入口有支撑 · 身体落地', description: '入口有支撑·身体落地' },
  { label: '压', title: '情绪安定 · 力量聚拢', description: '情绪安定·力量聚拢' },
  { label: '回', title: '回甘持久 · 空间舒展开', description: '回甘持久·空间舒展开' },
];

// ───────────────────────────────────────────────
// Sub-component: ProductEntryPanel
// ───────────────────────────────────────────────

interface ProductEntryPanelProps {
  product: typeof bysProduct;
  linkTo: string;
  variant: 'light' | 'dark';
  productImage: string;
}

function ProductEntryPanel({
  product,
  linkTo,
  variant,
  productImage,
}: ProductEntryPanelProps) {
  const isLight = variant === 'light';

  return (
    <div className="relative min-h-[520px] xs:min-h-[580px] md:min-h-[680px] lg:min-h-[720px] overflow-hidden">
      {/* Background: full-bleed product image */}
      <img
        src={productImage}
        alt={`${product.name}产品场景`}
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
       decoding="async"/>

      {/* Natural radial mask — only top-left corner for text readability */}
      <div
        className="absolute inset-0 z-[1]"
        style={{
          background: isLight
            ? 'radial-gradient(ellipse 75% 60% at 15% 20%, rgba(250,249,247,0.93) 0%, rgba(250,249,247,0.6) 35%, transparent 65%)'
            : 'radial-gradient(ellipse 75% 60% at 15% 20%, rgba(45,38,32,0.9) 0%, rgba(45,38,32,0.5) 35%, transparent 65%)',
        }}
      />

      {/* Subtle edge feather at top to blend with section bg */}
      <div
        className={`absolute inset-x-0 top-0 h-24 z-[1] ${
          isLight
            ? 'bg-gradient-to-b from-warm-white/80 to-transparent'
            : 'bg-gradient-to-b from-archive-brown/60 to-transparent'
        }`}
      />

      {/* Product info — top left, over the masked area */}
      <div className="relative z-10 p-6 md:p-10 lg:p-12 max-w-[65%] md:max-w-[55%]">
        {/* Product Number */}
        <span className="block text-xs font-medium font-sans-zh tracking-[0.15em] mb-3 uppercase text-tea-gold">
          {product.id}
        </span>

        {/* Product Name */}
        <h3
          className={`text-2xl md:text-3xl font-serif-zh mb-3 ${
            isLight ? 'text-archive-brown' : 'text-warm-white'
          }`}
        >
          {product.name}
        </h3>

        {/* Life Structure Tag */}
        <span
          className={`inline-block px-3 py-1 text-xs font-sans-zh rounded mb-4 backdrop-blur-sm ${
            isLight
              ? 'bg-deep-green/10 text-deep-green border border-deep-green/12'
              : 'bg-warm-white/15 text-warm-white/90 border border-warm-white/15'
          }`}
        >
          {product.lifeStructureTag}
        </span>

        {/* Core Sentence */}
        <p
          className={`text-base font-serif-zh italic mb-6 leading-relaxed ${
            isLight ? 'text-archive-brown/75' : 'text-warm-white/80'
          }`}
        >
          {isLight ? '轻盈入身，给时间一点空间。' : '扎根入身，给身体一些支撑。'}
        </p>

        {/* CTA */}
        <Link
          to={linkTo}
          className={`inline-flex items-center gap-2 text-sm font-sans-zh transition-colors duration-200 group/cta ${
            isLight
              ? 'text-archive-brown hover:text-tea-gold'
              : 'text-warm-white hover:text-tea-gold'
          }`}
        >
          进入此路径
          <ArrowRight
            size={16}
            strokeWidth={1.5}
            className="transition-transform duration-200 group-hover/cta:translate-x-1"
          />
        </Link>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────
// Sub-component: KeywordCircle
// ───────────────────────────────────────────────

interface KeywordCircleProps {
  keyword: BodyKeyword;
  variant: 'light' | 'dark';
}

function KeywordCircle({ keyword, variant }: KeywordCircleProps) {
  const isLight = variant === 'light';

  return (
    <div className="bes-keyword-circle flex flex-col items-center text-center">
      {/* Circle with keyword */}
      <div
        className={`w-16 h-16 md:w-20 md:h-20 rounded-full border-2 flex items-center justify-center mb-3 ${
          isLight
            ? 'border-archive-brown-12 bg-warm-white'
            : 'border-archive-brown-30 bg-archive-brown-12'
        }`}
      >
        <span className="text-xl md:text-2xl font-serif-zh text-archive-brown">
          {keyword.label}
        </span>
      </div>
      {/* Description */}
      <p className="text-xs font-sans-zh text-archive-brown-60 leading-relaxed whitespace-pre-line">
        {keyword.description.split('·').join('\n')}
      </p>
    </div>
  );
}

// ───────────────────────────────────────────────
// Sub-component: BodyStateColumn (merged with CTA)
// ───────────────────────────────────────────────

interface BodyStateColumnProps {
  product: typeof bysProduct;
  keywords: BodyKeyword[];
  scenario: string;
  variant: 'light' | 'dark';
  linkTo: string;
  buttonClass: string;
}

function BodyStateColumn({
  product,
  keywords,
  scenario,
  variant,
  linkTo,
  buttonClass,
}: BodyStateColumnProps) {
  const isLight = variant === 'light';

  return (
    <div className="flex flex-col items-center text-center">
      {/* Product tag */}
      <span
        className={`inline-block px-3 py-1 text-xs font-sans-zh rounded mb-3 ${
          isLight
            ? 'bg-deep-green/10 text-deep-green'
            : 'bg-archive-brown/10 text-archive-brown'
        }`}
      >
        {product.lifeStructureTag}
      </span>

      {/* Product name */}
      <h4 className="text-xl md:text-2xl font-serif-zh text-archive-brown mb-6 md:mb-8">
        {product.name}
      </h4>

      {/* Three keyword circles */}
      <div className="flex items-start justify-center gap-6 md:gap-10 mb-6 md:mb-8">
        {keywords.map((kw) => (
          <KeywordCircle key={kw.label} keyword={kw} variant={variant} />
        ))}
      </div>

      {/* Scenario text */}
      <p className="bes-scenario-text text-sm font-sans-zh text-archive-brown-60 leading-relaxed max-w-xs mb-8">
        {scenario}
      </p>

      {/* CTA Button — merged from Layer 3 */}
      <Link
        to={linkTo}
        className={`w-full sm:w-auto inline-flex items-center justify-center px-10 py-4 text-sm font-medium font-sans-zh rounded hover:opacity-90 transition-all duration-200 active:scale-[0.98] tracking-[0.05em] ${buttonClass}`}
      >
        进入 {product.name}
      </Link>
    </div>
  );
}

// ───────────────────────────────────────────────
// Main Component: BodyEntrySelector
// ───────────────────────────────────────────────

export default function BodyEntrySelector() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      if (!sectionRef.current) return;
      const ctx = gsap.context(() => {
        // ── Layer 0: Header ──────────────────────
        gsap.fromTo(
          '.bes-header > *',
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: '.bes-header',
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );

        // ── Layer 1: ProductEntry (Desktop) ──────
        const desktopPanels = gsap.utils.toArray<HTMLElement>('.bes-panel-left, .bes-panel-right');
        desktopPanels.forEach((panel, i) => {
          gsap.fromTo(
            panel,
            { opacity: 0, x: i === 0 ? -60 : 60 },
            {
              opacity: 1,
              x: 0,
              duration: 0.8,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: '.bes-split-screen',
                start: 'top 80%',
                toggleActions: 'play none none none',
              },
            }
          );
        });

        // ── Layer 1: ProductEntry (Mobile) ───────
        const mobilePanels = gsap.utils.toArray<HTMLElement>('.bes-product-panel-mobile');
        mobilePanels.forEach((panel, i) => {
          gsap.fromTo(
            panel,
            { opacity: 0, y: 40 },
            {
              opacity: 1,
              y: 0,
              duration: 0.8,
              delay: i * 0.2,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: panel,
                start: 'top 80%',
                toggleActions: 'play none none none',
              },
            }
          );
        });

        // ── Layer 2: BodyStatePreview ────────────
        gsap.fromTo(
          '.bes-body-state-header',
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: '.bes-body-state',
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );

        // Keyword circles pop in with stagger
        gsap.fromTo(
          '.bes-keyword-circle',
          { opacity: 0, scale: 0.5 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.5,
            stagger: 0.1,
            ease: 'back.out(1.8)',
            scrollTrigger: {
              trigger: '.bes-keyword-circles-container',
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );

        // Scenario text + CTA buttons fade in
        gsap.fromTo(
          '.bes-scenario-text, .bes-state-cta',
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: '.bes-scenario-text',
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        );
      }, sectionRef);

      return () => ctx.revert();
    },
    { scope: sectionRef }
  );

  return (
    <section ref={sectionRef} className="bg-warm-white">
      {/* ═══════════════════════════════════════════
          Layer 0 — Header
      ═══════════════════════════════════════════ */}
      <div className="bes-header py-16 md:py-24 text-center px-4 xs:px-6 md:px-8 lg:px-16">
        <SectionEyebrow text="TWO ENTRY POINTS" />
        <h2 className="text-[clamp(1.5rem,3.5vw,2.75rem)] font-serif-zh font-normal leading-[1.25] tracking-[0.015em] text-archive-brown mb-5">
          两款茶，是两种身体入口。
        </h2>
        <p className="text-base font-sans-zh text-archive-brown-60 max-w-xl mx-auto leading-relaxed">
          不是选择一款茶，而是选择当下的身体状态。
        </p>
      </div>

      {/* ═══════════════════════════════════════════
          Layer 1+2 — Product Entry + Body State
          Desktop: split-screen (left/right), then state preview
          Mobile: product group order (BYS img→state→BD001 img→state)
      ═══════════════════════════════════════════ */}

      {/* Desktop: product entry split-screen (unchanged) */}
      <div className="hidden md:grid md:grid-cols-2 bes-split-screen">
        <div className="bes-panel-left opacity-0">
          <ProductEntryPanel
            product={bysProduct}
            linkTo="/product?product=bys"
            variant="light"
            productImage="/images/banjian-new/home/entry-bys.jpg"
          />
        </div>
        <div className="bes-panel-right opacity-0">
          <ProductEntryPanel
            product={bd001Product}
            linkTo="/product?product=bd001"
            variant="dark"
            productImage="/images/banjian-new/home/entry-bd001.jpg"
          />
        </div>
      </div>

      {/* Desktop: body state preview (unchanged) */}
      <div className="hidden md:block bes-body-state py-16 md:py-24 bg-warm-cream px-4 xs:px-6 md:px-8 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="bes-body-state-header text-center mb-12 md:mb-16">
            <SectionEyebrow text="BODY PREVIEW" />
            <h3 className="text-[clamp(1.25rem,2.5vw,2rem)] font-serif-zh font-normal text-archive-brown mb-4">
              你的身体会更喜欢哪一种状态？
            </h3>
            <p className="text-sm font-sans-zh text-archive-brown-60 leading-relaxed">
              顺着身体的需要，进入属于你的茶之路径。
            </p>
          </div>
          <div className="grid grid-cols-[1fr_auto_1fr] gap-8 items-start">
            <div className="bes-keyword-circles-container bes-state-cta">
              <BodyStateColumn
                product={bysProduct}
                keywords={bysKeywords}
                scenario="适合清晨，或需要轻盈与灵动的时刻。"
                variant="light"
                linkTo="/product?product=bys"
                buttonClass="bg-deep-green text-warm-white"
              />
            </div>
            <div className="flex flex-col items-center justify-center h-full pt-16">
              <div className="w-[1px] h-24 bg-archive-brown-12 mb-4" />
              <Mountain size={28} strokeWidth={1} className="text-archive-brown-30" />
              <div className="w-[1px] h-24 bg-archive-brown-12 mt-4" />
            </div>
            <div className="bes-keyword-circles-container bes-state-cta">
              <BodyStateColumn
                product={bd001Product}
                keywords={bd001Keywords}
                scenario="适合当下，或需要稳定与支撑的时刻。"
                variant="dark"
                linkTo="/product?product=bd001"
                buttonClass="bg-archive-brown text-warm-white"
              />
            </div>
          </div>
          <div className="text-center mt-16">
            <Link
              to="/product"
              className="inline-flex items-center gap-2 text-sm font-sans-zh text-archive-brown-60 hover:text-tea-gold transition-colors duration-200 group/link"
            >
              了解更多两款茶的理念与差异
              <ArrowRight size={16} strokeWidth={1.5} className="transition-transform duration-200 group-hover/link:translate-x-1" />
            </Link>
          </div>
        </div>
      </div>

      {/* Mobile: product groups with correct reading order */}
      <div className="flex flex-col md:hidden">
        {/* BYS group: img → state */}
        <div className="bes-product-panel-mobile opacity-0 order-1">
          <ProductEntryPanel
            product={bysProduct}
            linkTo="/product?product=bys"
            variant="light"
            productImage="/images/banjian-new/home/entry-bys.jpg"
          />
        </div>
        <div className="order-2 bg-warm-cream py-12 px-6 bes-keyword-circles-container">
          <BodyStateColumn
            product={bysProduct}
            keywords={bysKeywords}
            scenario="适合清晨，或需要轻盈与灵动的时刻。"
            variant="light"
            linkTo="/product?product=bys"
            buttonClass="bg-deep-green text-warm-white"
          />
        </div>

        {/* BD001 group: img → state */}
        <div className="bes-product-panel-mobile opacity-0 order-3">
          <ProductEntryPanel
            product={bd001Product}
            linkTo="/product?product=bd001"
            variant="dark"
            productImage="/images/banjian-new/home/entry-bd001.jpg"
          />
        </div>
        <div className="order-4 bg-warm-cream py-12 px-6 bes-keyword-circles-container">
          <BodyStateColumn
            product={bd001Product}
            keywords={bd001Keywords}
            scenario="适合当下，或需要稳定与支撑的时刻。"
            variant="dark"
            linkTo="/product?product=bd001"
            buttonClass="bg-archive-brown text-warm-white"
          />
        </div>

        {/* Mobile secondary link */}
        <div className="order-5 bg-warm-cream text-center pb-12">
          <Link
            to="/product"
            className="inline-flex items-center gap-2 text-sm font-sans-zh text-archive-brown-60 hover:text-tea-gold transition-colors duration-200 group/link"
          >
            了解更多两款茶的理念与差异
            <ArrowRight size={16} strokeWidth={1.5} className="transition-transform duration-200 group-hover/link:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}
