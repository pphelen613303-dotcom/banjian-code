import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { ArrowRight } from 'lucide-react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { bysProduct, bd001Product } from '@/data/archive';

gsap.registerPlugin(ScrollTrigger);

function ProductCard({ product, delay }: { product: typeof bysProduct; delay: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const isBys = product.id === 'BYS001';
  const textureUrl = isBys
    ? '/images/banjian-new/brand/mountain-texture-bys.png'
    : '/images/banjian-new/brand/mountain-texture-bd001.png';

  useGSAP(() => {
    if (!cardRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        cardRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          delay,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cardRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, cardRef);
    return () => ctx.revert();
  }, { scope: cardRef });

  return (
    <div
      ref={cardRef}
      className="relative bg-[rgba(250,249,247,0.6)] border-t border-archive-brown-6 p-6 xs:p-8 transition-all duration-300 hover:border-tea-gold-40 opacity-0 overflow-hidden group"
    >
      {/* Mountain texture background decoration */}
      <div
        className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-[0.07] group-hover:opacity-[0.11]"
        style={{
          backgroundImage: `url(${textureUrl})`,
          backgroundPosition: 'bottom right',
          backgroundSize: '85% auto',
          backgroundRepeat: 'no-repeat',
          mixBlendMode: 'multiply',
        }}
      />
      {/* Right-edge subtle mountain contour line */}
      <div
        className="absolute right-0 bottom-0 w-[60%] h-[45%] pointer-events-none opacity-[0.06] group-hover:opacity-[0.09] transition-opacity duration-300"
        style={{
          backgroundImage: `url(${textureUrl})`,
          backgroundPosition: 'bottom right',
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
          filter: 'contrast(0.8) brightness(1.1)',
        }}
      />
      {/* Content layer */}
      <div className="relative z-10">
      {/* Product Number */}
      <span className="block text-xs font-medium font-sans-zh tracking-[0.15em] text-tea-gold mb-2 uppercase">
        {product.id}
      </span>

      {/* Product Name */}
      <h3 className="text-xl xs:text-2xl font-serif-zh text-archive-brown mb-3">
        {product.name}
      </h3>

      {/* Life Structure Tag */}
      <span className="inline-block px-3 py-1 text-xs font-sans-zh rounded bg-deep-green/10 text-deep-green mb-4">
        {product.lifeStructureTag}
      </span>

      {/* Core Sentence */}
      <p className="text-base font-serif-zh text-archive-brown/80 italic mb-4 leading-relaxed">
        {product.coreSentence}
      </p>

      {/* Meta Line */}
      <p className="text-xs font-sans-zh text-archive-brown-60 mb-6 leading-relaxed">
        {product.category} · {product.region} · {product.sampleSize} · {product.observationPath}
      </p>

      {/* CTA */}
      <Link
        to={`/product?product=${product.id === 'BYS001' ? 'bys' : 'bd001'}`}
        className="inline-flex items-center gap-2 text-sm font-sans-zh text-archive-brown hover:text-tea-gold transition-colors duration-200 group/cta"
      >
        进入{product.name}
        <ArrowRight size={16} strokeWidth={1.5} className="transition-transform duration-200 group-hover/cta:translate-x-1" />
      </Link>
      </div>{/* end content layer */}
    </div>
  );
}

export default function DualProductSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.dual-header > *',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.12,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.dual-header',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.dual-hero-img',
        { opacity: 0, scale: 0.98 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.dual-hero-img',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} className="py-16 md:py-24 bg-warm-white">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="dual-header mb-6">
          <SectionEyebrow text="TWO ENTRY POINTS" />
          <h2 className="text-[clamp(1.25rem,3vw,2.5rem)] font-serif-zh font-normal leading-[1.25] tracking-[0.015em] text-archive-brown mb-4">
            两款茶，是两种身体入口。
          </h2>
          <p className="text-base font-sans-zh text-archive-brown-60 max-w-xl leading-relaxed">
            这里不先问哪一款更好，而是先看你此刻更需要慢下来，还是重新感到结构。
          </p>
        </div>

        {/* Dual Hero Image */}
        <div className="dual-hero-img mb-6 rounded-lg overflow-hidden">
          <img
            src="/images/banjian-new/home/home-dual-sample.jpg"
            alt="白莺初霁与石界岩手同系统双产品档案入口"
            className="w-full max-h-[400px] object-cover"
            loading="lazy"
           decoding="async"/>
        </div>

        {/* Product Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-4">
          <ProductCard product={bysProduct} delay={0} />
          <ProductCard product={bd001Product} delay={0.15} />
        </div>

        {/* Section CTA */}
        <div className="mt-12 text-center">
          <Link
            to="/origin"
            className="inline-flex items-center justify-center px-8 py-3.5 border border-archive-brown text-archive-brown text-sm font-medium font-sans-zh rounded hover:bg-archive-brown hover:text-warm-white transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
          >
            查看生命档案
          </Link>
        </div>
      </div>
    </section>
  );
}
