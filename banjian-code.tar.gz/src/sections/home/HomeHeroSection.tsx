import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';

gsap.registerPlugin(ScrollTrigger);

export default function HomeHeroSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      tl.fromTo('.hero-eyebrow', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5 }, 0.2)
        .fromTo('.hero-h1', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.7 }, 0.4)
        .fromTo('.hero-desc', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6 }, 0.6)
        .fromTo('.hero-cta', { opacity: 0, y: 15 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.1 }, 0.8)
        .fromTo('.hero-image', { opacity: 0, scale: 0.97 }, { opacity: 1, scale: 1, duration: 1.0 }, 0.3)
        .fromTo('.hero-caption', { opacity: 0 }, { opacity: 1, duration: 0.5 }, 1.0);
    }, sectionRef);

    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      className="relative  bg-warm-white overflow-hidden"
    >
      {/* Subtle paper texture overlay */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%233D3229' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
      }} />

      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 py-5 md:py-12 lg:py-16">
        <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6 lg:gap-4 min-h-[auto]">
          {/* Left: Text Content (reordered first on mobile) */}
          <div className="w-full md:w-[48%] order-1 flex flex-col justify-center">
            <div className="hero-eyebrow opacity-0">
              <SectionEyebrow text="BANJIAN LIVING ARCHIVE" />
            </div>

            <h1 className="hero-h1 opacity-0 font-serif-zh text-[clamp(1.75rem,5vw,3rem)] md:text-[clamp(2.25rem,3.5vw,3.5rem)] font-normal leading-[1.15] tracking-[0.02em] text-archive-brown mb-6">
              看得见的，只是浮在上面那一层。
            </h1>

            <p className="hero-desc opacity-0 font-sans-zh text-base xs:text-base leading-[1.75] text-archive-brown/70 max-w-[480px] mb-8">
              半见用一杯茶，帮助现代人重新建立对时间、身体、生态和劳动关系的观察能力。
            </p>

            <div className="flex flex-col xs:flex-row gap-4 hero-cta">
              <Link
                to="/observe"
                className="opacity-0 inline-flex items-center justify-center px-8 py-3.5 bg-archive-brown text-warm-white text-sm font-medium font-sans-zh rounded hover:bg-tea-gold hover:text-archive-brown transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
              >
                开始七泡观察
              </Link>
              <Link
                to="/product"
                className="opacity-0 inline-flex items-center justify-center px-8 py-3.5 border border-archive-brown text-archive-brown text-sm font-medium font-sans-zh rounded hover:bg-archive-brown hover:text-warm-white transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
              >
                查看两款基准茶
              </Link>
            </div>
          </div>

          {/* Right: Hero Image (order-2 on mobile) */}
          <div className="w-full md:w-[52%] order-2">
            <div className="hero-image opacity-0 relative">
              <img
                src="/images/banjian-new/home/home-hero-01-temp-final.png"
                alt="观察桌面——一只手正靠近茶杯，自然木质桌面上的茶观察场景"
                className="w-full h-auto max-h-[70vh] object-cover rounded-lg"
                loading="eager"
                fetchPriority="high"
               decoding="async"/>
              <p className="hero-caption opacity-0 mt-3 text-xs font-sans-zh text-archive-brown/50 tracking-[0.02em]">
                <span className="md:hidden">01 从第一口开始。</span>
                <span className="hidden md:inline">01 从第一口开始，档案仍在继续。</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
