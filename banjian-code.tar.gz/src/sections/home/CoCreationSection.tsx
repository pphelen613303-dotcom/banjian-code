import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import {
  Leaf, Wrench, Package, Coffee,
  TrendingUp, GraduationCap, TreePine, ClipboardList, Share2,
  Gem, Users, BookOpen, Heart, ArrowRight,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

// ─── Data ───

const layers = [
  {
    number: '01',
    name: '第一层  生产完成层',
    title: '茶如何被做出来',
    nodes: [
      { icon: Leaf, label: '茶农鲜叶' },
      { icon: Wrench, label: '制茶工费' },
      { icon: Package, label: '包材履约' },
      { icon: Coffee, label: '用户冲泡' },
    ],
    note: '完成一泡茶的基础发生。',
  },
  {
    number: '02',
    name: '第二层  再生系统层',
    title: '人 + 技艺 + 资源 + 系统如何持续存在',
    nodes: [
      { icon: TrendingUp, label: '茶农增益' },
      { icon: GraduationCap, label: '学徒与工艺传承' },
      { icon: TreePine, label: '古茶树生态' },
      { icon: ClipboardList, label: '溯源记录' },
      { icon: Share2, label: '内容传播' },
    ],
    note: '不是额外包装，而是为了让下一泡茶还能成立。',
  },
  {
    number: '03',
    name: '第三层  文化与长期增长层',
    title: '系统最终留下什么',
    nodes: [
      { icon: Gem, label: '更好的产品' },
      { icon: Users, label: '更稳定的人' },
      { icon: TreePine, label: '可持续的资源' },
      { icon: BookOpen, label: '可被阅读的档案' },
      { icon: Heart, label: '逐渐成熟的文化关系' },
    ],
    note: '系统不是只卖当下，而是留下未来。',
  },
];

// ─── Component ───

export default function CoCreationSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    // Hero animations
    gsap.fromTo('.cocreation-label', { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: '.cocreation-hero', start: 'top 80%' },
    });
    gsap.fromTo('.cocreation-title-line', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.7, stagger: 0.15, ease: 'power2.out',
      scrollTrigger: { trigger: '.cocreation-title', start: 'top 80%' },
    });
    gsap.fromTo('.cocreation-paragraphs > p', { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.08, ease: 'power2.out',
      scrollTrigger: { trigger: '.cocreation-paragraphs', start: 'top 85%' },
    });
    gsap.fromTo('.cocreation-badge', { opacity: 0, scale: 0.9 }, {
      opacity: 1, scale: 1, duration: 0.7, ease: 'power2.out',
      scrollTrigger: { trigger: '.cocreation-badge', start: 'top 85%' },
    });

    // Timeline animations
    gsap.fromTo('.cocreation-timeline-line', { scaleY: 0 }, {
      scaleY: 1, duration: 1, ease: 'power2.out',
      scrollTrigger: { trigger: '.cocreation-layers', start: 'top 80%' },
    });
    gsap.utils.toArray<HTMLElement>('.cocreation-layer').forEach((layer, i) => {
      gsap.fromTo(layer, { opacity: 0, y: 40 }, {
        opacity: 1, y: 0, duration: 0.7, delay: i * 0.15, ease: 'power2.out',
        scrollTrigger: { trigger: layer, start: 'top 85%' },
      });
    });
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      className="relative w-full overflow-hidden"
      style={{ backgroundColor: '#FAF9F7' }}
    >
      {/* ═══════════ HERO ═══════════ */}
      <div className="cocreation-hero relative">
        {/* Background image */}
        <div
          className="absolute inset-0 w-full h-full"
          style={{
            backgroundImage: 'url(/images/banjian-new/brand/co-creation-hero-bg.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center right',
          }}
        />
        {/* Stronger left-side overlay for text readability */}
        <div
          className="absolute inset-0 z-[1]"
          style={{
            background: 'linear-gradient(to right, rgba(250,249,247,0.88) 0%, rgba(250,249,247,0.75) 40%, rgba(250,249,247,0.3) 65%, transparent 80%)',
          }}
        />

        <div className="relative z-10 max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 py-16 md:py-24 lg:py-28">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-8">
            {/* Left: text */}
            <div className="max-w-lg">
              <p className="cocreation-label text-[10px] font-mono-data tracking-[0.25em] text-archive-brown-40 uppercase mb-6">
                CO-CREATION SYSTEM
              </p>
              <div className="cocreation-title mb-8">
                <h2 className="cocreation-title-line text-[clamp(1.75rem,4vw,2.75rem)] font-serif-zh text-archive-brown leading-[1.3]">
                  这不是买卖，
                </h2>
                <h2 className="cocreation-title-line text-[clamp(1.75rem,4vw,2.75rem)] font-serif-zh text-archive-brown leading-[1.3]">
                  是一套正在学习成熟的共创系统
                </h2>
              </div>
              <div className="cocreation-paragraphs space-y-1.5 text-sm font-sans-zh text-archive-brown-60 leading-[1.8]">
                <p>我们并不把一泡茶看成孤立商品。</p>
                <p>它来自山场、茶农、制茶师、学徒、古茶树资源、</p>
                <p>溯源记录与用户体验的共同完成。</p>
                <p>这个系统还不成熟，但真实在发生，也正在被公开。</p>
              </div>
            </div>

            {/* Right: tea badge */}
            <div className="cocreation-badge flex-shrink-0 self-center md:self-auto md:mt-12">
              <div
                className="w-36 h-36 md:w-44 md:h-44 rounded-full flex flex-col items-center justify-center border-2"
                style={{
                  backgroundColor: 'rgba(250,249,247,0.7)',
                  borderColor: 'rgba(61,50,41,0.1)',
                  backdropFilter: 'blur(4px)',
                }}
              >
                <span className="text-2xl md:text-3xl font-mono-data text-archive-brown mb-1">01</span>
                <span className="text-sm font-serif-zh text-archive-brown">基准茶</span>
                <span className="text-[10px] font-mono-data text-archive-brown-50 tracking-wider mt-0.5">BYS001</span>
                <div className="w-8 h-[1px] bg-archive-brown-20 my-2" />
                <span className="text-xs font-sans-zh text-archive-brown-60">白莺初霁</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════ THREE LAYERS ═══════════ */}
      <div className="cocreation-layers relative max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 py-8 md:py-12">
        {/* Vertical timeline line */}
        <div
          className="cocreation-timeline-line absolute left-[19px] md:left-[21px] top-3 bottom-3 w-[1px] origin-top"
          style={{ backgroundColor: 'rgba(61,50,41,0.12)' }}
        />

        <div className="space-y-0">
          {layers.map((layer, layerIdx) => (
            <div
              key={layer.number}
              className="cocreation-layer relative pl-10 md:pl-14 pb-6 md:pb-10 last:pb-0"
            >
              {/* Timeline dot */}
              <div
                className="absolute left-0 top-0 w-10 h-10 md:w-11 md:h-11 rounded-full flex items-center justify-center border z-10"
                style={{
                  borderColor: layerIdx === 0 ? '#D4A853' : 'rgba(61,50,41,0.15)',
                  backgroundColor: layerIdx === 0 ? 'rgba(212,168,83,0.08)' : '#FAF9F7',
                }}
              >
                <span
                  className="text-xs md:text-sm font-mono-data font-medium"
                  style={{ color: layerIdx === 0 ? '#D4A853' : 'rgba(61,50,41,0.35)' }}
                >
                  {layer.number}
                </span>
              </div>

              {/* Layer content */}
              <div className="flex flex-col lg:flex-row lg:items-start gap-4 lg:gap-8">
                {/* Left: name */}
                <div className="lg:w-32 flex-shrink-0 pt-1">
                  <p className="text-xs font-sans-zh text-archive-brown-40 leading-relaxed whitespace-pre-line">
                    {layer.name}
                  </p>
                </div>

                {/* Center: title + nodes */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg md:text-xl font-serif-zh text-archive-brown mb-4">
                    {layer.title}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 md:gap-3">
                    {layer.nodes.map((node, nodeIdx) => {
                      const Icon = node.icon;
                      return (
                        <div key={node.label} className="flex items-center">
                          <div className="flex flex-col items-center text-center px-1.5 py-2">
                            <div
                              className="w-10 h-10 md:w-11 md:h-11 rounded-full flex items-center justify-center mb-1"
                              style={{ backgroundColor: 'rgba(61,50,41,0.04)' }}
                            >
                              <Icon size={16} className="text-archive-brown" strokeWidth={1.5} />
                            </div>
                            <span className="text-[10px] font-sans-zh text-archive-brown-60">
                              {node.label}
                            </span>
                          </div>
                          {nodeIdx < layer.nodes.length - 1 && (
                            <ArrowRight size={12} className="text-archive-brown-20 mx-0.5 shrink-0 mt-[-12px]" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Right: note */}
                <div className="lg:w-40 flex-shrink-0">
                  <p className="text-sm font-sans-zh text-archive-brown-50 leading-relaxed whitespace-pre-line">
                    {layer.note}
                  </p>
                </div>
              </div>

              {/* Divider between layers */}
              {layerIdx < layers.length - 1 && (
                <div className="w-full h-[1px] bg-archive-brown-10 mt-6 md:mt-10" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
