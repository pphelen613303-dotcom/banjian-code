import { useRef, useState } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import { infusionKeywords } from '@/data/experience';

gsap.registerPlugin(ScrollTrigger);

export default function SevenInfusionEntry() {
  const sectionRef = useRef<HTMLElement>(null);
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.seven-core-text',
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.seven-core-text',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.infusion-node',
        { opacity: 0, scale: 0.8 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.infusion-nodes-container',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.seven-ctas',
        { opacity: 0, y: 15 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          delay: 0.3,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.infusion-nodes-container',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} className="py-16 md:py-24 bg-warm-white">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 text-center">
        {/* Core Sentence */}
        <div className="seven-core-text mb-6">
          <h2 className="text-[clamp(1.25rem,3vw,2.5rem)] font-serif-zh font-normal leading-[1.25] tracking-[0.015em] text-archive-brown mb-4">
            第一次喝，不用急着评价。七泡里，只观察一件事：身体有没有开始说话。
          </h2>
          <p className="text-xs font-sans-zh text-archive-brown-50 tracking-wide">
            不急着判断好坏
          </p>
        </div>

        {/* Seven Nodes */}
        <div className="infusion-nodes-container flex items-center justify-center gap-3 xs:gap-4 mb-6 overflow-x-auto pb-4 xs:pb-0 snap-x snap-mandatory">
          {/* Connecting line (desktop) */}
          <div className="hidden md:block absolute left-0 right-0 h-[1px] bg-archive-brown-10 top-1/2 -z-10" />

          {infusionKeywords.map((item) => (
            <Link
              key={item.step}
              to={`/observe?infusion=${item.step}`}
              className="snap-center shrink-0 relative"
              onMouseEnter={() => setHoveredStep(item.step)}
              onMouseLeave={() => setHoveredStep(null)}
            >
              <div
                className={cn(
                  'w-14 h-14 xs:w-16 xs:h-16 rounded-full border-2 flex items-center justify-center',
                  'transition-all duration-300',
                  hoveredStep === item.step
                    ? 'border-tea-gold bg-tea-gold-20 shadow-[0_0_8px_rgba(212,168,83,0.4)]'
                    : 'border-archive-brown-15'
                )}
              >
                <span className="font-mono-data text-sm text-archive-brown">
                  {String(item.step).padStart(2, '0')}
                </span>
              </div>

              {/* Hover tooltip */}
              <div
                className={cn(
                  'absolute -top-10 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-archive-brown text-warm-white text-xs font-sans-zh whitespace-nowrap transition-all duration-200 pointer-events-none',
                  hoveredStep === item.step ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
                )}
              >
                {item.keyword}
              </div>
            </Link>
          ))}
        </div>

        {/* CTAs */}
        <div className="seven-ctas flex flex-col xs:flex-row items-center justify-center gap-4">
          <Link
            to="/observe"
            className="w-full xs:w-auto inline-flex items-center justify-center px-8 py-3.5 bg-archive-brown text-warm-white text-sm font-medium font-sans-zh rounded hover:bg-tea-gold hover:text-archive-brown transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
          >
            开始七泡观察
          </Link>
          <Link
            to="/observe?track=7day"
            className="w-full xs:w-auto inline-flex items-center justify-center px-8 py-3.5 border border-archive-brown text-archive-brown text-sm font-medium font-sans-zh rounded hover:bg-archive-brown hover:text-warm-white transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
          >
            进入七天茶觉
          </Link>
        </div>
      </div>
    </section>
  );
}
