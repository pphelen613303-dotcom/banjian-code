import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    title: '拿起这一泡',
    description: '每一袋对应一次独立的身体观察。',
  },
  {
    number: '02',
    title: '看卡片提示',
    description: '卡片告诉你在这一泡里注意什么。',
  },
  {
    number: '03',
    title: '写下一句话',
    description: '不需要专业术语，只记录身体最真实的反应。',
  },
];

export default function ObservationCardBridge() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.card-bridge-header > *',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.card-bridge-header',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.observe-card-img',
        { opacity: 0, rotate: -2 },
        {
          opacity: 1,
          rotate: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.observe-card-img',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.step-card',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.steps-container',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} className="py-16 md:py-24 bg-warm-cream">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="card-bridge-header mb-5">
          <SectionEyebrow text="OBSERVATION CARD" />
          <h2 className="text-[clamp(1.25rem,3vw,2.5rem)] font-serif-zh font-normal leading-[1.25] tracking-[0.015em] text-archive-brown mb-4">
            从包装上的一张卡，进入一次真实记录。
          </h2>
          <p className="text-base font-sans-zh text-archive-brown-60 max-w-2xl leading-relaxed">
            观察卡不是茶知识说明书。它只负责帮你停一下，把注意力从"这茶好不好"带到"我身体里发生了什么"。
          </p>
        </div>

        {/* Observation Card Image */}
        <div className="observe-card-img mb-6 max-w-lg mx-auto md:mx-0">
          <img
            src="/images/banjian-new/packaging/bys-observe-card.png"
            alt="观察卡——帮助你将注意力从这茶好不好带到我身体里发生了什么"
            className="w-full h-auto rounded-lg shadow-[0_4px_20px_rgba(0,0,0,0.06)]"
            loading="lazy"
           decoding="async"/>
        </div>

        {/* Three Steps */}
        <div className="steps-container grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {steps.map((step, index) => (
            <div key={step.number} className="step-card relative opacity-0">
              <span className="block text-4xl font-serif-zh text-tea-gold mb-3">{step.number}</span>
              <h3 className="text-lg font-semibold font-serif-zh text-archive-brown mb-2">
                {step.title}
              </h3>
              <p className="text-sm font-sans-zh text-archive-brown-60 leading-relaxed">
                {step.description}
              </p>
              {/* Connecting line (desktop only) */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 right-0 w-full h-[1px] bg-archive-brown-10 translate-x-1/2" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
