import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

export default function ValueOriginEntry() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.value-origin-content',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.value-origin-ctas > *',
        { opacity: 0, y: 15 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.value-origin-ctas',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      className="py-16 md:py-24 relative overflow-hidden"
    >
      {/* Background scene image */}
      <img
        src="/images/banjian-new/home/value-origin-bg.jpg"
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
       decoding="async"/>

      {/* Semi-transparent archive-brown overlay for color harmony */}
      <div className="absolute inset-0 bg-archive-brown/72 backdrop-blur-[2px]" />

      <div className="max-w-3xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 text-center relative z-10">
        <div className="value-origin-content">
          {/* Five-dimension summary */}
          <h2 className="text-[clamp(1.25rem,3vw,2.5rem)] font-serif-zh font-normal leading-[1.25] tracking-[0.015em] text-warm-white mb-6">
            不只问好不好喝，而是看感官、身体、信息、文化与伦理是否一起成立。
          </h2>

          {/* Eight-value-flow question */}
          <p className="text-base font-sans-zh text-warm-white/70 leading-relaxed mb-5">
            一泡茶的钱，继续流向哪里？
          </p>
        </div>

        {/* CTAs */}
        <div className="value-origin-ctas flex flex-col xs:flex-row items-center justify-center gap-4">
          <Link
            to="/origin"
            className="opacity-0 w-full xs:w-auto inline-flex items-center justify-center px-8 py-3.5 border border-tea-gold text-tea-gold text-sm font-medium font-sans-zh rounded hover:bg-tea-gold hover:text-archive-brown transition-all duration-200 active:scale-[0.98] tracking-[0.05em]"
          >
            查看生命档案
          </Link>
          <Link
            to="/value"
            className="opacity-0 w-full xs:w-auto inline-flex items-center justify-center px-8 py-3.5 text-warm-white/70 text-sm font-medium font-sans-zh underline underline-offset-4 hover:text-tea-gold transition-colors duration-200"
          >
            查看八项价值流向
          </Link>
        </div>
      </div>
    </section>
  );
}
