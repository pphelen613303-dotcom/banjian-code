import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import SectionEyebrow from '@/components/SectionEyebrow';
import SevenInfusionPath from './SevenInfusionPath';
import { bysTimeline, bd001Timeline } from '@/data/originTimelineData';
import { Leaf, Mountain } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const productImages: Record<string, string> = {
  bys: '/images/banjian-new/product/bys-box-closed.jpg',
  bd001: '/images/banjian-new/product/bd001-box-closed.jpg',
};

const sampleSpec = '1枚 × 8g / 7枚 × 8g / 14枚 × 8g';

const coreEvidence: Record<string, string[]> = {
  bys: ['标本采样', '采摘监控', '鲜叶称重', '初制溯源码', '温湿度记录', '摊晾/揉捻/日晒记录', '封箱运输', '数字存证'],
  bd001: ['标本/山场资料', '采摘监控', '鲜叶称重', '初制溯源码', '锅温记录', '炒青/揉捻/晒青记录', '封箱运输', '数字存证'],
};

interface Props {
  activeProduct: 'bys' | 'bd001';
  onSwitch: (p: 'bys' | 'bd001') => void;
}

export default function ProductArchiveSection({ activeProduct, onSwitch }: Props) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const isBYS = activeProduct === 'bys';
  const data = isBYS ? bysTimeline : bd001Timeline;
  const imgSrc = productImages[activeProduct];
  const evidenceTags = coreEvidence[activeProduct];

  useGSAP(() => {
    if (!contentRef.current) return;
    const items = contentRef.current.querySelectorAll('.pa-item');
    gsap.fromTo(items, { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.06, ease: 'power2.out',
      scrollTrigger: { trigger: contentRef.current, start: 'top 85%', toggleActions: 'play none none none' },
    });
  }, { scope: sectionRef, dependencies: [activeProduct] });

  // Info tags: 编号 / 品类 / 生命结构
  const infoTags = [
    { label: data.code, mono: true },
    { label: isBYS ? '白茶' : '普洱生茶', mono: false },
    { label: data.lifeStructure, mono: false },
  ];

  // Data fields — exactly as V3 specified
  const fields = [
    { label: '编号', value: data.code },
    { label: '来源名', value: data.sourceName },
    { label: '产品名', value: data.name },
    { label: '核心句', value: data.coreSentence, highlight: true },
    { label: '生命结构', value: data.lifeStructure },
    { label: '产区', value: data.mountain },
    { label: '品类', value: isBYS ? '白茶' : '普洱生茶' },
    { label: '样本规格', value: sampleSpec },
  ];

  return (
    <section ref={sectionRef} id="origin-archive" className="bg-warm-white py-14 md:py-20">
      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <SectionEyebrow text="LIVING ARCHIVE" />

        <div ref={contentRef}>
          {/* Title */}
          <h2 className="pa-item font-serif-zh text-archive-brown mb-5" style={{ fontSize: 'clamp(1.5rem, 3vw, 2.25rem)' }}>
            产品档案
          </h2>

          {/* Product Switcher */}
          <div className="pa-item flex items-center gap-2 mb-5">
            <button
              onClick={() => onSwitch('bys')}
              className={cn(
                'flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-sans-zh font-medium transition-all duration-300 border',
                isBYS
                  ? 'border-transparent text-warm-white'
                  : 'border-archive-brown-12 text-archive-brown-60 hover:text-archive-brown'
              )}
              style={{ backgroundColor: isBYS ? '#1B4332' : 'transparent' }}
            >
              <Leaf size={14} strokeWidth={1.5} />
              白莺初霁 BYS001
            </button>
            <button
              onClick={() => onSwitch('bd001')}
              className={cn(
                'flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-sans-zh font-medium transition-all duration-300 border',
                !isBYS
                  ? 'border-transparent text-warm-white'
                  : 'border-archive-brown-12 text-archive-brown-60 hover:text-archive-brown'
              )}
              style={{ backgroundColor: !isBYS ? '#8B6239' : 'transparent' }}
            >
              <Mountain size={14} strokeWidth={1.5} />
              石界岩手 BD001
            </button>
          </div>

          {/* Info Tags: BYS001 / 白茶 / 时间缓释结构 */}
          <div className="pa-item flex items-center gap-2 mb-4">
            {infoTags.map((tag, i) => (
              <span
                key={i}
                className={cn(
                  'px-3 py-1 rounded text-sm',
                  tag.mono ? 'font-mono-data' : 'font-sans-zh'
                )}
                style={{
                  backgroundColor: 'rgba(61,50,41,0.06)',
                  color: '#3D3229',
                  border: '1px solid rgba(61,50,41,0.08)',
                }}
              >
                {tag.label}
              </span>
            ))}
          </div>

          {/* Core Sentence */}
          <p className="pa-item text-base font-serif-zh text-archive-brown-80 leading-relaxed mb-8">
            {data.coreSentence}
          </p>

          {/* Content: image + data */}
          <div className="pa-item flex flex-col lg:flex-row gap-8 lg:gap-10">
            {/* Left: Product image */}
            <div className="lg:w-64 flex-shrink-0">
              <div className="relative rounded-xl overflow-hidden border border-archive-brown-12">
                <img
                  src={imgSrc}
                  alt={`${data.name}产品包装`}
                  className="w-full aspect-square object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <div
                  className="absolute bottom-0 left-0 right-0 px-3 py-2"
                  style={{ background: 'linear-gradient(to top, rgba(61,50,41,0.6), transparent)' }}
                >
                  <p className="text-xs font-mono-data text-warm-white/90">{data.code}</p>
                  <p className="text-sm font-serif-zh text-warm-white">{data.name}</p>
                </div>
              </div>
            </div>

            {/* Right: Data fields */}
            <div className="flex-1 min-w-0">
              <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-0">
                {fields.map((field, index) => {
                  const isEven = index % 2 === 0;
                  return (
                    <div
                      key={`${activeProduct}-${field.label}`}
                      className="flex flex-col xs:flex-row xs:items-baseline py-3 border-b border-archive-brown-12"
                      style={{ backgroundColor: isEven ? 'rgba(61,50,41,0.02)' : 'transparent' }}
                    >
                      <dt className="text-xs font-sans-zh uppercase tracking-[0.1em] text-archive-brown-60 w-full xs:w-24 shrink-0 mb-1 xs:mb-0">
                        {field.label}
                      </dt>
                      <dd className={`text-sm flex-1 ${
                        field.highlight
                          ? 'font-serif-zh text-archive-brown-80'
                          : field.label === '编号'
                            ? 'font-mono-data text-archive-brown'
                            : 'font-medium text-archive-brown'
                      }`}>
                        {field.value}
                      </dd>
                    </div>
                  );
                })}

                {/* Seven Infusion Path */}
                <div className="col-span-1 md:col-span-2 py-4 border-b border-archive-brown-12">
                  <SevenInfusionPath
                    steps={data.infusionPath}
                    productColor={isBYS ? '#1B4332' : '#8B6239'}
                  />
                </div>

                {/* Core Evidence Direction */}
                <div className="col-span-1 md:col-span-2 py-4">
                  <p className="text-xs font-sans-zh uppercase tracking-[0.1em] text-archive-brown-60 mb-3">
                    核心证据方向
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {evidenceTags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 rounded-full text-xs font-sans-zh"
                        style={{
                          backgroundColor: isBYS ? 'rgba(27,67,50,0.06)' : 'rgba(139,98,57,0.06)',
                          color: isBYS ? '#1B4332' : '#8B6239',
                          border: `1px solid ${isBYS ? 'rgba(27,67,50,0.12)' : 'rgba(139,98,57,0.12)'}`,
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
