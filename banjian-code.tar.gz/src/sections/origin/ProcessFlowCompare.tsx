import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import {
  Droplets, Wind, Hand, Sun, Layers, SunDim,
  Timer, Flame, Mountain, Leaf,
} from 'lucide-react';
import type { ProcessPhase } from '@/data/originTimelineData';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  Droplets, Wind, Hand, Sun, Layers, SunDim, Timer, Flame, Mountain, Leaf,
};

interface Props {
  bysProcess: ProcessPhase;
  bd001Process: ProcessPhase;
}

function ProcessColumn({
  subtitle,
  productName,
  icon: HeaderIcon,
  process,
  accentColor,
}: {
  subtitle: string;
  productName: string;
  icon: React.ElementType;
  process: ProcessPhase;
  accentColor: string;
}) {
  return (
    <div className="flex-1 min-w-0">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <HeaderIcon size={16} style={{ color: accentColor }} strokeWidth={1.5} />
        <div>
          <p className="text-sm font-serif-zh text-archive-brown">{productName}</p>
          <p className="text-[10px] font-sans-zh text-archive-brown-50">{subtitle}</p>
        </div>
      </div>

      {/* Steps */}
      <div className="space-y-2">
        {process.steps.map((step, i) => {
          const Icon = iconMap[step.icon] || Sun;
          return (
            <div key={step.name} className="pf-step">
              <div
                className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg border transition-all duration-200 hover:shadow-sm"
                style={{
                  borderColor: 'rgba(61,50,41,0.08)',
                  backgroundColor: 'rgba(250,249,247,0.8)',
                }}
              >
                <Icon size={14} style={{ color: accentColor }} strokeWidth={1.5} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-serif-zh text-archive-brown">{step.name}</p>
                  <p className="text-[10px] font-sans-zh text-archive-brown-50">{step.desc}</p>
                </div>
              </div>
              {i < process.steps.length - 1 && (
                <div className="flex justify-center py-0.5">
                  <div className="w-[1px] h-2" style={{ backgroundColor: 'rgba(61,50,41,0.08)' }} />
                </div>
              )}
            </div>
          );
        })}

        {/* Closing card */}
        {process.closing && (
          <div
            className="mt-3 px-3 py-3 rounded-lg border"
            style={{
              borderColor: `${accentColor}30`,
              backgroundColor: `${accentColor}08`,
            }}
          >
            <div className="flex items-center gap-2">
              {(() => {
                const ClosingIcon = iconMap[process.closing.icon] || Leaf;
                return <ClosingIcon size={14} style={{ color: accentColor }} strokeWidth={1.5} />;
              })()}
              <div>
                <p className="text-xs font-serif-zh font-medium" style={{ color: accentColor }}>
                  {process.closing.title}
                </p>
                <p className="text-[10px] font-sans-zh text-archive-brown-50">{process.closing.desc}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ProcessFlowCompare({ bysProcess, bd001Process }: Props) {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.pf-step', { opacity: 0, x: -10 }, {
      opacity: 1, x: 0, duration: 0.4, stagger: 0.04, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="py-6 md:py-8">
      {/* Label */}
      <p className="text-[10px] font-mono-data tracking-[0.25em] text-archive-brown-40 uppercase mb-2">
        CRAFT · 工艺转化
      </p>

      {/* Two columns */}
      <div className="flex flex-col md:flex-row gap-6 md:gap-8">
        <ProcessColumn
          subtitle="低干预 · 缓慢转化"
          productName="白莺初霁"
          icon={Leaf}
          process={bysProcess}
          accentColor="#1B4332"
        />
        <ProcessColumn
          subtitle="高温激活 · 结构释放"
          productName="石界岩手"
          icon={Mountain}
          process={bd001Process}
          accentColor="#8B6239"
        />
      </div>
    </div>
  );
}
