import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import type { InfusionStep } from '@/data/originTimelineData';

gsap.registerPlugin(ScrollTrigger);

interface Props {
  steps: InfusionStep[];
  productColor: string; // '#1B4332' for BYS, '#8B6239' for BD001
}

export default function SevenInfusionPath({ steps, productColor }: Props) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.sip-step', { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.08, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 85%' },
    });
    gsap.fromTo('.sip-line', { scaleX: 0 }, {
      scaleX: 1, duration: 1.2, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="py-6 md:py-8">
      {/* Label */}
      <p className="text-[10px] font-mono-data tracking-[0.25em] text-archive-brown-40 uppercase mb-6">
        SEVEN INFUSION PATH
      </p>

      {/* Timeline */}
      <div className="relative">
        {/* Connection line */}
        <div
          className="sip-line absolute top-[15px] md:top-[19px] left-0 right-0 h-[2px] origin-left"
          style={{
            background: `linear-gradient(to right, ${productColor} 0%, ${productColor} 70%, #D4A853 70%, #D4A853 100%)`,
          }}
        />

        {/* Steps */}
        <div className="flex justify-between relative z-10">
          {steps.map((step, i) => {
            const isHovered = hoveredIdx === i;
            return (
              <div
                key={step.number}
                className="sip-step flex flex-col items-center cursor-pointer group"
                style={{ width: `${100 / 7}%` }}
                onMouseEnter={() => setHoveredIdx(i)}
                onMouseLeave={() => setHoveredIdx(null)}
              >
                {/* Circle dot */}
                <div
                  className="w-[30px] h-[30px] md:w-[38px] md:h-[38px] rounded-full border-2 flex items-center justify-center transition-all duration-300"
                  style={{
                    borderColor: i < 5 ? productColor : '#D4A853',
                    backgroundColor: isHovered
                      ? (i < 5 ? productColor : '#D4A853')
                      : '#FAF9F7',
                    transform: isHovered ? 'scale(1.15)' : 'scale(1)',
                  }}
                >
                  <span
                    className="text-[10px] md:text-xs font-mono-data font-medium transition-colors duration-300"
                    style={{
                      color: isHovered ? '#FAF9F7' : (i < 5 ? productColor : '#D4A853'),
                    }}
                  >
                    {String(step.number).padStart(2, '0')}
                  </span>
                </div>

                {/* Name */}
                <span
                  className="mt-2 text-[10px] md:text-xs font-serif-zh text-archive-brown text-center transition-colors duration-200"
                  style={{ color: isHovered ? productColor : '#3D3229' }}
                >
                  {step.name}
                </span>
              </div>
            );
          })}
        </div>

        {/* Hover tooltip */}
        {hoveredIdx !== null && (
          <div
            className="absolute left-1/2 -translate-x-1/2 mt-3 px-4 py-3 rounded-lg border max-w-xs w-full"
            style={{
              backgroundColor: 'rgba(250,249,247,0.96)',
              borderColor: 'rgba(61,50,41,0.1)',
              top: '60px',
            }}
          >
            <p className="text-[10px] font-mono-data text-archive-brown-40 mb-1">
              第{steps[hoveredIdx].number}泡 · {steps[hoveredIdx].name}
            </p>
            <p className="text-xs font-sans-zh text-archive-brown-70 leading-relaxed">
              {steps[hoveredIdx].guidance}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
