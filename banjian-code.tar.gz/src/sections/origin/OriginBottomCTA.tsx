import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

export default function OriginBottomCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!contentRef.current) return;
    const els = contentRef.current.children;

    gsap.fromTo(
      els[0],
      { opacity: 0, y: 25 },
      {
        opacity: 1, y: 0, duration: 0.6, ease: 'power2.out',
        scrollTrigger: { trigger: contentRef.current, start: 'top 85%', toggleActions: 'play none none none' },
      }
    );
    gsap.fromTo(
      els[1],
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.5, delay: 0.3, ease: 'power2.out',
        scrollTrigger: { trigger: contentRef.current, start: 'top 85%', toggleActions: 'play none none none' },
      }
    );
    gsap.fromTo(
      els[2],
      { opacity: 0, y: 15 },
      {
        opacity: 1, y: 0, duration: 0.5, delay: 0.5, ease: 'power2.out',
        scrollTrigger: { trigger: contentRef.current, start: 'top 85%', toggleActions: 'play none none none' },
      }
    );
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      id="origin-cta"
      className="bg-archive-brown py-14 md:py-20"
    >
      <div ref={contentRef} className="max-w-2xl mx-auto px-4 xs:px-6 text-center">
        <h2
          className="font-serif-zh text-warm-white"
          style={{ fontSize: 'clamp(1.5rem, 3.5vw, 2.25rem)', lineHeight: 1.2 }}
        >
          这份档案，还差你的一泡。
        </h2>

        <p className="mt-4 text-warm-white/70 font-sans-zh text-base leading-relaxed">
          当茶进入你的身体，它的生命档案才真正来到最后一层。
        </p>

        {/* CTA buttons */}
        <div className="mt-10 flex flex-col items-center gap-4">
          {/* Primary CTA */}
          <div className="w-full xs:w-auto flex flex-col items-center gap-2">
            <Link
              to="/observe"
              className="w-full xs:w-auto inline-block px-8 py-3.5 bg-tea-gold text-archive-brown text-sm font-medium font-sans-zh rounded hover:bg-[#e0b86a] active:scale-[0.98] transition-all duration-200 text-center tracking-wide"
            >
              进入七泡观察
            </Link>
            <span className="text-xs text-warm-white/40 font-sans-zh">
              第一次建议从七泡开始
            </span>
          </div>

          {/* Secondary CTA */}
          <div className="w-full xs:w-auto flex flex-col items-center gap-2">
            <Link
              to="/observe?track=7day"
              className="w-full xs:w-auto inline-block px-8 py-3.5 border border-tea-gold text-tea-gold text-sm font-medium font-sans-zh rounded hover:bg-tea-gold hover:text-archive-brown active:scale-[0.98] transition-all duration-200 text-center tracking-wide"
            >
              进入七天茶觉
            </Link>
            <span className="text-xs text-warm-white/40 font-sans-zh">
              每天一个身体入口，更长周期
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
