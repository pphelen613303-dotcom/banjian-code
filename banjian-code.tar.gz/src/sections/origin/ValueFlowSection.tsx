import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { Leaf, Wrench, Building, ClipboardCheck, Sparkles, Truck, TreePine, RefreshCw, ChevronDown } from 'lucide-react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { bysValueFlow, bd001ValueFlow } from '@/data/value-flow';
import type { ValueFlowItem } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ReactNode> = {
  leaf: <Leaf size={16} strokeWidth={1.5} />,
  wrench: <Wrench size={16} strokeWidth={1.5} />,
  building: <Building size={16} strokeWidth={1.5} />,
  'clipboard-check': <ClipboardCheck size={16} strokeWidth={1.5} />,
  sparkles: <Sparkles size={16} strokeWidth={1.5} />,
  truck: <Truck size={16} strokeWidth={1.5} />,
  'tree-pine': <TreePine size={16} strokeWidth={1.5} />,
  'refresh-cw': <RefreshCw size={16} strokeWidth={1.5} />,
};

const shortNames: Record<string, string> = {
  '固定成本': '固费',
  '溯源开销': '溯源',
  '品牌运营': '品牌',
  '物流售后': '物流',
  '生态回流': '生态',
  '成本回收': '回收',
};

interface ValueFlowRowProps {
  item: ValueFlowItem;
  maxPercent: number;
  index: number;
  active: boolean;
}

function ValueFlowRow({ item, maxPercent, index, active }: ValueFlowRowProps) {
  const barRef = useRef<HTMLDivElement>(null);
  const rowRef = useRef<HTMLDivElement>(null);
  const [showDetail, setShowDetail] = useState(false);
  const barWidth = (item.percent / maxPercent) * 100;

  useGSAP(() => {
    if (!barRef.current || !rowRef.current) return;

    gsap.fromTo(
      rowRef.current,
      { opacity: 0, y: 15 },
      {
        opacity: 1,
        y: 0,
        duration: 0.4,
        delay: index * 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: rowRef.current,
          start: 'top 90%',
          toggleActions: 'play none none none',
        },
      }
    );

    gsap.fromTo(
      barRef.current,
      { width: '0%' },
      {
        width: `${barWidth}%`,
        duration: 0.8,
        delay: index * 0.1 + 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: rowRef.current,
          start: 'top 90%',
          toggleActions: 'play none none none',
        },
      }
    );
  }, { scope: rowRef, dependencies: [active] });

  return (
    <div ref={rowRef} className="py-2.5">
      <div className="flex items-center gap-2 xs:gap-3">
        {/* Icon */}
        <span className="w-[26px] h-[26px] flex items-center justify-center text-archive-brown-60 shrink-0">
          {iconMap[item.icon] || <Leaf size={16} strokeWidth={1.5} />}
        </span>

        {/* Name */}
        <span className="w-10 xs:w-14 text-sm font-medium text-archive-brown font-sans-zh shrink-0 truncate">
          <span className="hidden xs:inline">{item.name}</span>
          <span className="xs:hidden">{shortNames[item.name] || item.name.slice(0, 2)}</span>
        </span>

        {/* Bar */}
        <div className="flex-1 h-4 bg-archive-brown/[0.06] rounded-full overflow-hidden relative">
          <div
            ref={barRef}
            className="h-full rounded-full"
            style={{
              background: 'linear-gradient(90deg, #1B4332, #40916c)',
              width: '0%',
            }}
          />
        </div>

        {/* Amount */}
        <span className="w-12 xs:w-14 text-right text-sm font-mono-data text-archive-brown shrink-0">
          ¥{item.amount.toFixed(2)}
        </span>
      </div>

      {/* Expandable cost detail */}
      <button
        onClick={() => setShowDetail(!showDetail)}
        className="mt-1 ml-8 xs:ml-9 text-[11px] text-archive-brown-60 font-sans-zh hover:text-tea-gold transition-colors flex items-center gap-0.5"
      >
        <span>查看成本明细</span>
        <ChevronDown
          size={12}
          className={`transition-transform duration-200 ${showDetail ? 'rotate-180' : ''}`}
        />
      </button>

      {showDetail && (
        <div className="mt-2 ml-8 xs:ml-9 p-3 bg-warm-cream rounded-md text-xs font-sans-zh space-y-1.5">
          <div className="flex justify-between text-archive-brown-60">
            <span>鲜叶采购</span>
            <span className="font-mono-data text-archive-brown">{(item.amount * 0.4).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-archive-brown-60">
            <span>初制工费</span>
            <span className="font-mono-data text-archive-brown">{(item.amount * 0.25).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-archive-brown-60">
            <span>固定费用摊销</span>
            <span className="font-mono-data text-archive-brown">{(item.amount * 0.2).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-archive-brown-60">
            <span>设备摊销</span>
            <span className="font-mono-data text-archive-brown">{(item.amount * 0.15).toFixed(2)}</span>
          </div>
        </div>
      )}
    </div>
  );
}

interface ValueFlowColumnProps {
  title: string;
  price: number;
  items: ValueFlowItem[];
  active: boolean;
}

function ValueFlowColumn({ title, price, items, active }: ValueFlowColumnProps) {
  const maxPercent = Math.max(...items.map((i) => i.percent));

  return (
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-archive-brown-12">
        <h3 className="text-base font-serif-zh text-archive-brown">{title}</h3>
        <span className="text-sm font-mono-data text-archive-brown-60">¥{price}/泡</span>
      </div>
      {items.map((item, i) => (
        <ValueFlowRow
          key={item.name}
          item={item}
          maxPercent={maxPercent}
          index={i}
          active={active}
        />
      ))}
    </div>
  );
}

export default function ValueFlowSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<'bys' | 'bd001'>('bys');

  const bysPrice = 36.9;
  const bd001Price = 29.9;

  return (
    <section
      ref={sectionRef}
      id="origin-value"
      className="bg-warm-white py-16 md:py-24"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <SectionEyebrow text="VALUE FLOW" />
        <h2
          className="font-serif-zh text-archive-brown mb-8 md:mb-6"
          style={{ fontSize: 'clamp(1.25rem, 3vw, 2rem)' }}
        >
          一泡茶的钱，继续流向哪里？
        </h2>

        {/* Product toggle */}
        <div className="flex border-b-2 border-archive-brown-12 mb-8">
          <button
            onClick={() => setActiveTab('bys')}
            className={`flex-1 py-3 text-base font-serif-zh transition-all duration-200 border-b-2 -mb-[2px] ${
              activeTab === 'bys'
                ? 'border-tea-gold text-archive-brown'
                : 'border-transparent text-archive-brown-60 hover:text-archive-brown'
            }`}
          >
            白莺初霁 ¥{bysPrice}/泡
          </button>
          <button
            onClick={() => setActiveTab('bd001')}
            className={`flex-1 py-3 text-base font-serif-zh transition-all duration-200 border-b-2 -mb-[2px] ${
              activeTab === 'bd001'
                ? 'border-tea-gold text-archive-brown'
                : 'border-transparent text-archive-brown-60 hover:text-archive-brown'
            }`}
          >
            石界岩手 ¥{bd001Price}/泡
          </button>
        </div>

        {/* Desktop: side-by-side / Mobile: single column based on active tab */}
        <div className="hidden md:flex gap-6 lg:gap-4">
          <ValueFlowColumn
            title="白莺初霁"
            price={bysPrice}
            items={bysValueFlow}
            active={activeTab === 'bys'}
          />
          <div className="w-[1px] bg-archive-brown-12 self-stretch" />
          <ValueFlowColumn
            title="石界岩手"
            price={bd001Price}
            items={bd001ValueFlow}
            active={activeTab === 'bd001'}
          />
        </div>

        {/* Mobile: single column with toggle */}
        <div className="md:hidden">
          {activeTab === 'bys' ? (
            <ValueFlowColumn
              title="白莺初霁"
              price={bysPrice}
              items={bysValueFlow}
              active={true}
            />
          ) : (
            <ValueFlowColumn
              title="石界岩手"
              price={bd001Price}
              items={bd001ValueFlow}
              active={true}
            />
          )}
        </div>
      </div>
    </section>
  );
}
