import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import SectionEyebrow from '@/components/SectionEyebrow';
import SevenInfusionPath from './SevenInfusionPath';
import ProcessFlowCompact from './ProcessFlowCompact';
import { bysTimeline, bd001Timeline } from '@/data/originTimelineData';
import EvidenceDrawerSection from './EvidenceDrawerSection';
import type { TimelineNode as TypesTimelineNode, EvidenceItem } from '@/types';
import type { ProductTimeline, TimelineNode } from '@/data/originTimelineData';
import { TreePine, Hand, Flame, Package, Lock, Eye, RefreshCw, ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const nodeIcons = [TreePine, Hand, Flame, Package, Lock, Eye, RefreshCw];

const groupStyles = [
  { label: '进山 · 茶的来处', color: '#1B4332', bg: 'rgba(27,67,50,0.06)', border: 'rgba(27,67,50,0.12)', labelBg: 'rgba(27,67,50,0.08)' },
  { label: '制茶 · 人的手艺', color: '#D4A853', bg: 'rgba(212,168,83,0.05)', border: 'rgba(212,168,83,0.15)', labelBg: 'rgba(212,168,83,0.08)' },
  { label: '到你 · 你的身体', color: '#8B6239', bg: 'rgba(139,98,57,0.05)', border: 'rgba(139,98,57,0.12)', labelBg: 'rgba(139,98,57,0.08)' },
];

// ═══ Single Node Card ═══

function NodeCard({
  node,
  isLarge,
  isNode3,
  isNode6,
  productData,
}: {
  node: TimelineNode;
  isLarge: boolean;
  isNode3: boolean;
  isNode6: boolean;
  productData: ProductTimeline;
}) {
  const [expandedItems, setExpandedItems] = useState<Set<number>>(new Set());
  const groupIndex = node.nodeNumber <= 2 ? 0 : node.nodeNumber <= 4 ? 1 : 2;
  const style = groupStyles[groupIndex];
  const Icon = nodeIcons[node.nodeNumber - 1];

  const toggleItem = (i: number) => {
    setExpandedItems((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  };

  return (
    <div
      className={cn('rounded-xl border backdrop-blur-sm transition-all duration-300', isLarge ? 'p-6 md:p-8' : 'p-5 md:p-6')}
      style={{ borderColor: style.border, backgroundColor: 'rgba(250,249,247,0.92)' }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: style.bg }}>
          <Icon size={18} style={{ color: style.color }} />
        </div>
        <div>
          <h3 className={cn('font-serif-zh text-archive-brown', isLarge ? 'text-xl md:text-2xl' : 'text-lg md:text-xl')}>
            {node.title}
          </h3>
          <span className="text-[10px] font-sans-zh tracking-[0.12em] uppercase" style={{ color: style.color }}>
            {style.label}
          </span>
        </div>
      </div>

      {/* Summary */}
      <p className="text-xs font-sans-zh text-archive-brown-60 leading-relaxed mb-4 italic">
        {node.summary}
      </p>

      {/* Item 1 — always expanded */}
      <div className="mb-4">
        <p className="text-sm font-serif-zh font-medium text-archive-brown leading-relaxed">{node.items[0].title}</p>
        <p className="text-sm font-sans-zh text-archive-brown-70 leading-relaxed mt-1.5">{node.items[0].body}</p>
      </div>

      {/* Items 2-4 — expandable */}
      <div className="space-y-0 border-t" style={{ borderColor: style.border }}>
        {[1, 2, 3].map((i) => {
          const isExpanded = expandedItems.has(i);
          return (
            <div key={i} className="py-2">
              <button onClick={() => toggleItem(i)} className="flex items-center gap-2 w-full text-left group">
                <ChevronDown size={14} className={cn('transition-transform duration-200 shrink-0', isExpanded ? 'rotate-180' : '')} style={{ color: style.color }} />
                <span className="text-sm font-serif-zh text-archive-brown-60 group-hover:text-archive-brown transition-colors">{node.items[i].title}</span>
              </button>
              {isExpanded && (
                <p className="text-sm font-sans-zh text-archive-brown-70 leading-relaxed mt-2 pl-6">{node.items[i].body}</p>
              )}
            </div>
          );
        })}
      </div>

      {/* Item 5 — always expanded */}
      <div className="mt-4 pt-4 border-t" style={{ borderColor: style.border }}>
        <p className="text-sm font-serif-zh font-medium italic leading-relaxed" style={{ color: style.color }}>{node.items[4].title}</p>
        <p className="text-sm font-sans-zh text-archive-brown-70 leading-relaxed mt-1.5">{node.items[4].body}</p>
      </div>

      {/* Node 03: Process Flow — current product only */}
      {isNode3 && (
        <div className="mt-6 pt-6 border-t" style={{ borderColor: style.border }}>
          {(() => {
            const isBYS = productData.productId === 'bys';
            const process = isBYS ? productData.process.bys : productData.process.bd001;
            return (
              <ProcessFlowCompact
                steps={process.steps}
                closing={process.closing}
                productLabel={productData.name}
                productSubtitle={isBYS ? '低干预 · 缓慢转化' : '高温激活 · 结构释放'}
                accentColor={isBYS ? '#1B4332' : '#8B6239'}
              />
            );
          })()}
        </div>
      )}

      {/* Node 06: Seven Infusion Path */}
      {isNode6 && (
        <div className="mt-6 pt-6 border-t" style={{ borderColor: style.border }}>
          <SevenInfusionPath
            steps={productData.infusionPath}
            productColor={productData.productId === 'bys' ? '#1B4332' : '#8B6239'}
          />
        </div>
      )}

      {/* Evidence Summary */}
      <div className="mt-4 p-4 rounded-lg" style={{ backgroundColor: style.bg, border: `1px solid ${style.border}` }}>
        <p className="font-serif-zh text-sm text-archive-brown font-medium leading-relaxed">
          {node.evidenceDrawer[0]?.displayText || '已建档'}
        </p>
      </div>

      {/* Evidence Drawer — Original component, data mapped from new format */}
      {(() => {
        // Map new evidenceDrawer format to old EvidenceItem format
        const mappedEvidence: EvidenceItem[] = node.evidenceDrawer.map((ev, i) => {
          // Map displayText to derive status
          const isVerified = ev.displayText.includes('查看') || ev.displayText.includes('展示');
          const isPending = ev.displayText.includes('待关联');
          // Map type keyword to EvidenceItem type
          let type: EvidenceItem['type'] = 'form';
          if (ev.type.includes('图片')) type = 'image';
          else if (ev.type.includes('视频')) type = 'video';
          else if (ev.type.includes('签名') || ev.type.includes('确认')) type = 'signature';
          else if (ev.type.includes('重量') || ev.type.includes('称重')) type = 'weight';

          return {
            id: `n${node.nodeNumber}-e${i}`,
            type,
            title: ev.evidenceName,
            status: isVerified ? 'verified' : isPending ? 'pending' : 'incomplete',
            description: ev.displayText,
          };
        });
        // Build a node object compatible with EvidenceDrawerSection
        const compatNode: TypesTimelineNode = {
          nodeNumber: node.nodeNumber,
          title: node.title,
          evidence: mappedEvidence,
          evidenceSummary: { brief: node.summary, detail: node.evidenceDrawer[0]?.displayText || '' },
        };
        return <EvidenceDrawerSection node={compatNode} />;
      })()}
    </div>
  );
}

// ═══ Main Timeline Section ═══

interface TimelineSectionProps {
  activeProduct: 'bys' | 'bd001';
}

export default function TimelineSection({ activeProduct }: TimelineSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const nodesRef = useRef<HTMLDivElement>(null);

  const productData = activeProduct === 'bd001' ? bd001Timeline : bysTimeline;
  const nodes = productData.nodes;

  // Scroll animations
  useGSAP(() => {
    if (!nodesRef.current) return;
    const nodeEls = nodesRef.current.querySelectorAll('.timeline-node');
    nodeEls.forEach((el, i) => {
      gsap.fromTo(el, { opacity: 0, y: 30 }, {
        opacity: 1, y: 0, duration: 0.6, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
        delay: i * 0.08,
      });
    });
  }, { scope: sectionRef, dependencies: [activeProduct] });

  // Re-animate on product switch
  useGSAP(() => {
    if (!nodesRef.current) return;
    gsap.fromTo(nodesRef.current, { opacity: 0, y: -15 }, {
      opacity: 1, y: 0, duration: 0.4, ease: 'power2.out',
    });
  }, { scope: sectionRef, dependencies: [activeProduct] });

  return (
    <section ref={sectionRef} id="origin-timeline" className="bg-warm-cream py-16 md:py-24">
      <div className="max-w-5xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <SectionEyebrow text="CO-CREATION TIMELINE" />

        {/* Title */}
        <h2 className="font-serif-zh text-archive-brown mb-4" style={{ fontSize: 'clamp(1.25rem, 3vw, 2rem)' }}>
          七段共创时间轴
        </h2>
        <p className="text-sm font-sans-zh text-archive-brown-60 mb-10 md:mb-14">
          {productData.coreSentence}
        </p>

        {/* Timeline Nodes */}
        <div ref={nodesRef} className="relative space-y-8 md:space-y-10">
          {/* Group: 进山 */}
          <div className="flex items-center gap-3 py-2 px-4 rounded-full w-fit" style={{ backgroundColor: groupStyles[0].labelBg }}>
            <TreePine size={14} style={{ color: groupStyles[0].color }} />
            <span className="text-xs font-sans-zh" style={{ color: groupStyles[0].color }}>进山 · 茶的来处</span>
          </div>
          {nodes.slice(0, 2).map((node) => (
            <div key={`${activeProduct}-${node.nodeNumber}`} className="timeline-node">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 text-lg font-mono-data text-warm-white" style={{ backgroundColor: groupStyles[0].color }}>
                  {String(node.nodeNumber).padStart(2, '0')}
                </div>
                <div className="flex-1 min-w-0 pt-1">
                  <NodeCard node={node} isLarge={false} isNode3={false} isNode6={false} productData={productData} />
                </div>
              </div>
            </div>
          ))}

          {/* Group: 制茶 */}
          <div className="flex items-center gap-3 py-2 px-4 rounded-full w-fit" style={{ backgroundColor: groupStyles[1].labelBg }}>
            <Flame size={14} style={{ color: groupStyles[1].color }} />
            <span className="text-xs font-sans-zh" style={{ color: groupStyles[1].color }}>制茶 · 人的手艺</span>
          </div>
          {/* Node 03 — LARGE + ProcessFlow */}
          <div key={`${activeProduct}-3`} className="timeline-node">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center shrink-0 text-xl font-mono-data text-warm-white" style={{ backgroundColor: groupStyles[1].color }}>
                03
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <NodeCard node={nodes[2]} isLarge={true} isNode3={true} isNode6={false} productData={productData} />
              </div>
            </div>
          </div>
          {/* Node 04 */}
          <div key={`${activeProduct}-4`} className="timeline-node">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 text-lg font-mono-data" style={{ backgroundColor: groupStyles[1].color, color: '#3D3229' }}>
                04
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <NodeCard node={nodes[3]} isLarge={false} isNode3={false} isNode6={false} productData={productData} />
              </div>
            </div>
          </div>

          {/* Group: 到你 */}
          <div className="flex items-center gap-3 py-2 px-4 rounded-full w-fit" style={{ backgroundColor: groupStyles[2].labelBg }}>
            <Eye size={14} style={{ color: groupStyles[2].color }} />
            <span className="text-xs font-sans-zh" style={{ color: groupStyles[2].color }}>到你 · 你的身体</span>
          </div>
          {/* Node 05 */}
          <div key={`${activeProduct}-5`} className="timeline-node">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 text-lg font-mono-data text-warm-white" style={{ backgroundColor: groupStyles[2].color }}>
                05
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <NodeCard node={nodes[4]} isLarge={false} isNode3={false} isNode6={false} productData={productData} />
              </div>
            </div>
          </div>
          {/* Node 06 — LARGE + SevenInfusionPath */}
          <div key={`${activeProduct}-6`} className="timeline-node">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center shrink-0 text-xl font-mono-data text-warm-white" style={{ backgroundColor: groupStyles[2].color }}>
                06
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <NodeCard node={nodes[5]} isLarge={true} isNode3={false} isNode6={true} productData={productData} />
              </div>
            </div>
          </div>
          {/* Node 07 — LARGE */}
          <div key={`${activeProduct}-7`} className="timeline-node">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center shrink-0 text-xl font-mono-data text-warm-white" style={{ backgroundColor: groupStyles[2].color }}>
                07
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <NodeCard node={nodes[6]} isLarge={true} isNode3={false} isNode6={false} productData={productData} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
