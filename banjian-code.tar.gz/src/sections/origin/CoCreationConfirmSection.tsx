import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { Check } from 'lucide-react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { sharedConfirmPeople, confirmSummary } from '@/data/shared-confirm';

gsap.registerPlugin(ScrollTrigger);

interface SignatureCardProps {
  role: string;
  name: string;
  responsibility: string;
  confirmTime: string;
  archive?: string;
  index: number;
}

function SignatureCard({ role, name, responsibility, confirmTime, archive, index }: SignatureCardProps) {
  const [expanded, setExpanded] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!cardRef.current) return;
    gsap.fromTo(
      cardRef.current,
      { opacity: 0, y: 20 },
      {
        opacity: 1,
        y: 0,
        duration: 0.5,
        delay: index * 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: cardRef.current,
          start: 'top 88%',
          toggleActions: 'play none none none',
        },
      }
    );
  }, { scope: cardRef });

  return (
    <div
      ref={cardRef}
      className="border-t border-archive-brown-6 py-5 xs:py-6 cursor-pointer hover:border-tea-gold/30 transition-all duration-200"
      onClick={() => archive && setExpanded(!expanded)}
    >
      <div className="text-sm text-archive-brown-60 font-sans-zh mb-1">{role}</div>
      <div className="text-lg font-serif-zh font-semibold text-archive-brown mb-2">{name}</div>
      <p className="text-sm text-archive-brown font-sans-zh leading-relaxed mb-3">
        {responsibility}
      </p>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs text-[#1B4332] font-sans-zh">
          <Check size={14} strokeWidth={2} />
          <span>已确认</span>
        </div>
        <span className="text-xs text-archive-brown-40 font-sans-zh">{confirmTime}</span>
      </div>

      {/* Expandable craftsman profile */}
      {archive && (
        <div
          className="overflow-hidden transition-[height,opacity] duration-200 ease-out"
          style={{ height: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0 }}
        >
          <div className="mt-3 pt-3 border-t border-archive-brown-12 text-xs text-archive-brown-60 font-sans-zh">
            <span className="text-archive-brown-60">监匠档案：</span>
            <span className="text-archive-brown">{archive}</span>
          </div>
        </div>
      )}

      {archive && !expanded && (
        <div className="mt-2 text-[11px] text-archive-brown-40 font-sans-zh">
          点击展开查看档案
        </div>
      )}
    </div>
  );
}

export default function CoCreationConfirmSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!summaryRef.current) return;
    gsap.fromTo(
      summaryRef.current,
      { opacity: 0, y: 20 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: summaryRef.current,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      }
    );
  }, { scope: sectionRef });

  const summaryText = `${confirmSummary.totalPeople}人确认 · ${confirmSummary.totalNodes}段节点 · ${confirmSummary.totalEvidence}项证据`;

  return (
    <section
      ref={sectionRef}
      id="origin-confirm"
      className="bg-warm-cream py-16 md:py-24"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <SectionEyebrow text="CO-CREATION CONFIRMATION" />

        {/* Summary card */}
        <div className="flex justify-center mb-5 md:mb-6">
          <div
            ref={summaryRef}
            className="inline-flex items-center px-6 py-3 rounded-full bg-archive-brown/[0.08] text-sm font-mono-data text-archive-brown"
          >
            {summaryText}
          </div>
        </div>

        {/* Signature cards grid */}
        <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-3 gap-4 xs:gap-5">
          {sharedConfirmPeople.map((person, i) => (
            <SignatureCard
              key={person.role}
              role={person.role}
              name={person.name}
              responsibility={person.responsibility}
              confirmTime={person.confirmTime || '2026年春'}
              archive={person.archive}
              index={i}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
