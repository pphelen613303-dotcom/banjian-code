import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import {
  Droplets, Wind, Hand, Sun, Layers, SunDim,
  Timer, Flame, Mountain, Leaf,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  Droplets, Wind, Hand, Sun, Layers, SunDim, Timer, Flame, Mountain, Leaf,
};

interface ProcessStep {
  icon: string;
  name: string;
  desc: string;
}

interface Props {
  steps: ProcessStep[];
  closing?: { icon: string; title: string; desc: string };
  productLabel: string;
  productSubtitle: string;
  accentColor: string;
}

export default function ProcessFlowCompact({
  steps,
  closing,
  productLabel,
  productSubtitle,
  accentColor,
}: Props) {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.pfc-step', { opacity: 0, y: 12 }, {
      opacity: 1, y: 0, duration: 0.35, stagger: 0.05, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 90%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="py-5">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <p className="text-[10px] font-mono-data tracking-[0.25em] text-archive-brown-40 uppercase">
          CRAFT · 工艺转化
        </p>
        <div className="flex-1 h-[1px] bg-archive-brown-10" />
        <p className="text-[10px] font-sans-zh" style={{ color: accentColor }}>
          {productLabel} · {productSubtitle}
        </p>
      </div>

      {/* Compact step flow */}
      <div className="flex flex-wrap items-center gap-2">
        {steps.map((step, i) => {
          const Icon = iconMap[step.icon] || Sun;
          return (
            <div key={step.name} className="pfc-step flex items-center">
              <div
                className="flex items-center gap-2 px-3 py-2 rounded-lg border transition-all duration-200 hover:shadow-sm"
                style={{
                  borderColor: 'rgba(61,50,41,0.08)',
                  backgroundColor: 'rgba(250,249,247,0.8)',
                }}
              >
                <Icon size={14} style={{ color: accentColor }} strokeWidth={1.5} />
                <div>
                  <p className="text-xs font-serif-zh text-archive-brown leading-none">{step.name}</p>
                  <p className="text-[10px] font-sans-zh text-archive-brown-50 leading-tight mt-0.5">{step.desc}</p>
                </div>
              </div>
              {i < steps.length - 1 && (
                <div className="w-3 h-[1px] bg-archive-brown-10 mx-1" />
              )}
            </div>
          );
        })}

        {/* Closing card */}
        {closing && (
          <>
            <div className="w-3 h-[1px] bg-archive-brown-10 mx-1" />
            <div className="pfc-step">
              <div
                className="flex items-center gap-2 px-3 py-2 rounded-lg border"
                style={{
                  borderColor: `${accentColor}25`,
                  backgroundColor: `${accentColor}08`,
                }}
              >
                {(() => {
                  const ClosingIcon = iconMap[closing.icon] || Leaf;
                  return <ClosingIcon size={14} style={{ color: accentColor }} strokeWidth={1.5} />;
                })()}
                <div>
                  <p className="text-xs font-serif-zh font-medium leading-none" style={{ color: accentColor }}>{closing.title}</p>
                  <p className="text-[10px] font-sans-zh text-archive-brown-50 leading-tight mt-0.5">{closing.desc}</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
