import { useState, useEffect } from 'react';
import { Leaf, Mountain } from 'lucide-react';

interface Props {
  activeProduct: 'bys' | 'bd001';
  onSwitch: (product: 'bys' | 'bd001') => void;
}

/**
 * Left-side floating quick switch — visible only when timeline is in viewport.
 * Desktop: small pill on left edge, expands on hover.
 * Mobile: thinner, stays minimal.
 */
export default function ProductQuickSwitch({ activeProduct, onSwitch }: Props) {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const timelineEl = document.getElementById('origin-timeline');
    if (!timelineEl) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting && entry.intersectionRatio > 0.1);
      },
      { threshold: [0.1, 0.9] }
    );

    observer.observe(timelineEl);
    return () => observer.disconnect();
  }, []);

  if (!isVisible) return null;

  const isBYS = activeProduct === 'bys';

  return (
    <div
      className="fixed left-3 top-1/2 -translate-y-1/2 z-40 hidden md:block"
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      <div
        className="flex flex-col items-center gap-2 rounded-full border px-1.5 py-3 transition-all duration-300"
        style={{
          backgroundColor: 'rgba(250,249,247,0.95)',
          borderColor: 'rgba(61,50,41,0.1)',
          backdropFilter: 'blur(8px)',
          width: isExpanded ? '44px' : '32px',
        }}
      >
        {/* Active indicator dot */}
        <div
          className="w-2 h-2 rounded-full shrink-0 transition-colors duration-300"
          style={{ backgroundColor: isBYS ? '#1B4332' : '#8B6239' }}
        />

        {/* BYS button */}
        <button
          onClick={() => onSwitch('bys')}
          className="w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200"
          style={{
            backgroundColor: isBYS ? 'rgba(27,67,50,0.1)' : 'transparent',
            opacity: isBYS ? 1 : 0.4,
          }}
          title="白莺初霁 BYS001"
        >
          <Leaf size={12} strokeWidth={1.5} style={{ color: '#1B4332' }} />
        </button>

        {/* Divider */}
        <div className="w-3 h-[1px] bg-archive-brown-12" />

        {/* BD001 button */}
        <button
          onClick={() => onSwitch('bd001')}
          className="w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200"
          style={{
            backgroundColor: !isBYS ? 'rgba(139,98,57,0.1)' : 'transparent',
            opacity: !isBYS ? 1 : 0.4,
          }}
          title="石界岩手 BD001"
        >
          <Mountain size={12} strokeWidth={1.5} style={{ color: '#8B6239' }} />
        </button>
      </div>
    </div>
  );
}
