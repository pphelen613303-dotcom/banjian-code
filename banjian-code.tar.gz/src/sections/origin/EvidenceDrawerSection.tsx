import { useState, useCallback, useRef, useEffect } from 'react';
import { Camera, FileText, Video, PenTool, Weight, Check, X, ZoomIn, RotateCcw } from 'lucide-react';
import type { EvidenceItem, TimelineNode, EvidenceStatus } from '@/types';

const statusConfig: Record<EvidenceStatus, { label: string; className: string; tooltip: string }> = {
  verified: {
    label: '真实',
    className: 'bg-[#1B4332] text-white',
    tooltip: '经多方交叉验证，数据真实可信',
  },
  pending: {
    label: '待关联',
    className: 'bg-[#D4A017] text-white',
    tooltip: '证据已收集，待与完整档案关联',
  },
  incomplete: {
    label: '待补全',
    className: 'bg-transparent border border-dashed border-[#999] text-[#999]',
    tooltip: '档案仍在收集中，内容待后续补全',
  },
};

const typeIcons: Record<string, React.ReactNode> = {
  image: <Camera size={14} strokeWidth={1.5} />,
  form: <FileText size={14} strokeWidth={1.5} />,
  video: <Video size={14} strokeWidth={1.5} />,
  signature: <PenTool size={14} strokeWidth={1.5} />,
  weight: <Weight size={14} strokeWidth={1.5} />,
};

const typeLabels: Record<string, string> = {
  image: '图片',
  form: '表单',
  video: '视频',
  signature: '签名',
  weight: '称重',
};

function StatusBadge({ status }: { status: EvidenceStatus }) {
  const [showTooltip, setShowTooltip] = useState(false);
  const config = statusConfig[status];

  return (
    <span
      className="relative inline-block"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <span
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-sans-zh leading-none ${config.className}`}
      >
        {config.label}
      </span>
      {showTooltip && (
        <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2 py-1 bg-archive-brown text-warm-white text-[11px] rounded whitespace-nowrap z-50 font-sans-zh shadow-lg">
          {config.tooltip}
        </span>
      )}
    </span>
  );
}

function Lightbox({ src, onClose }: { src: string; onClose: () => void }) {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white/80 hover:text-white p-2"
        aria-label="关闭"
      >
        <X size={24} strokeWidth={1.5} />
      </button>
      <div
        className="relative max-w-[90vw] max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={src}
          alt="证据图片"
          className="max-w-full max-h-[90vh] object-contain rounded cursor-zoom-in"
          style={{ transform: `scale(${scale})`, transition: 'transform 0.2s ease' }}
          decoding="async"
          onClick={() => setScale((s) => (s === 1 ? 2 : 1))}
        />
        <div className="absolute bottom-2 right-2 flex gap-2">
          <button
            onClick={() => setScale((s) => s + 0.5)}
            className="p-1.5 bg-black/50 text-white rounded hover:bg-black/70"
            aria-label="放大"
          >
            <ZoomIn size={16} />
          </button>
          <button
            onClick={() => setScale(1)}
            className="p-1.5 bg-black/50 text-white rounded hover:bg-black/70"
            aria-label="重置"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

function EvidenceCard({ item }: { item: EvidenceItem }) {
  const [showVideo, setShowVideo] = useState(false);
  const [showOCR, setShowOCR] = useState(false);
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isImage = item.type === 'image';
  const isVideo = item.type === 'video';
  const isSignature = item.type === 'signature';

  // Auto-muted 3s preview for video
  useEffect(() => {
    if (showVideo && videoRef.current) {
      videoRef.current.muted = true;
      videoRef.current.play().catch(() => {});
    }
  }, [showVideo]);

  const handleImageClick = useCallback(() => {
    if (isImage) {
      setLightboxSrc(item.url || '/images/banjian-new/origin/origin-evidence.jpg');
    }
  }, [isImage, item.url]);

  return (
    <>
      <div className="bg-white/70 border border-archive-brown/[0.08] rounded-lg p-4 hover:border-tea-gold/30 transition-colors duration-200">
        {/* Thumbnail area */}
        <div
          className={`relative aspect-video bg-warm-cream rounded-md mb-3 overflow-hidden flex items-center justify-center ${
            isImage ? 'cursor-pointer' : ''
          }`}
          onClick={handleImageClick}
        >
          {isImage && (
            <img
              src={item.url || '/images/banjian-new/origin/origin-evidence.jpg'}
              alt={item.title}
              className="w-full h-full object-cover"
              loading="lazy"
             decoding="async"/>
          )}
          {isVideo && !showVideo && (
            <div
              className="flex flex-col items-center gap-2 cursor-pointer"
              onClick={() => setShowVideo(true)}
            >
              <Video size={32} className="text-archive-brown-60" strokeWidth={1.2} />
              <span className="text-xs text-archive-brown-60 font-sans-zh">点击播放预览</span>
            </div>
          )}
          {isVideo && showVideo && (
            <video
              ref={videoRef}
              src={item.url}
              className="w-full h-full object-cover"
              controls
              loop
              playsInline
            />
          )}
          {(item.type === 'form' || item.type === 'weight') && (
            <div className="flex flex-col items-center gap-2">
              <FileText size={32} className="text-archive-brown-60" strokeWidth={1.2} />
              <span className="text-xs text-archive-brown-60 font-sans-zh">{item.title}</span>
            </div>
          )}
          {isSignature && (
            <div className="flex flex-col items-center gap-2">
              <PenTool size={32} className="text-archive-brown-60" strokeWidth={1.2} />
              <span className="text-xs text-archive-brown-60 font-sans-zh">{item.title}</span>
            </div>
          )}

          {/* Status badge top-right */}
          <div className="absolute top-2 right-2">
            <StatusBadge status={item.status} />
          </div>
        </div>

        {/* Info */}
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-archive-brown-60">{typeIcons[item.type]}</span>
          <span className="text-xs text-archive-brown-60 font-sans-zh">{typeLabels[item.type]}</span>
        </div>
        <h4 className="text-sm font-medium text-archive-brown font-sans-zh mb-1">
          {item.title}
        </h4>
        {item.description && (
          <p className="text-xs text-archive-brown-60 font-sans-zh leading-relaxed">
            {item.description}
          </p>
        )}

        {/* Signature: OCR toggle */}
        {isSignature && (
          <div className="mt-2 pt-2 border-t border-archive-brown-12">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <button
                type="button"
                role="switch"
                aria-checked={showOCR}
                onClick={() => setShowOCR(!showOCR)}
                className={`relative w-8 h-4.5 rounded-full transition-colors duration-200 ${
                  showOCR ? 'bg-deep-green' : 'bg-archive-brown-30'
                }`}
                style={{ height: '18px' }}
              >
                <span
                  className={`absolute top-[2px] left-[2px] w-3.5 h-3.5 bg-white rounded-full transition-transform duration-200 ${
                    showOCR ? 'translate-x-3.5' : 'translate-x-0'
                  }`}
                />
              </button>
              <span className="text-xs text-archive-brown-60 font-sans-zh">显示文字识别</span>
            </label>
            {showOCR && (
              <div className="mt-2 p-2 bg-warm-cream rounded text-xs text-archive-brown-60 font-sans-zh">
                [OCR识别结果将在此显示]
              </div>
            )}
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightboxSrc && <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />}
    </>
  );
}

interface EvidenceDrawerProps {
  node: TimelineNode;
}

export default function EvidenceDrawerSection({ node }: EvidenceDrawerProps) {
  const [expanded, setExpanded] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const [contentHeight, setContentHeight] = useState(0);

  useEffect(() => {
    if (contentRef.current) {
      setContentHeight(contentRef.current.scrollHeight);
    }
  }, [node.evidence]);

  const stats = {
    verified: node.evidence.filter((e) => e.status === 'verified').length,
    pending: node.evidence.filter((e) => e.status === 'pending').length,
    incomplete: node.evidence.filter((e) => e.status === 'incomplete').length,
  };

  const total = node.evidence.length;

  return (
    <div className="mt-4 pt-4 border-t border-archive-brown/[0.06]">
      {/* Collapsed summary */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between py-2 text-left group"
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm font-sans-zh text-archive-brown group-hover:text-tea-gold transition-colors">
            {total}项证据
          </span>
          {/* Evidence type icons */}
          <div className="flex items-center gap-1.5 text-archive-brown-60">
            {Array.from(new Set(node.evidence.map((e) => e.type))).map((t) => (
              <span key={t} className="flex items-center gap-0.5">
                {typeIcons[t]}
                <span className="text-[10px] font-sans-zh">{typeLabels[t]}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Micro stats */}
        <div className="flex items-center gap-2 text-[11px] font-sans-zh shrink-0 ml-2">
          {stats.verified > 0 && (
            <span className="flex items-center gap-0.5 text-[#1B4332]">
              <Check size={10} />{stats.verified}真实
            </span>
          )}
          {stats.pending > 0 && (
            <span className="text-[#D4A017]">{stats.pending}待关联</span>
          )}
          {stats.incomplete > 0 && (
            <span className="text-[#999]">{stats.incomplete}待补全</span>
          )}
          <svg
            className={`text-archive-brown-60 transition-transform duration-300 ml-1 ${expanded ? 'rotate-180' : ''}`}
            width="14"
            height="14"
            viewBox="0 0 14 14"
            fill="none"
          >
            <path d="M3 5L7 9L11 5" stroke="currentColor" strokeWidth="1.2" />
          </svg>
        </div>
      </button>

      {/* Expanded evidence grid */}
      <div
        className="overflow-hidden transition-[height,opacity] duration-300 ease-out"
        style={{
          height: expanded ? contentHeight : 0,
          opacity: expanded ? 1 : 0,
        }}
      >
        <div ref={contentRef} className="pt-3 pb-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {node.evidence.map((item) => (
              <EvidenceCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
