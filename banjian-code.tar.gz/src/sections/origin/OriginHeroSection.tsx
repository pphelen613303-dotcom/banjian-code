import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

export default function OriginHeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const h1Ref = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);

  useGSAP(() => {
    if (!h1Ref.current || !subtitleRef.current) return;

    gsap.fromTo(
      h1Ref.current,
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.7, ease: 'power2.out' }
    );

    gsap.fromTo(
      subtitleRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.6, delay: 0.3, ease: 'power2.out' }
    );
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      id="origin-hero"
      className="relative min-h-[60dvh] flex items-center justify-center overflow-hidden"
    >
      {/* Background image with Ken Burns */}
      <div
        className="absolute inset-0 bg-cover bg-center animate-ken-burns"
        style={{
          backgroundImage: 'url(/images/banjian-new/origin/origin-hero.jpg)',
        }}
      />
      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(to bottom, rgba(61,50,41,0.5), rgba(61,50,41,0.8))',
        }}
      />

      {/* Content */}
      <div className="relative z-10 text-center px-4 xs:px-6 max-w-2xl mx-auto py-16">
        <h1
          ref={h1Ref}
          className="font-serif-zh text-warm-white leading-[1.15] tracking-[0.02em]"
          style={{ fontSize: 'clamp(1.75rem, 5vw, 3rem)' }}
        >
          一杯茶，不是从货架开始的。
        </h1>
        <p
          ref={subtitleRef}
          className="mt-4 text-lg text-warm-white/75 font-sans-zh leading-relaxed max-w-xl mx-auto"
        >
          从古茶树保护、采摘、初制、生产到你的七泡观察，每一个关键节点都被记录。
        </p>
      </div>

      <style>{`
        @keyframes ken-burns {
          0% { transform: scale(1); }
          100% { transform: scale(1.03); }
        }
        .animate-ken-burns {
          animation: ken-burns 10s ease-out forwards;
        }
      `}</style>
    </section>
  );
}
