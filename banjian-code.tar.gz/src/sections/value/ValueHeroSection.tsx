import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ValueHeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const eyebrowRef = useRef<HTMLDivElement>(null);
  const h1Ref = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      tl.fromTo(
        eyebrowRef.current,
        { opacity: 0, y: 15 },
        { opacity: 1, y: 0, duration: 0.3 }
      )
        .fromTo(
          h1Ref.current,
          { opacity: 0, y: 25 },
          { opacity: 1, y: 0, duration: 0.5 },
          0.2
        )
        .fromTo(
          subtitleRef.current,
          { opacity: 0 },
          { opacity: 1, duration: 0.4 },
          0.5
        );

      // Subtle parallax on background
      gsap.to(sectionRef.current, {
        backgroundPositionY: '30%',
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full flex items-center justify-center overflow-hidden"
      style={{
        minHeight: '55vh',
        backgroundImage:
          'linear-gradient(to bottom, rgba(61,50,41,0.45), rgba(61,50,41,0.75)), url(/images/banjian-new/value/value-hero.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center 0%',
      }}
    >
      <div className="relative z-10 text-center px-4 xs:px-6 md:px-8 py-14 md:py-20">
        <div
          ref={eyebrowRef}
          className="text-xs font-sans-zh font-medium uppercase tracking-[0.15em] text-[#D4A853] mb-4"
        >
          VALUE ECOLOGY
        </div>

        <h1
          ref={h1Ref}
          className="font-serif-zh text-[#FAF9F7] leading-[1.15] tracking-[0.02em] mb-6"
          style={{
            fontSize: 'clamp(1.75rem, 5vw, 3rem)',
          }}
        >
          评价一杯茶，有五个维度。
        </h1>

        <p
          ref={subtitleRef}
          className="text-lg font-sans-zh text-[rgba(250,249,247,0.75)] max-w-[560px] mx-auto leading-relaxed"
        >
          你不需要记住术语。只需要记住身体、来源、手艺和钱的去向。
        </p>
      </div>
    </section>
  );
}
