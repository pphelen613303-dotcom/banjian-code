import { useRef } from 'react';
import { Link } from 'react-router';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ValueBottomCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const h2Ref = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        h2Ref.current,
        { opacity: 0, y: 25 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      const ctas = ctaRef.current?.querySelectorAll('.cta-item');
      if (ctas) {
        gsap.fromTo(
          ctas,
          { opacity: 0, y: 15 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: ctaRef.current,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="w-full bg-[#3D3229] py-14 md:py-20"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 text-center">
        <h2
          ref={h2Ref}
          className="font-serif-zh text-[#FAF9F7] mb-5 md:mb-6"
          style={{
            fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
            lineHeight: 1.25,
            letterSpacing: '0.015em',
          }}
        >
          看完价值评价，用身体来验证。
        </h2>

        <div ref={ctaRef} className="flex flex-col items-center gap-4 md:gap-5">
          {/* Primary CTA - solid gold */}
          <Link
            to="/observe"
            className="cta-item w-full md:w-auto inline-flex items-center justify-center px-8 py-3.5 bg-[#D4A853] text-[#3D3229] text-sm font-sans-zh font-medium rounded hover:bg-[#C49A4A] active:scale-[0.98] transition-all duration-200"
          >
            开始七泡观察
          </Link>

          {/* Secondary CTA - outline gold */}
          <Link
            to="/origin"
            className="cta-item w-full md:w-auto inline-flex items-center justify-center px-8 py-3.5 border border-[#D4A853] text-[#D4A853] text-sm font-sans-zh font-medium rounded hover:bg-[#D4A853] hover:text-[#3D3229] active:scale-[0.98] transition-all duration-200"
          >
            查看生命档案
          </Link>

          {/* Tertiary CTA - text link */}
          <Link
            to="/product"
            className="cta-item text-sm font-sans-zh text-[rgba(250,249,247,0.6)] hover:text-[#D4A853] underline underline-offset-4 transition-colors duration-200 mt-2"
          >
            选择观察样本
          </Link>
        </div>
      </div>
    </section>
  );
}
