import { useRef, useState, useEffect } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Leaf,
  Wrench,
  Building2,
  ClipboardCheck,
  Sparkles,
  Truck,
  TreePine,
  RefreshCw,
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

// ---------- DATA ----------

interface FlowItem {
  name: string;
  percent: number;
  amount: number;
}

interface ProductFlowData {
  name: string;
  id: string;
  price: number;
  items: FlowItem[];
}

const productsData: ProductFlowData[] = [
  {
    name: '白莺初霁',
    id: 'BYS001',
    price: 36.9,
    items: [
      { name: '鲜叶', percent: 24.1, amount: 8.89 },
      { name: '工费', percent: 7.3, amount: 2.69 },
      { name: '固定成本', percent: 7.0, amount: 2.58 },
      { name: '溯源', percent: 12.4, amount: 4.58 },
      { name: '品牌', percent: 14.9, amount: 5.50 },
      { name: '物流', percent: 7.0, amount: 2.58 },
      { name: '生态', percent: 9.0, amount: 3.32 },
      { name: '回收', percent: 18.3, amount: 6.73 },
    ],
  },
  {
    name: '石界岩手',
    id: 'BD001',
    price: 29.9,
    items: [
      { name: '鲜叶', percent: 18.1, amount: 5.41 },
      { name: '工费', percent: 13.4, amount: 4.01 },
      { name: '固定成本', percent: 4.7, amount: 1.42 },
      { name: '溯源', percent: 8.1, amount: 2.43 },
      { name: '品牌', percent: 18.1, amount: 5.41 },
      { name: '物流', percent: 7.0, amount: 2.09 },
      { name: '生态', percent: 9.0, amount: 2.69 },
      { name: '回收', percent: 21.5, amount: 6.42 },
    ],
  },
];

// Icon mapping
const iconMap: Record<string, React.ReactNode> = {
  '鲜叶': <Leaf size={20} strokeWidth={1.5} />,
  '工费': <Wrench size={20} strokeWidth={1.5} />,
  '固定成本': <Building2 size={20} strokeWidth={1.5} />,
  '溯源': <ClipboardCheck size={20} strokeWidth={1.5} />,
  '品牌': <Sparkles size={20} strokeWidth={1.5} />,
  '物流': <Truck size={20} strokeWidth={1.5} />,
  '生态': <TreePine size={20} strokeWidth={1.5} />,
  '回收': <RefreshCw size={20} strokeWidth={1.5} />,
};

// ---------- SINGLE BAR ROW ----------

function BarRow({
  item,
  index,
  animated,
  isHighlighted,
}: {
  item: FlowItem;
  index: number;
  animated: boolean;
  isHighlighted: boolean;
}) {
  const barRef = useRef<HTMLDivElement>(null);
  const [barWidth, setBarWidth] = useState(0);

  useEffect(() => {
    if (animated && barRef.current) {
      // Small delay per item
      const timer = setTimeout(() => {
        setBarWidth(item.percent);
      }, index * 100);
      return () => clearTimeout(timer);
    }
  }, [animated, item.percent, index]);

  const percentStr = `${item.percent}%`;
  const amountStr = `¥${item.amount.toFixed(2)}/泡`;

  return (
    <div className="flex items-center gap-3 md:gap-4 py-3">
      {/* Icon */}
      <div
        className="w-[26px] h-[26px] flex items-center justify-center shrink-0 text-[#3D3229]"
        aria-hidden="true"
      >
        {iconMap[item.name] || <Sparkles size={20} strokeWidth={1.5} />}
      </div>

      {/* Name */}
      <div
        className="w-[56px] shrink-0 text-sm font-sans-zh font-medium text-[#3D3229] truncate"
        title={item.name}
      >
        {item.name}
      </div>

      {/* Bar */}
      <div className="flex-1 flex items-center gap-2 md:gap-3 min-w-0">
        <div className="flex-1 h-4 bg-[rgba(61,50,41,0.06)] rounded-lg overflow-hidden">
          <div
            ref={barRef}
            className="h-full rounded-lg transition-all duration-700 ease-out"
            style={{
              width: `${barWidth}%`,
              background: isHighlighted
                ? 'linear-gradient(90deg, #D4A017, #E5B52A)'
                : 'linear-gradient(90deg, #1B4332, #40916c)',
            }}
          />
        </div>
        <span
          className={`text-xs font-sans-zh font-medium shrink-0 min-w-[48px] text-right ${
            isHighlighted ? 'text-[#D4A017]' : 'text-[rgba(61,50,41,0.6)]'
          }`}
        >
          {percentStr}
        </span>
      </div>

      {/* Amount */}
      <div
        className={`w-[72px] shrink-0 text-right text-sm font-mono-data font-medium ${
          isHighlighted ? 'text-[#D4A017]' : 'text-[#3D3229]'
        }`}
      >
        {amountStr}
      </div>
    </div>
  );
}

// ---------- MAIN COMPONENT ----------

export default function EightValueFlowSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<HTMLDivElement>(null);
  const [activeProduct, setActiveProduct] = useState(0);
  const [animated, setAnimated] = useState(false);

  const currentData = productsData[activeProduct];

  // Compute which items have significant difference (>5% difference in percent)
  const getHighlightedItems = (): Set<string> => {
    const highlighted = new Set<string>();
    const bys = productsData[0];
    const bd = productsData[1];
    for (const bysItem of bys.items) {
      const bdItem = bd.items.find((i) => i.name === bysItem.name);
      if (bdItem && Math.abs(bysItem.percent - bdItem.percent) > 5) {
        highlighted.add(bysItem.name);
      }
    }
    return highlighted;
  };

  const highlightedItems = getHighlightedItems();

  useGSAP(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: chartRef.current,
        start: 'top 80%',
        onEnter: () => setAnimated(true),
        once: true,
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Reset animation on tab switch
  const handleTabSwitch = (index: number) => {
    if (index === activeProduct) return;
    setAnimated(false);
    setActiveProduct(index);
    // Small delay then re-animate
    requestAnimationFrame(() => {
      setTimeout(() => setAnimated(true), 50);
    });
  };

  return (
    <section ref={sectionRef} className="w-full bg-[#FAF9F7] py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="mb-5 md:mb-7">
          <div className="text-xs font-sans-zh font-medium uppercase tracking-[0.15em] text-[rgba(61,50,41,0.6)] mb-4">
            VALUE FLOW
          </div>
          <h2
            className="font-serif-zh text-[#3D3229] mb-4"
            style={{
              fontSize: 'clamp(1.75rem, 2.5vw, 2.5rem)',
              lineHeight: 1.25,
              letterSpacing: '0.015em',
            }}
          >
            一泡茶的钱，继续流向哪里？
          </h2>
        </div>

        {/* Product Tab Switcher */}
        <div className="flex items-center gap-0 mb-8 border-b border-[rgba(61,50,41,0.12)]">
          {productsData.map((product, index) => (
            <button
              key={product.id}
              onClick={() => handleTabSwitch(index)}
              className={`relative px-4 md:px-6 py-3 text-base font-serif-zh transition-colors duration-200 ${
                activeProduct === index
                  ? 'text-[#3D3229]'
                  : 'text-[rgba(61,50,41,0.5)] hover:text-[rgba(61,50,41,0.7)]'
              }`}
            >
              {product.name}
              {activeProduct === index && (
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#D4A853] rounded-full" />
              )}
            </button>
          ))}
          <div className="ml-auto text-sm font-sans-zh text-[rgba(61,50,41,0.6)]">
            ¥{currentData.price}/泡
          </div>
        </div>

        {/* Bar Chart */}
        <div ref={chartRef} className="border-t border-archive-brown-6 py-4 md:py-6">
          {/* Column headers (desktop only) */}
          <div className="hidden md:flex items-center gap-3 md:gap-4 pb-3 mb-2 border-b border-[rgba(61,50,41,0.06)]">
            <div className="w-[26px] shrink-0" />
            <div className="w-[56px] shrink-0 text-xs font-sans-zh text-[rgba(61,50,41,0.5)]">
              项目
            </div>
            <div className="flex-1 text-xs font-sans-zh text-[rgba(61,50,41,0.5)]">
              占比
            </div>
            <div className="w-[72px] shrink-0 text-right text-xs font-sans-zh text-[rgba(61,50,41,0.5)]">
              金额
            </div>
          </div>

          {/* Rows */}
          {currentData.items.map((item, index) => (
            <BarRow
              key={item.name}
              item={item}
              index={index}
              animated={animated}
              isHighlighted={highlightedItems.has(item.name)}
            />
          ))}

          {/* Legend for highlighted items */}
          <div className="mt-4 pt-4 border-t border-[rgba(61,50,41,0.06)] flex items-center gap-2">
            <div
              className="w-4 h-4 rounded"
              style={{ background: 'linear-gradient(90deg, #D4A017, #E5B52A)' }}
            />
            <span className="text-xs font-sans-zh text-[rgba(61,50,41,0.5)]">
              标注色表示两款茶差异显著（&gt;5%）的项目
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
