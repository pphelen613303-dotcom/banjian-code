import { useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { treeDimensions } from '@/data/value-tree';

gsap.registerPlugin(ScrollTrigger);

/* ------------------------------------------------------------------ */
/*  COMPONENT                                                         */
/* ------------------------------------------------------------------ */

export default function FiveDimensionSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const treeRef = useRef<HTMLDivElement>(null);
  const disclaimerRef = useRef<HTMLParagraphElement>(null);

  const [activeDim, setActiveDim] = useState<string | null>(null);
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);
  const [mobileDimId, setMobileDimId] = useState<string | null>(null);

  /* ---- hover helpers (desktop only) ---- */
  const handleEnter = (id: string) => setActiveDim(id);
  const handleLeave = () => setActiveDim(null);

  /* ---- click helper ---- */
  const handleClickDim = (id: string) => {
    // Desktop: set hash + scroll to expand section
    if (window.innerWidth >= 768) {
      window.location.hash = `dim=${id}`;
      const el = document.getElementById(`dim-expand-${id}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return;
    }
    // Mobile: open sheet
    setMobileDimId(id);
    setMobileSheetOpen(true);
  };

  const activeData =
    mobileDimId != null
      ? treeDimensions.find((d) => d.id === mobileDimId) ?? null
      : null;

  /* ---- scroll animations ---- */
  useGSAP(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        treeRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: treeRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      const labels =
        treeRef.current?.querySelectorAll('.tree-dim-label');
      if (labels) {
        gsap.fromTo(
          labels,
          { opacity: 0, x: -15 },
          {
            opacity: 1,
            x: 0,
            duration: 0.5,
            stagger: 0.1,
            delay: 0.5,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: treeRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      gsap.fromTo(
        disclaimerRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.5,
          delay: 0.8,
          scrollTrigger: {
            trigger: disclaimerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ---- derived ---- */
  const dimHighlighted = (id: string) => activeDim === id;
  const dimDimmed = (id: string) =>
    activeDim !== null && activeDim !== id;

  return (
    <section ref={sectionRef} className="w-full bg-warm-cream py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* ---------- Header ---------- */}
        <div ref={headerRef} className="mb-8 md:mb-10">
          <h2
            className="font-serif-zh text-archive-brown mb-4"
            style={{
              fontSize: 'clamp(1.75rem, 2.5vw, 2.5rem)',
              lineHeight: 1.25,
              letterSpacing: '0.015em',
            }}
          >
            不只问好不好喝
          </h2>
          <p className="text-base font-sans-zh text-archive-brown-60 leading-relaxed max-w-xl">
            这五个维度，带你看清一杯古树茶的完整状态。
          </p>
        </div>

        {/* ---------- Tree Diagram ---------- */}
        <div
          ref={treeRef}
          className="relative w-full select-none"
          onMouseLeave={handleLeave}
        >
          {/* Background image */}
          <img
            src="/images/value-tree-no-text.png"
            alt="古树茶五维生命图"
            className="w-full h-auto block rounded-lg"
            draggable={false}
           decoding="async"/>

          {/* Hotspots removed — labels are the only interaction entry */}

          {/* ---- Desktop: side labels ---- */}
          <div className="hidden md:block">
            {treeDimensions.map((dim) => {
              const highlighted = dimHighlighted(dim.id);
              const dimmed = dimDimmed(dim.id);

              return (
                <div
                  key={`lbl-${dim.id}`}
                  className={`tree-dim-label absolute cursor-pointer transition-all duration-300 ${
                    dim.label.side === 'left'
                      ? 'left-[4%] text-left'
                      : 'right-[4%] text-right'
                  }`}
                  style={{
                    top: dim.label.top,
                    opacity: dimmed ? 0.35 : 1,
                    transform: highlighted
                      ? 'scale(1.03)'
                      : 'scale(1)',
                  }}
                  onMouseEnter={() => handleEnter(dim.id)}
                  onMouseLeave={handleLeave}
                  onClick={() => handleClickDim(dim.id)}
                >
                  {/* Number */}
                  <span
                    className="inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-mono-data mb-1.5"
                    style={{
                      backgroundColor: highlighted
                        ? dim.color
                        : `${dim.color}18`,
                      color: highlighted ? '#fff' : dim.color,
                      transition: 'all 0.3s ease',
                    }}
                  >
                    {dim.num}
                  </span>

                  {/* Name */}
                  <h4
                    className="font-serif-zh text-lg lg:text-xl leading-snug"
                    style={{ color: highlighted ? dim.color : '#3D3229' }}
                  >
                    {dim.name}
                  </h4>

                  {/* Core judgment */}
                  <p
                    className="text-sm font-sans-zh mt-0.5"
                    style={{
                      color: highlighted
                        ? 'rgba(61,50,41,0.75)'
                        : 'rgba(61,50,41,0.45)',
                    }}
                  >
                    {dim.coreJudgment}
                  </p>

                  {/* Leader line */}
                  <div
                    className="absolute top-[50%] transition-all duration-300"
                    style={{
                      [dim.label.side === 'left'
                        ? 'right'
                        : 'left']: '100%',
                      width: highlighted ? '40px' : '24px',
                      height: '1px',
                      backgroundColor: highlighted
                        ? dim.color
                        : 'rgba(61,50,41,0.12)',
                      opacity: highlighted ? 0.6 : 0.4,
                      marginTop: '-0.5px',
                      marginLeft:
                        dim.label.side === 'right' ? '8px' : undefined,
                      marginRight:
                        dim.label.side === 'left' ? '8px' : undefined,
                    }}
                  />
                </div>
              );
            })}
          </div>

          {/* ---- Mobile: labels in surrounding whitespace ---- */}
          <div className="md:hidden pointer-events-none">
            {treeDimensions.map((dim) => {
              // Position in whitespace around tree, matching reference image
              const pos: Record<string, { side: 'left' | 'right'; top: string }> = {
                sensory: { side: 'left', top: '14%' },
                body: { side: 'left', top: '38%' },
                information: { side: 'right', top: '18%' },
                cultural: { side: 'right', top: '44%' },
                ethics: { side: 'right', top: '70%' },
              };
              const p = pos[dim.id];
              return (
                <button
                  key={`mob-lbl-${dim.id}`}
                  onClick={() => handleClickDim(dim.id)}
                  className={`absolute pointer-events-auto text-left transition-opacity ${
                    dimDimmed(dim.id) ? 'opacity-35' : 'opacity-100'
                  }`}
                  style={{
                    [p.side]: '2%',
                    top: p.top,
                  }}
                >
                  <span
                    className="inline-flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-mono-data mb-1"
                    style={{
                      backgroundColor: dimHighlighted(dim.id) ? dim.color : `${dim.color}18`,
                      color: dimHighlighted(dim.id) ? '#fff' : dim.color,
                    }}
                  >
                    {dim.num}
                  </span>
                  <div
                    className="font-serif-zh text-sm leading-tight"
                    style={{ color: dimHighlighted(dim.id) ? dim.color : '#3D3229' }}
                  >
                    {dim.name}
                  </div>
                </button>
              );
            })}
          </div>

          {/* ---- Desktop Hover Tooltip ---- */}
          {activeDim && (
            <DesktopTooltip
              dim={
                treeDimensions.find((d) => d.id === activeDim)!
              }
              onClose={handleLeave}
            />
          )}
        </div>

        {/* ---------- Disclaimer ---------- */}
        <p
          ref={disclaimerRef}
          className="text-xs font-sans-zh text-archive-brown-40 text-center mt-8 md:mt-10"
        >
          这不是评分系统。每个维度只描述状态，不给出0-100的分数。
        </p>
      </div>

      {/* ---------- Mobile Bottom Sheet ---------- */}
      <Sheet open={mobileSheetOpen} onOpenChange={setMobileSheetOpen}>
        <SheetContent
          side="bottom"
          className="h-[70vh] rounded-t-2xl bg-warm-cream border-t border-archive-brown-6 p-0"
        >
          {activeData && (
            <div className="flex flex-col h-full overflow-hidden">
              <SheetHeader className="shrink-0 pb-4 border-b border-archive-brown-6 mb-4 px-6 pt-6">
                <div className="flex items-center gap-3">
                  <span
                    className="inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-mono-data text-white"
                    style={{ backgroundColor: activeData.color }}
                  >
                    {activeData.num}
                  </span>
                  <SheetTitle className="font-serif-zh text-xl text-[#3D3229]">
                    {activeData.name}
                  </SheetTitle>
                </div>
                <p
                  className="text-sm font-sans-zh mt-1"
                  style={{ color: activeData.color }}
                >
                  {activeData.coreJudgment}
                </p>
              </SheetHeader>

              <div className="flex-1 overflow-y-auto px-6 pb-8">
                <p className="text-sm font-sans-zh text-[rgba(61,50,41,0.75)] leading-relaxed">
                  {activeData.description}
                </p>

                <button
                  onClick={() => setMobileSheetOpen(false)}
                  className="w-full mt-6 py-3 rounded-lg text-sm font-sans-zh font-medium bg-[rgba(61,50,41,0.06)] text-[#3D3229] hover:bg-[rgba(61,50,41,0.1)] transition-colors"
                >
                  关闭
                </button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  DESKTOP TOOLTIP  — short intro only                               */
/* ------------------------------------------------------------------ */

function DesktopTooltip({
  dim,
  onClose,
}: {
  dim: (typeof treeDimensions)[number];
  onClose: () => void;
}) {
  const isLeft = dim.label.side === 'left';

  return (
    <div
      className="hidden md:block absolute z-30 pointer-events-none"
      style={{
        [isLeft ? 'left' : 'right']: '22%',
        top: `calc(${dim.label.top} + 20px)`,
        maxWidth: '320px',
        width: '28vw',
      }}
    >
      <div
        className="bg-white/95 backdrop-blur-sm rounded-xl border p-5 pointer-events-auto"
        style={{
          borderColor: `${dim.color}30`,
          boxShadow: `0 8px 32px rgba(61,50,41,0.08), 0 0 0 1px ${dim.color}15`,
        }}
        onMouseEnter={onClose}
      >
        {/* Header */}
        <div className="flex items-center gap-2.5 mb-3">
          <span
            className="inline-flex items-center justify-center w-7 h-7 rounded-full text-[10px] font-mono-data text-white"
            style={{ backgroundColor: dim.color }}
          >
            {dim.num}
          </span>
          <h5 className="font-serif-zh text-base text-[#3D3229]">
            {dim.name}
          </h5>
        </div>

        {/* Core judgment */}
        <p
          className="text-xs font-sans-zh mb-3"
          style={{ color: dim.color }}
        >
          {dim.coreJudgment}
        </p>

        {/* Divider */}
        <div
          className="w-full h-px mb-3"
          style={{ backgroundColor: `${dim.color}20` }}
        />

        {/* Short description */}
        <p className="text-sm font-sans-zh text-[rgba(61,50,41,0.7)] leading-relaxed">
          {dim.description}
        </p>
      </div>
    </div>
  );
}
