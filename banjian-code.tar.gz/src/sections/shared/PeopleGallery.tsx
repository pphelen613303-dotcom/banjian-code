import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { coCreationPeople } from '@/data/coCreationData';

gsap.registerPlugin(ScrollTrigger);

export default function PeopleGallery() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.pg-person', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.12, ease: 'power2.out',
      scrollTrigger: { trigger: '.pg-people', start: 'top 85%' },
    });
  }, { scope: sectionRef });

  return (
    <div ref={sectionRef} className="w-full py-12 md:py-16" style={{ backgroundColor: '#FAF9F7' }}>
      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <div className="pg-people flex flex-wrap justify-center gap-6 md:gap-10">
          {coCreationPeople.map((person) => (
            <div key={person.name} className="pg-person flex flex-col items-center text-center max-w-[100px]">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full overflow-hidden border-2 border-tea-gold/60 mb-3">
                <img
                  src={person.image}
                  alt={person.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                 decoding="async"/>
              </div>
              <p className="text-sm font-serif-zh font-medium text-archive-brown">{person.name}</p>
              <p className="text-xs font-sans-zh" style={{ color: '#8B6239' }}>{person.role}</p>
              <p className="text-[11px] font-sans-zh text-archive-brown-50 mt-1">{person.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
