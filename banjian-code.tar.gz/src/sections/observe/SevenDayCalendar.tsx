import { useState } from 'react';
import { Check } from 'lucide-react';
import { teaObserveDays } from '@/data/experience';

interface SevenDayCalendarProps {
  currentDay: number;
  onDayClick: (day: number) => void;
}

export default function SevenDayCalendar({
  currentDay,
  onDayClick,
}: SevenDayCalendarProps) {
  const [activeDay, setActiveDay] = useState<number>(currentDay);

  const handleDayClick = (day: number) => {
    setActiveDay(day);
    onDayClick(day);
  };

  return (
    <section
      id="observe-calendar"
      className="max-w-[600px] mx-auto px-4 xs:px-6 mt-6"
    >
      {/* Desktop: 1 row × 7 columns */}
      <div className="hidden xs:flex items-center justify-center gap-3">
        {teaObserveDays.map((dayData) => {
          const isActive = activeDay === dayData.day;

          return (
            <div key={dayData.day} className="flex flex-col items-center gap-2">
              <button
                onClick={() => handleDayClick(dayData.day)}
                className="relative flex items-center justify-center rounded-full transition-all duration-200 focus:outline-none hover:scale-110"
                style={{
                  width: '44px',
                  height: '44px',
                  background: isActive ? '#3D3229' : '#E8E4DF',
                  color: isActive ? '#FAF9F7' : '#3D3229',
                  boxShadow: isActive
                    ? '0 0 8px rgba(212,168,83,0.4)'
                    : 'none',
                  cursor: 'pointer',
                }}
                aria-label={`Day ${dayData.day}`}
              >
                {dayData.day < activeDay ? (
                  <Check size={16} strokeWidth={2} />
                ) : (
                  <span className="text-sm font-sans-zh font-medium">
                    {dayData.day}
                  </span>
                )}
              </button>
              <span
                className="text-xs font-sans-zh transition-colors duration-200"
                style={{
                  color: isActive ? '#3D3229' : 'rgba(61,50,41,0.5)',
                  fontWeight: isActive ? 500 : 400,
                }}
              >
                Day {dayData.day}
              </span>
            </div>
          );
        })}
      </div>

      {/* Mobile: 2 rows (3+4) */}
      <div className="flex xs:hidden flex-col items-center gap-3">
        {/* First row: days 1-3 */}
        <div className="flex items-center justify-center gap-3">
          {teaObserveDays.slice(0, 3).map((dayData) => {
            const isActive = activeDay === dayData.day;

            return (
              <div key={dayData.day} className="flex flex-col items-center gap-1.5">
                <button
                  onClick={() => handleDayClick(dayData.day)}
                  className="relative flex items-center justify-center rounded-full transition-all duration-200 focus:outline-none hover:scale-110"
                  style={{
                    width: '44px',
                    height: '44px',
                    background: isActive ? '#3D3229' : '#E8E4DF',
                    color: isActive ? '#FAF9F7' : '#3D3229',
                    boxShadow: isActive
                      ? '0 0 8px rgba(212,168,83,0.4)'
                      : 'none',
                    cursor: 'pointer',
                  }}
                  aria-label={`Day ${dayData.day}`}
                >
                  {dayData.day < activeDay ? (
                    <Check size={16} strokeWidth={2} />
                  ) : (
                    <span className="text-sm font-sans-zh font-medium">
                      {dayData.day}
                    </span>
                  )}
                </button>
                <span
                  className="text-xs font-sans-zh"
                  style={{
                    color: isActive ? '#3D3229' : 'rgba(61,50,41,0.5)',
                    fontWeight: isActive ? 500 : 400,
                  }}
                >
                  Day {dayData.day}
                </span>
              </div>
            );
          })}
        </div>

        {/* Second row: days 4-7 */}
        <div className="flex items-center justify-center gap-3">
          {teaObserveDays.slice(3).map((dayData) => {
            const isActive = activeDay === dayData.day;

            return (
              <div key={dayData.day} className="flex flex-col items-center gap-1.5">
                <button
                  onClick={() => handleDayClick(dayData.day)}
                  className="relative flex items-center justify-center rounded-full transition-all duration-200 focus:outline-none hover:scale-110"
                  style={{
                    width: '44px',
                    height: '44px',
                    background: isActive ? '#3D3229' : '#E8E4DF',
                    color: isActive ? '#FAF9F7' : '#3D3229',
                    boxShadow: isActive
                      ? '0 0 8px rgba(212,168,83,0.4)'
                      : 'none',
                    cursor: 'pointer',
                  }}
                  aria-label={`Day ${dayData.day}`}
                >
                  {dayData.day < activeDay ? (
                    <Check size={16} strokeWidth={2} />
                  ) : (
                    <span className="text-sm font-sans-zh font-medium">
                      {dayData.day}
                    </span>
                  )}
                </button>
                <span
                  className="text-xs font-sans-zh"
                  style={{
                    color: isActive ? '#3D3229' : 'rgba(61,50,41,0.5)',
                    fontWeight: isActive ? 500 : 400,
                  }}
                >
                  Day {dayData.day}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
