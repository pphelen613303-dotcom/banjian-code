import { useState, useEffect, useCallback, useRef } from 'react';
import gsap from 'gsap';
import { submitDailyRecord, checkHealth } from '@/data/feishu-api';
import type { ObservationRecord } from '@/types';

/* ------------------------------------------------------------------ */
/*  Day-specific feeling tags — synced with 7Day themes               */
/* ------------------------------------------------------------------ */

const DAY_TAGS: Record<number, string[]> = {
  1: ['甜', '清', '雅', '浓', '淡', '持久', '累', '舒服'],        // 香气：嗅觉层次
  2: ['苦', '涩', '甜', '滑', '刺激', '柔和', '饱满', '单薄'],      // 滋味：味觉口感
  3: ['顺', '干', '润', '厚', '薄', '紧', '滑', '舒服'],            // 咽喉：顺滑度
  4: ['暖', '松', '沉', '浮', '紧', '舒服', '清', '热'],            // 身体：整体反应
  5: ['静', '安', '缓', '急', '烦', '淡', '稳', '舒服'],            // 情绪：心情状态
  6: ['浓', '淡', '变', '稳', '长', '短', '层次', '舒服'],           // 七泡：层次持久
  7: ['敏', '钝', '变', '稳', '深', '浅', '清', '舒服'],            // 复盘：自我认知
};

/* ------------------------------------------------------------------ */
/*  Tea options                                                         */
/* ------------------------------------------------------------------ */

const TEA_OPTIONS = [
  { key: 'bys' as const, label: '白莺初霁' },
  { key: 'bd001' as const, label: '石界岩手' },
  { key: 'custom' as const, label: '其他茶品' },
];

/* ------------------------------------------------------------------ */

interface RecordFormSectionProps {
  currentDay: number;
  teaType: 'bys' | 'bd001' | 'custom';
  customTeaName: string;
  onTeaTypeChange: (type: 'bys' | 'bd001' | 'custom') => void;
  onCustomTeaNameChange: (name: string) => void;
}

function generateId(): string {
  return `record_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function getSessionId(): string {
  let sid = sessionStorage.getItem('banjian_session_id');
  if (!sid) {
    sid = `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    sessionStorage.setItem('banjian_session_id', sid);
  }
  return sid;
}

export default function RecordFormSection({
  currentDay,
  teaType,
  customTeaName,
  onTeaTypeChange,
  onCustomTeaNameChange,
}: RecordFormSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const [bodyFeeling, setBodyFeeling] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [status, setStatus] = useState<'editing' | 'local-preview' | 'submitting' | 'submitted' | 'error'>('editing');
  const [previewRecord, setPreviewRecord] = useState<ObservationRecord | null>(null);
  const [backendStatus, setBackendStatus] = useState<'unknown' | 'online' | 'offline'>('unknown');
  const [submitMessage, setSubmitMessage] = useState('');

  const draftKey = `banjian_observe_draft_day_${currentDay}`;
  const feelingTags = DAY_TAGS[currentDay] || DAY_TAGS[1];

  // Check backend health
  useEffect(() => {
    checkHealth()
      .then(() => setBackendStatus('online'))
      .catch(() => setBackendStatus('offline'));
  }, []);

  // Restore draft
  useEffect(() => {
    try {
      const saved = localStorage.getItem(draftKey);
      if (saved) {
        const draft = JSON.parse(saved);
        if (draft.bodyFeeling) setBodyFeeling(draft.bodyFeeling);
        if (draft.selectedTags) setSelectedTags(draft.selectedTags);
      }
    } catch { /* ignore */ }
  }, [draftKey]);

  // Auto-save draft
  useEffect(() => {
    const timeout = setTimeout(() => {
      const draft = { bodyFeeling, selectedTags, savedAt: Date.now() };
      localStorage.setItem(draftKey, JSON.stringify(draft));
    }, 500);
    return () => clearTimeout(timeout);
  }, [bodyFeeling, selectedTags, draftKey]);

  // ===== CRITICAL: Reset form when day changes =====
  useEffect(() => {
    setStatus('editing');
    setPreviewRecord(null);
    setSubmitMessage('');
    // Restore draft for the new day (already handled by the draft restore effect above)
    try {
      const saved = localStorage.getItem(draftKey);
      if (saved) {
        const draft = JSON.parse(saved);
        setBodyFeeling(draft.bodyFeeling || '');
        setSelectedTags(draft.selectedTags || []);
      } else {
        setBodyFeeling('');
        setSelectedTags([]);
      }
    } catch {
      setBodyFeeling('');
      setSelectedTags([]);
    }
  }, [currentDay, draftKey]);

  // Scroll animation
  useEffect(() => {
    if (!cardRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(cardRef.current, { opacity: 0, y: 20 }, {
        opacity: 1, y: 0, duration: 0.6, ease: 'power2.out',
        scrollTrigger: { trigger: cardRef.current, start: 'top 85%', toggleActions: 'play none none none' },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const toggleTag = useCallback((tag: string) => {
    setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
  }, []);

  const createRecord = useCallback(
    (recordStatus: 'local-preview' | 'submitted' | 'syncing'): ObservationRecord => {
      return {
        id: generateId(),
        source: 'seven-day',
        teaType,
        customTeaName: teaType === 'custom' ? customTeaName : undefined,
        dayNumber: currentDay,
        bodyFeeling: bodyFeeling.trim() || '(未填写)',
        feelingTags: selectedTags,
        status: recordStatus,
        createdAt: new Date().toISOString(),
        deviceType: window.innerWidth < 768 ? 'mobile' : 'desktop',
        screenWidth: window.innerWidth,
        sourcePage: 'observe',
        sessionId: getSessionId(),
        syncStatus: recordStatus === 'submitted' ? 'synced' : 'local-only',
      };
    },
    [teaType, customTeaName, currentDay, bodyFeeling, selectedTags]
  );

  const saveToLocal = useCallback((record: ObservationRecord) => {
    const existing = JSON.parse(localStorage.getItem('banjian_observe_records') || '[]');
    existing.push(record);
    localStorage.setItem('banjian_observe_records', JSON.stringify(existing));
  }, []);

  const handlePreview = useCallback(() => {
    const record = createRecord('local-preview');
    saveToLocal(record);
    setPreviewRecord(record);
    setStatus('local-preview');
  }, [createRecord, saveToLocal]);

  const handleSubmit = useCallback(async () => {
    if (!bodyFeeling.trim()) {
      setSubmitMessage('请填写身体感受');
      setTimeout(() => setSubmitMessage(''), 2000);
      return;
    }

    setStatus('submitting');
    setSubmitMessage('正在提交...');

    try {
      const res = await submitDailyRecord({
        day: currentDay,
        tea_type: teaType,
        custom_tea_name: teaType === 'custom' ? customTeaName : undefined,
        body_feeling: bodyFeeling.trim(),
        feeling_tags: selectedTags,
        content: `Day ${currentDay} 观察记录 - ${teaType === 'custom' ? (customTeaName || '自选茶') : teaType === 'bys' ? '白莺初霁' : '石界岩手'}`,
      });

      const record = createRecord('submitted');
      saveToLocal(record);
      setPreviewRecord(record);

      if (res.success) {
        setStatus('submitted');
        setSubmitMessage('提交成功');
        localStorage.removeItem(draftKey);
      } else {
        setStatus('submitted');
        setSubmitMessage('已保存（服务端响应异常，数据已备份至本地）');
      }
    } catch {
      const record = createRecord('submitted');
      saveToLocal(record);
      setPreviewRecord(record);
      setStatus('submitted');
      setSubmitMessage('网络暂时不可用，记录已保存至本地，后续可同步');
    }
  }, [currentDay, teaType, customTeaName, bodyFeeling, selectedTags, createRecord, saveToLocal, draftKey]);

  const handleEditAgain = useCallback(() => {
    setStatus('editing');
    setPreviewRecord(null);
    setSubmitMessage('');
  }, []);

  // Get record prompt from dayGuides
  const dayPrompts: Record<number, string> = {
    1: '这杯茶的香气，让我感觉……',
    2: '第一口最明显的是……它让我……',
    3: '这杯茶经过喉咙时，我感觉……',
    4: '这杯茶，我的身体接住了吗？为什么？',
    5: '喝茶前我……喝完后我……',
    6: '喝到后面，它还留下了……',
    7: '这七天，我通过茶看见了自己……',
  };

  return (
    <section ref={sectionRef} id="observe-record" className="max-w-[600px] mx-auto px-4 xs:px-6 mt-6 mb-6">
      <div
        ref={cardRef}
        className="opacity-0 bg-white/70 rounded-lg p-5 xs:p-6"
        style={{ border: '1px solid rgba(61,50,41,0.08)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-serif-zh text-lg text-archive-brown font-semibold">
            写下今天的观察
          </h3>
          <span className="text-xs font-mono-data" style={{
            color: backendStatus === 'online' ? '#1B4332' : backendStatus === 'offline' ? '#C17B5F' : '#999',
          }}>
            <span className="inline-block w-1.5 h-1.5 rounded-full mr-1" style={{
              background: backendStatus === 'online' ? '#1B4332' : backendStatus === 'offline' ? '#C17B5F' : '#999',
            }} />
            {backendStatus === 'online' ? '已连接' : backendStatus === 'offline' ? '离线' : '检查中'}
          </span>
        </div>

        {/* ===== EDITING STATE ===== */}
        {status === 'editing' && (
          <div className="space-y-4">
            {/* Tea Selection */}
            <div>
              <label className="block text-xs font-sans-zh mb-2 text-archive-brown-50">选择茶品</label>
              <div className="flex gap-2 flex-wrap">
                {TEA_OPTIONS.map(option => {
                  const isActive = teaType === option.key;
                  return (
                    <button
                      key={option.key}
                      onClick={() => onTeaTypeChange(option.key)}
                      className="font-sans-zh text-sm px-4 py-2 rounded transition-all duration-200"
                      style={{
                        border: isActive ? '1px solid #D4A853' : '1px solid rgba(61,50,41,0.15)',
                        background: isActive ? 'rgba(212,168,83,0.15)' : 'transparent',
                        color: isActive ? '#3D3229' : 'rgba(61,50,41,0.6)',
                        fontWeight: isActive ? 500 : 400,
                      }}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
              {teaType === 'custom' && (
                <input
                  type="text"
                  value={customTeaName}
                  onChange={e => onCustomTeaNameChange(e.target.value)}
                  placeholder="输入茶品名称..."
                  className="mt-2 w-full font-sans-zh text-sm px-3 py-2 rounded"
                  style={{ border: '1px solid rgba(61,50,41,0.15)', color: '#3D3229' }}
                />
              )}
            </div>

            {/* Body Feeling */}
            <div>
              <label className="block text-xs font-sans-zh mb-1.5 text-archive-brown-50">身体感受</label>
              <textarea
                value={bodyFeeling}
                onChange={e => setBodyFeeling(e.target.value)}
                placeholder={dayPrompts[currentDay] || '写下你当下的感受...'}
                rows={3}
                className="w-full font-sans-zh text-sm px-4 py-3 rounded resize-none"
                style={{ border: '1px solid rgba(61,50,41,0.15)', color: '#3D3229' }}
              />
            </div>

            {/* Feeling Tags — day-specific */}
            <div>
              <label className="block text-xs font-sans-zh mb-1.5 text-archive-brown-50">
                感受标签（Day {currentDay}）
              </label>
              <div className="flex flex-wrap gap-2">
                {feelingTags.map(tag => {
                  const isSelected = selectedTags.includes(tag);
                  return (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className="font-sans-zh text-sm px-3 py-1 rounded-full transition-all duration-150"
                      style={{
                        border: isSelected ? '1px solid #D4A853' : '1px solid rgba(61,50,41,0.15)',
                        background: isSelected ? 'rgba(212,168,83,0.15)' : 'transparent',
                        color: isSelected ? '#3D3229' : 'rgba(61,50,41,0.6)',
                      }}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col xs:flex-row gap-2 pt-1">
              <button onClick={handlePreview}
                className="flex-1 font-sans-zh text-sm px-6 py-3 rounded"
                style={{ border: '1px solid #3D3229', background: 'transparent', color: '#3D3229', fontWeight: 500 }}>
                预览
              </button>
              <button onClick={handleSubmit}
                className="flex-1 font-sans-zh text-sm px-6 py-3 rounded"
                style={{ background: '#3D3229', color: '#FAF9F7', fontWeight: 500 }}>
                提交
              </button>
            </div>

            {submitMessage && (
              <p className="text-xs text-red-pine-clay text-center">{submitMessage}</p>
            )}
          </div>
        )}

        {/* ===== SUBMITTING ===== */}
        {status === 'submitting' && (
          <div className="py-8 text-center">
            <div className="inline-block w-6 h-6 border-2 border-archive-brown-20 border-t-archive-brown rounded-full animate-spin mb-3" />
            <p className="text-sm text-archive-brown-60 font-sans-zh">正在提交...</p>
          </div>
        )}

        {/* ===== LOCAL PREVIEW ===== */}
        {status === 'local-preview' && previewRecord && (
          <div className="space-y-3">
            <div className="p-4 rounded-lg" style={{ background: '#FAF9F7', border: '1px solid rgba(61,50,41,0.08)' }}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs font-sans-zh px-2 py-0.5 rounded-full" style={{ background: 'rgba(212,168,83,0.2)', color: '#3D3229' }}>
                  仅你可见的预览
                </span>
              </div>
              <RecordDisplay record={previewRecord} />
            </div>
            <button onClick={handleEditAgain} className="font-sans-zh text-sm text-tea-gold hover:underline">
              继续编辑
            </button>
          </div>
        )}

        {/* ===== SUBMITTED — with encouragement message ===== */}
        {status === 'submitted' && previewRecord && (
          <div className="space-y-3">
            <div className="p-4 rounded-lg" style={{ background: 'rgba(27,67,50,0.06)', border: '1px solid rgba(27,67,50,0.15)' }}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs font-sans-zh px-2 py-0.5 rounded-full" style={{ background: '#1B4332', color: '#fff' }}>
                  已提交
                </span>
                {submitMessage && (
                  <span className="text-xs font-sans-zh text-archive-brown-40">{submitMessage}</span>
                )}
              </div>
              <RecordDisplay record={previewRecord} />

              {/* ===== Encouragement message ===== */}
              <div className="mt-4 pt-3 border-t" style={{ borderColor: 'rgba(27,67,50,0.1)' }}>
                <p className="font-sans-zh text-xs leading-relaxed" style={{ color: 'rgba(27,67,50,0.7)' }}>
                  感谢你的记录。每一杯茶的观察都是对自己身体的更深了解。
                  我们会定期整理茶友们的记录，为大家提供阶段性观察分析与反馈。
                  坚持记录，你会慢慢发现自己对茶的感知越来越清晰。
                </p>
              </div>
            </div>
            <button onClick={handleEditAgain} className="font-sans-zh text-sm text-tea-gold hover:underline">
              再写一条
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

/* ---- Sub-component: record display ---- */
function RecordDisplay({ record }: { record: ObservationRecord }) {
  return (
    <div className="space-y-2 text-sm font-sans-zh">
      <p className="text-archive-brown">
        <span className="text-archive-brown-40">茶品：</span>
        {record.teaType === 'custom' ? (record.customTeaName || '自选茶') : record.teaType === 'bys' ? '白莺初霁' : '石界岩手'}
      </p>
      <p className="text-archive-brown">
        <span className="text-archive-brown-40">Day：</span>
        {record.dayNumber}
      </p>
      <p className="text-archive-brown">
        <span className="text-archive-brown-40">感受：</span>
        {record.bodyFeeling}
      </p>
      {record.feelingTags.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {record.feelingTags.map(tag => (
            <span key={tag} className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(212,168,83,0.15)', color: '#3D3229', border: '1px solid #D4A853' }}>
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
