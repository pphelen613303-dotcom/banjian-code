import { useState } from 'react';
import { getDayAdvanced } from '@/data/day-advanced';

interface AdvancedContentSectionProps {
  currentDay: number;
}

export default function AdvancedContentSection({ currentDay }: AdvancedContentSectionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const items = getDayAdvanced(currentDay);

  const toggle = (index: number) => {
    setOpenIndex((prev) => (prev === index ? null : index));
  };

  return (
    <section
      id="observe-advanced"
      className="max-w-[720px] mx-auto px-4 xs:px-6 py-6 mb-8"
    >
      {/* Section eyebrow */}
      <div className="flex items-center gap-3 mb-4">
        <div className="h-px flex-1" style={{ background: 'rgba(61,50,41,0.12)' }} />
        <span className="text-xs font-mono-data tracking-[0.15em]" style={{ color: 'rgba(61,50,41,0.4)' }}>
          深入了解
        </span>
        <div className="h-px flex-1" style={{ background: 'rgba(61,50,41,0.12)' }} />
      </div>

      {/* Accordion */}
      <div className="space-y-0">
        {items.map((item, index) => {
          const isOpen = openIndex === index;
          return (
            <div
              key={`${currentDay}-${index}`}
              className="border-t"
              style={{ borderColor: 'rgba(61,50,41,0.08)' }}
            >
              {/* Accordion Header */}
              <button
                onClick={() => toggle(index)}
                className="w-full text-left py-3.5 flex items-start justify-between gap-4 group"
              >
                <span
                  className="font-sans-zh text-sm leading-relaxed transition-colors duration-200"
                  style={{
                    color: isOpen ? '#3D3229' : 'rgba(61,50,41,0.7)',
                    fontWeight: isOpen ? 500 : 400,
                  }}
                >
                  {item.title}
                </span>
                <span
                  className="shrink-0 text-lg leading-none mt-0.5 transition-transform duration-200"
                  style={{
                    color: 'rgba(61,50,41,0.4)',
                    transform: isOpen ? 'rotate(45deg)' : 'rotate(0)',
                  }}
                >
                  +
                </span>
              </button>

              {/* Accordion Body */}
              <div
                className="overflow-hidden transition-[height,opacity] duration-300 ease-out"
                style={{
                  height: isOpen ? 'auto' : '0',
                  opacity: isOpen ? 1 : 0,
                }}
              >
                <div className="pb-4 pr-8">
                  <p
                    className="font-sans-zh text-sm leading-[1.8]"
                    style={{ color: 'rgba(61,50,41,0.65)' }}
                  >
                    {item.content}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
        {/* Bottom border */}
        <div className="border-t" style={{ borderColor: 'rgba(61,50,41,0.08)' }} />
      </div>

      {/* Day indicator */}
      <p className="text-center text-xs font-mono-data mt-4" style={{ color: 'rgba(61,50,41,0.3)' }}>
        Day {currentDay} · 共{items.length}项
      </p>
    </section>
  );
}
