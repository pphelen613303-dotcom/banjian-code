import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Play, Pause, Loader2 } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import type { TeaObserveDay } from '@/types';
import { getDayGuide } from '@/data/day-guides';

type PlayerState = 'idle' | 'loading' | 'ready' | 'playing' | 'paused' | 'ended';

interface AudioPlayerProps {
  day: TeaObserveDay;
  isDay6?: boolean;
  onRecordClick?: () => void;
}

function formatTime(seconds: number): string {
  if (!isFinite(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

/** Highlight keywords in text with gold color */
function HighlightText({ text, keywords }: { text: string; keywords: string[] }) {
  if (!keywords.length) return <>{text}</>;

  // Build a regex that matches any keyword
  const pattern = new RegExp(`(${keywords.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'g');
  const parts = text.split(pattern);

  return (
    <>
      {parts.map((part, i) => {
        const isKeyword = keywords.includes(part);
        return isKeyword ? (
          <span key={i} className="font-semibold" style={{ color: '#D4A853' }}>{part}</span>
        ) : (
          <span key={i}>{part}</span>
        );
      })}
    </>
  );
}

export default function AudioPlayer({ day, isDay6, onRecordClick }: AudioPlayerProps) {
  const [playerState, setPlayerState] = useState<PlayerState>('idle');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(day.duration || 0);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [_currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
  const [showMiniPlayer, setShowMiniPlayer] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);

  const guide = useMemo(() => getDayGuide(day.day), [day.day]);
  const segments = day.segments;
  const totalSegments = segments.length;

  // Calculate segment duration for time-based sync
  const segmentDuration = useMemo(() => {
    if (duration <= 0 || totalSegments === 0) return 0;
    return duration / totalSegments;
  }, [duration, totalSegments]);

  // Day 6 infusion indicators
  const infusionIndex = useMemo(() => {
    if (!isDay6 || duration <= 0) return 0;
    const infusionDuration = duration / 7;
    return Math.min(Math.floor(currentTime / infusionDuration), 6);
  }, [isDay6, currentTime, duration]);

  // Mini player visibility
  useEffect(() => {
    if (!playerRef.current) return;
    observerRef.current = new IntersectionObserver(
      ([entry]) => { setShowMiniPlayer(!entry.isIntersecting); },
      { threshold: 0.1 }
    );
    observerRef.current.observe(playerRef.current);
    return () => { observerRef.current?.disconnect(); };
  }, []);

  // Audio lifecycle
  useEffect(() => {
    const audio = new Audio(day.audioUrl);
    audioRef.current = audio;
    setPlayerState('idle');
    setCurrentTime(0);
    setCurrentSegmentIndex(0);

    const handleCanPlay = () => {
      setPlayerState(prev => (prev === 'loading' || prev === 'idle') ? 'ready' : prev);
      if (audio.duration && !isNaN(audio.duration)) setDuration(audio.duration);
    };
    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (segmentDuration > 0) {
        setCurrentSegmentIndex(Math.min(Math.floor(audio.currentTime / segmentDuration), totalSegments - 1));
      }
    };
    const handleEnded = () => { setPlayerState('ended'); setCurrentTime(duration); };
    const handleError = () => { setPlayerState('ready'); };

    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);
    audio.preload = 'auto';
    setPlayerState('loading');
    audio.load();

    return () => {
      audio.pause();
      audio.src = '';
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [day.audioUrl, day.duration, segmentDuration, totalSegments, duration]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    switch (playerState) {
      case 'idle': case 'ready': case 'paused':
        setPlayerState('playing');
        audio.play().catch(() => setPlayerState('ready'));
        break;
      case 'playing':
        setPlayerState('paused'); audio.pause(); break;
      case 'ended':
        audio.currentTime = 0; setCurrentTime(0); setCurrentSegmentIndex(0);
        setPlayerState('playing');
        audio.play().catch(() => setPlayerState('ready'));
        break;
    }
  }, [playerState]);

  const handleSeek = useCallback((values: number[]) => {
    const audio = audioRef.current;
    if (!audio || !duration) return;
    const newTime = (values[0] / 100) * duration;
    audio.currentTime = newTime;
    setCurrentTime(newTime);
    if (segmentDuration > 0) {
      setCurrentSegmentIndex(Math.min(Math.floor(newTime / segmentDuration), totalSegments - 1));
    }
  }, [duration, segmentDuration, totalSegments]);

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isPlaying = playerState === 'playing';
  const isLoading = playerState === 'loading';
  const isEnded = playerState === 'ended';

  return (
    <>
      {/* Main Player + Today Focus */}
      <div ref={playerRef} id="observe-audio" className="relative z-10 max-w-[720px] mx-auto px-4 xs:px-6 -mt-10">
        {/* === Audio Controls Card === */}
        <div
          className="relative overflow-hidden"
          style={{
            background: 'rgba(61,50,41,0.85)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
            borderRadius: '12px',
            border: '1px solid rgba(181,173,163,0.2)',
            padding: '20px 24px',
            boxShadow: '0 8px 40px rgba(0,0,0,0.15)',
          }}
        >
          {/* Controls Row */}
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="flex-shrink-0 flex items-center justify-center rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ width: '44px', height: '44px', color: '#FAF9F7' }}
              disabled={isLoading}
              aria-label={isPlaying ? '暂停' : isEnded ? '重新播放' : '播放'}
            >
              {isLoading ? (
                <Loader2 size={22} strokeWidth={1.5} className="animate-spin opacity-60" />
              ) : isPlaying ? (
                <Pause size={22} strokeWidth={1.5} />
              ) : (
                <Play size={22} strokeWidth={1.5} className="ml-0.5" />
              )}
            </button>

            <div className="flex-1 min-w-0">
              <Slider value={[progressPercent]} max={100} step={0.1} onValueChange={handleSeek} disabled={isLoading || duration <= 0} className="cursor-pointer" />
            </div>

            <div className="flex-shrink-0 font-mono-data text-sm" style={{ color: '#FAF9F7' }}>
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>

          {/* Ended CTA */}
          {isEnded && (
            <div className="mt-4 text-center">
              <p className="font-sans-zh text-base mb-3" style={{ color: '#D4A853' }}>今日音频已听完</p>
              <button
                onClick={onRecordClick}
                className="font-sans-zh text-sm px-5 py-2.5 rounded transition-all duration-200"
                style={{ background: '#D4A853', color: '#3D3229', fontWeight: 500 }}
              >记录今天的观察</button>
            </div>
          )}

          {/* Day 6 Infusion Indicators */}
          {isDay6 && (
            <div className="mt-4">
              <div className="flex items-center justify-center gap-2">
                {Array.from({ length: 7 }, (_, i) => (
                  <div key={i} className="rounded-full transition-all duration-300"
                    style={{
                      width: '12px', height: '12px',
                      background: i < infusionIndex ? 'rgba(212,168,83,0.3)' : i === infusionIndex ? '#D4A853' : 'rgba(181,173,163,0.3)',
                    }}
                  />
                ))}
              </div>
              <p className="text-center text-xs mt-2 font-sans-zh" style={{ color: 'rgba(240,237,232,0.5)' }}>
                第 {infusionIndex + 1} 泡
              </p>
            </div>
          )}
        </div>

        {/* === TODAY FOCUS: Daily Guide Card === */}
        <div
          className="mt-4 rounded-lg overflow-hidden"
          style={{
            background: 'rgba(250,249,247,0.7)',
            border: '1px solid rgba(61,50,41,0.08)',
            padding: '20px 24px',
          }}
        >
          {/* Day label + Theme */}
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono-data px-2 py-1 rounded" style={{ background: 'rgba(212,168,83,0.15)', color: '#3D3229' }}>
              Day {guide.day}
            </span>
            <span className="text-xs font-sans-zh" style={{ color: 'rgba(61,50,41,0.5)' }}>
              今日主题：{guide.theme}
            </span>
          </div>

          {/* Title */}
          <h3 className="font-serif-zh text-lg leading-snug mb-3" style={{ color: '#3D3229' }}>
            <HighlightText text={guide.title} keywords={guide.keywords} />
          </h3>

          {/* Plain Tip — core question */}
          <p className="font-sans-zh text-base mb-4 py-3 px-4 rounded" style={{ background: 'rgba(212,168,83,0.08)', color: '#3D3229', fontWeight: 500 }}>
            <HighlightText text={guide.plainTip} keywords={guide.keywords} />
          </p>

          {/* Record Prompt */}
          <p className="font-sans-zh text-sm mb-3" style={{ color: 'rgba(61,50,41,0.6)' }}>
            <span style={{ color: 'rgba(61,50,41,0.4)' }}>记录提示：</span>
            {guide.recordPrompt}
          </p>

          {/* Examples */}
          <div className="space-y-2">
            {guide.examples.map((ex, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-xs mt-0.5" style={{ color: 'rgba(212,168,83,0.6)' }}>▸</span>
                <p className="font-sans-zh text-sm" style={{ color: 'rgba(61,50,41,0.6)' }}>{ex}</p>
              </div>
            ))}
          </div>

          {/* Warm Reminder (Day 4 only) */}
          {guide.warmReminder && (
            <div className="mt-4 pt-3 border-t" style={{ borderColor: 'rgba(61,50,41,0.08)' }}>
              <p className="font-sans-zh text-xs leading-relaxed" style={{ color: 'rgba(61,50,41,0.4)' }}>
                {guide.warmReminder}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Mini Fixed Bottom Player (mobile) */}
      {showMiniPlayer && (playerState === 'playing' || playerState === 'paused') && (
        <div
          className="fixed bottom-0 left-0 right-0 z-40 px-4 py-3 md:hidden"
          style={{
            background: 'rgba(61,50,41,0.92)',
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
            borderTop: '1px solid rgba(181,173,163,0.2)',
          }}
        >
          <div className="flex items-center gap-3 max-w-[720px] mx-auto">
            <button onClick={togglePlay} className="flex-shrink-0 flex items-center justify-center" style={{ width: '40px', height: '40px', color: '#FAF9F7' }} aria-label={isPlaying ? '暂停' : '播放'}>
              {isPlaying ? <Pause size={20} strokeWidth={1.5} /> : <Play size={20} strokeWidth={1.5} className="ml-0.5" />}
            </button>
            <div className="flex-1">
              <Slider value={[progressPercent]} max={100} step={0.1} onValueChange={handleSeek} className="cursor-pointer" />
            </div>
            <span className="flex-shrink-0 font-mono-data text-xs" style={{ color: '#FAF9F7' }}>{formatTime(currentTime)}</span>
          </div>
        </div>
      )}
    </>
  );
}
