import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import gsap from 'gsap';
import { teaObserveDays } from '@/data/experience';
import { getDayGuide } from '@/data/day-guides';

interface TodayEntrySectionProps {
  teaType: 'bys' | 'bd001' | 'custom';
  customTeaName: string;
  onTeaTypeChange: (type: 'bys' | 'bd001' | 'custom') => void;
  onCustomTeaNameChange: (name: string) => void;
}

export default function TodayEntrySection({
  teaType,
  customTeaName,
  onTeaTypeChange,
  onCustomTeaNameChange,
}: TodayEntrySectionProps) {
  const [searchParams] = useSearchParams();
  const dayParam = searchParams.get('day');
  const dayNumber = dayParam ? parseInt(dayParam, 10) : 1;
  const currentDay = teaObserveDays.find((d) => d.day === dayNumber) || teaObserveDays[0];
  const guide = getDayGuide(dayNumber);

  const sectionRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const teaSelectRef = useRef<HTMLDivElement>(null);

  const [showCustomInput, setShowCustomInput] = useState(teaType === 'custom');

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(labelRef.current, { opacity: 0, y: 15 }, { opacity: 1, y: 0, duration: 0.3, delay: 0.2, ease: 'power2.out' });
      gsap.fromTo(titleRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, delay: 0.4, ease: 'power2.out' });
      gsap.fromTo(subtitleRef.current, { opacity: 0 }, { opacity: 1, duration: 0.4, delay: 0.6, ease: 'power2.out' });
      gsap.fromTo(teaSelectRef.current, { opacity: 0, y: 15 }, { opacity: 1, y: 0, duration: 0.5, delay: 0.7, ease: 'power2.out' });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const handleTeaSelect = (type: 'bys' | 'bd001' | 'custom') => {
    onTeaTypeChange(type);
    setShowCustomInput(type === 'custom');
  };

  return (
    <section
      ref={sectionRef}
      id="observe-today"
      className="relative flex items-center justify-center overflow-hidden"
      style={{ minHeight: '50vh' }}
    >
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/banjian-new/observe/observe-hero.jpg"
          alt=""
          className="w-full h-full object-cover"
          decoding="async"
          onError={(e) => { e.currentTarget.style.display = 'none'; }}
        />
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to bottom, rgba(61,50,41,0.4), rgba(61,50,41,0.7))' }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[600px] mx-auto text-center px-4 xs:px-6 py-12 md:py-16">
        {/* Day Label */}
        <div ref={labelRef} className="inline-block px-4 py-2 rounded-full opacity-0" style={{ background: 'rgba(212,168,83,0.15)' }}>
          <span className="text-sm font-sans-zh font-medium" style={{ color: '#D4A853', letterSpacing: '0.1em' }}>
            今天是第 {currentDay.day} 天 · {guide.theme}
          </span>
        </div>

        {/* Title */}
        <h1
          ref={titleRef}
          className="font-serif-zh mt-4 opacity-0"
          style={{ color: '#FAF9F7', fontSize: 'clamp(1.75rem, 5vw, 3rem)', fontWeight: 400, lineHeight: 1.2, letterSpacing: '0.02em' }}
        >
          今天观察{currentDay.title}
        </h1>

        {/* Subtitle */}
        <p ref={subtitleRef} className="font-sans-zh text-lg mt-4 opacity-0" style={{ color: 'rgba(250,249,247,0.8)' }}>
          {currentDay.subtitle}
        </p>

        {/* Tea Selection */}
        <div ref={teaSelectRef} className="mt-8 opacity-0">
          <p className="font-sans-zh text-xs mb-3" style={{ color: 'rgba(250,249,247,0.5)' }}>
            选择今天的茶品
          </p>

          <div className="flex items-center justify-center gap-2 flex-wrap">
            {[
              { key: 'bys' as const, label: '白莺初霁' },
              { key: 'bd001' as const, label: '石界岩手' },
              { key: 'custom' as const, label: '其他茶品' },
            ].map((option) => {
              const isActive = teaType === option.key;
              return (
                <button
                  key={option.key}
                  onClick={() => handleTeaSelect(option.key)}
                  className="font-sans-zh text-sm px-4 py-2 rounded-full transition-all duration-200"
                  style={{
                    background: isActive ? 'rgba(212,168,83,0.9)' : 'rgba(250,249,247,0.1)',
                    color: isActive ? '#3D3229' : '#FAF9F7',
                    border: isActive ? '1px solid rgba(212,168,83,0.9)' : '1px solid rgba(250,249,247,0.3)',
                    fontWeight: isActive ? 500 : 400,
                  }}
                >
                  {option.label}
                </button>
              );
            })}
          </div>

          {/* Custom tea input */}
          {showCustomInput && (
            <div className="mt-3 flex items-center justify-center">
              <input
                type="text"
                value={customTeaName}
                onChange={(e) => onCustomTeaNameChange(e.target.value)}
                placeholder="输入茶品名称..."
                className="w-full max-w-[280px] font-sans-zh text-sm px-4 py-2.5 rounded-lg outline-none"
                style={{
                  background: 'rgba(250,249,247,0.15)',
                  color: '#FAF9F7',
                  border: '1px solid rgba(250,249,247,0.3)',
                }}
              />
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
