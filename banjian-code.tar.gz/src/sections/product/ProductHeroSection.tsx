import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import SectionEyebrow from '@/components/SectionEyebrow';
import ProductSwitcher from '@/components/ProductSwitcher';
import { products } from '@/data/archive';
import { Timer, Anchor } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

// ───────────────────────────────────────────────
// Types
// ───────────────────────────────────────────────

interface ProductHeroSectionProps {
  activeProduct: 'bys' | 'bd001';
  onSwitch: (product: 'bys' | 'bd001') => void;
}

interface InfusionStep {
  step: string;
  title: string;
  guide: string;
}

// ───────────────────────────────────────────────
// Data: Body description + Seven-infusion paths
// ───────────────────────────────────────────────

const bodyDescriptions = {
  bys: {
    paragraphs: [
      '有些变化，不需要被察觉，它会自己慢慢发生。',
      '身体不会被拉扯，也不会被推动。它只是慢慢安静下来。',
      '像清晨的雾慢慢散开，而不是被驱散。',
    ],
    eyebrow: 'SEVEN-INFUSION PATH',
    heading: '七泡路径不是评分表，是身体记录。',
    infusions: [
      { step: '01', title: '初见', guide: '像刚刚进入清晨' },
      { step: '02', title: '渐开', guide: '香气慢慢抬升' },
      { step: '03', title: '合光', guide: '汤感开始变厚' },
      { step: '04', title: '湿明', guide: '呼吸慢慢变长' },
      { step: '05', title: '清和', guide: '甜感向后出现' },
      { step: '06', title: '微云', guide: '香气慢慢内收' },
      { step: '07', title: '余韵', guide: '停一会儿再结束' },
    ] as InfusionStep[],
    energy: ['4-8天萎凋', '24h观察动态', '5.7:1出茶率'],
  },
  bd001: {
    paragraphs: [
      '有些东西，不是被打开的，而是被慢慢释放出来的。',
      '身体会逐渐找到支撑点，而不是被推动。',
      '像石头不是被压碎，而是内部结构重新排列。',
    ],
    eyebrow: 'SEVEN-INFUSION PATH',
    heading: '七泡路径不是评分表，是身体记录。',
    infusions: [
      { step: '01', title: '松动', guide: '口腔初始收紧' },
      { step: '02', title: '试探', guide: '香气慢慢上行' },
      { step: '03', title: '舒展', guide: '口腔轮廓成形' },
      { step: '04', title: '结构', guide: '岩韵慢慢穿透' },
      { step: '05', title: '厚度', guide: '回甘慢慢回来' },
      { step: '06', title: '延展', guide: '身体内部升温' },
      { step: '07', title: '沉静', guide: '力量慢慢回收' },
    ] as InfusionStep[],
    energy: ['65°C±3°C叶温', '31锅手工淬炼', '4.1:1出茶率'],
  },
};

// ───────────────────────────────────────────────
// Sub-component: Inline Seven-Infusion Path
// ───────────────────────────────────────────────

function InlineSevenPath({
  infusions,
  energy,
  isBys,
}: {
  infusions: InfusionStep[];
  energy: string[];
  isBys: boolean;
}) {
  const pathRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState<number | null>(null);

  useGSAP(
    () => {
      if (!pathRef.current) return;
      const nodes = pathRef.current.querySelectorAll('.infusion-node');
      const line = pathRef.current.querySelector('.infusion-line-fill');

      // Line fills from left to right
      if (line) {
        gsap.fromTo(
          line,
          { scaleX: 0 },
          {
            scaleX: 1,
            duration: 1.2,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: pathRef.current,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Nodes pop in one by one
      gsap.fromTo(
        nodes,
        { opacity: 0, scale: 0.5 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.4,
          stagger: 0.12,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: pathRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    },
    { scope: pathRef, dependencies: [infusions] }
  );

  return (
    <div ref={pathRef} className="mt-8 pt-6 border-t border-archive-brown-12">
      {/* Eyebrow + heading */}
      <SectionEyebrow
        text="SEVEN-INFUSION PATH"
        className="mb-2"
      />
      <p className="text-sm font-sans-zh text-archive-brown-60 mb-6">
        七泡路径不是评分表，是身体记录。
      </p>

      {/* Horizontal path line */}
      <div className="relative">
        {/* Background line */}
        <div className="absolute top-[7px] left-0 right-0 h-[2px] bg-archive-brown-12" />
        {/* Animated fill line */}
        <div
          className="infusion-line-fill absolute top-[7px] left-0 h-[2px] origin-left"
          style={{
            background: isBys
              ? 'linear-gradient(to right, #1B4332, #D4A853)'
              : 'linear-gradient(to right, #3D3229, #D4A853)',
            width: '100%',
          }}
        />

        {/* Nodes */}
        <div className="relative flex justify-between">
          {infusions.map((item, index) => (
            <div
              key={item.step}
              className="infusion-node flex flex-col items-center cursor-pointer"
              onMouseEnter={() => setActiveStep(index)}
              onMouseLeave={() => setActiveStep(null)}
            >
              {/* Dot */}
              <div
                className={cn(
                  'w-4 h-4 rounded-full border-2 transition-all duration-300',
                  activeStep === index
                    ? 'scale-125'
                    : ''
                )}
                style={{
                  backgroundColor:
                    activeStep === index
                      ? isBys
                        ? '#1B4332'
                        : '#3D3229'
                      : '#FAF9F7',
                  borderColor: isBys ? '#1B4332' : '#3D3229',
                }}
              />
              {/* Step number */}
              <span className="text-[10px] font-mono-data text-archive-brown-30 mt-1.5">
                {item.step}
              </span>
              {/* Title */}
              <span className="text-xs font-sans-zh text-archive-brown mt-0.5">
                {item.title}
              </span>

              {/* Tooltip */}
              <div
                className={cn(
                  'absolute bottom-full mb-2 px-2.5 py-1.5 rounded text-center transition-all duration-200 pointer-events-none',
                  activeStep === index
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-1'
                )}
                style={{
                  backgroundColor: isBys ? '#1B4332' : '#3D3229',
                  minWidth: '80px',
                }}
              >
                <p className="text-[11px] font-sans-zh text-warm-white whitespace-nowrap">
                  {item.guide}
                </p>
                <div
                  className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0"
                  style={{
                    borderLeft: '4px solid transparent',
                    borderRight: '4px solid transparent',
                    borderTop: `4px solid ${isBys ? '#1B4332' : '#3D3229'}`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* System summary */}
      <div className="mt-6 pt-4 border-t border-archive-brown-12">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
            style={{ backgroundColor: isBys ? 'rgba(27,67,50,0.1)' : 'rgba(139,98,57,0.1)' }}
          >
            {isBys ? (
              <Timer size={14} className="text-deep-green" />
            ) : (
              <Anchor size={14} style={{ color: '#8B6239' }} />
            )}
          </div>
          <div>
            <p
              className="text-sm font-serif-zh mb-1"
              style={{ color: isBys ? '#1B4332' : '#8B6239' }}
            >
              {isBys ? '时间系统' : '结构系统'}
            </p>
            <p className="text-base font-serif-zh text-archive-brown">
              {isBys
                ? '不是让你更快，而是让你慢下来。'
                : '不是让你更强，而是让你更稳。'}
            </p>
            <p className="text-sm font-sans-zh text-archive-brown-60 mt-1">
              {isBys
                ? '让时间重新拥有空间。'
                : '让身体重新拥有支点。'}
            </p>
          </div>
        </div>
      </div>

      {/* Energy passwords */}
      <div className="mt-6 pt-4 border-t border-archive-brown-12">
        <p className="text-xs font-sans-zh text-archive-brown-40 mb-2">
          这批茶的能量密码
        </p>
        <div className="flex flex-wrap gap-x-4 gap-y-1">
          {energy.map((item) => (
            <span
              key={item}
              className="text-xs font-mono-data text-archive-brown-60"
            >
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────
// Main Component: ProductHeroSection
// ───────────────────────────────────────────────

export default function ProductHeroSection({
  activeProduct,
  onSwitch,
}: ProductHeroSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const product = activeProduct === 'bys' ? products.BYS001 : products.BD001;
  const textureUrl =
    activeProduct === 'bys'
      ? '/images/banjian-new/brand/mountain-texture-bys.png'
      : '/images/banjian-new/brand/mountain-texture-bd001.png';
  const data = bodyDescriptions[activeProduct];

  // GSAP crossfade on product switch
  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.3, ease: 'power2.out' }
      );
    }
  }, [activeProduct]);

  // Scroll-triggered entrance animations
  useGSAP(
    () => {
      if (!sectionRef.current) return;
      const elements = sectionRef.current.querySelectorAll('.hero-animate');
      gsap.fromTo(
        elements,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    },
    { scope: sectionRef }
  );

  return (
    <section ref={sectionRef} id="product-hero" className="w-full bg-warm-white">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 pt-8 pb-16 md:pb-24">
        {/* Product Switcher - full width */}
        <div className="hero-animate mb-8 md:mb-6">
          <ProductSwitcher activeProduct={activeProduct} onSwitch={onSwitch} />
        </div>

        {/* Content grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 items-start">
          {/* Left: Text content */}
          <div ref={contentRef} className="order-2 md:order-1 relative">
            {/* Mountain texture background decoration */}
            <div
              className="absolute -right-8 -bottom-4 w-[70%] h-[60%] pointer-events-none opacity-[0.05]"
              style={{
                backgroundImage: `url(${textureUrl})`,
                backgroundPosition: 'bottom right',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                mixBlendMode: 'multiply',
              }}
            />

            <SectionEyebrow
              text="BANJIAN LIVING ARCHIVE"
              className="hero-animate"
            />

            <h1 className="hero-animate text-[clamp(1.75rem,5vw,3rem)] md:text-[clamp(2.25rem,3.5vw,3.5rem)] font-serif-zh text-archive-brown leading-tight tracking-[0.02em]">
              {product.name}
            </h1>

            {/* Tags */}
            <div className="hero-animate flex flex-wrap gap-2 mt-4">
              <span className="px-3 py-1 rounded text-sm bg-archive-brown-12 text-archive-brown">
                {product.id}
              </span>
              <span className="px-3 py-1 rounded text-sm bg-archive-brown-12 text-archive-brown">
                {product.category}
              </span>
              <span
                className="px-3 py-1 rounded text-sm"
                style={{
                  backgroundColor: 'rgba(27,67,50,0.1)',
                  color: '#1B4332',
                }}
              >
                {product.lifeStructureTag}
              </span>
            </div>

            {/* Core sentence */}
            <p className="hero-animate mt-4 text-lg font-serif-zh text-archive-brown-80 leading-relaxed">
              {product.coreSentence}
            </p>

            {/* NEW: Body description paragraphs */}
            <div className="hero-animate mt-6 space-y-3">
              {data.paragraphs.map((p, i) => (
                <p
                  key={i}
                  className="text-sm md:text-base font-sans-zh text-archive-brown-60 leading-relaxed"
                >
                  {p}
                </p>
              ))}
            </div>

            {/* NEW: Inline seven-infusion path */}
            <div className="hero-animate">
              <InlineSevenPath
                infusions={data.infusions}
                energy={data.energy}
                isBys={activeProduct === 'bys'}
              />
            </div>
          </div>

          {/* Right: Product Image */}
          <div className="order-3 md:order-2 flex items-center justify-center md:sticky md:top-24">
            <img
              ref={imageRef}
              src={product.heroImage}
              alt={`${product.name} 产品套装`}
              className="hero-animate w-full max-w-[400px] md:max-w-[500px] h-auto object-contain"
              style={{
                animation: 'float 4s ease-in-out infinite',
              }}
              loading="eager"
             decoding="async"/>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(-4px); }
          50% { transform: translateY(4px); }
        }
      `}</style>
    </section>
  );
}
