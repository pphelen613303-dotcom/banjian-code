import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import type { ExperienceMethod } from './ExperienceMethodSection';

gsap.registerPlugin(ScrollTrigger);

interface SampleSelectionCTASectionProps {
  selectedMethod: ExperienceMethod | null;
}

const qrMapping: Record<ExperienceMethod, { src: string; label: string }> = {
  single: { src: '/images/banjian-new/qr/wechat-shop-qicaizongsi.png', label: '微信小店 — 单品一泡' },
  seven: { src: '/images/banjian-new/qr/wechat-shop-qicaizongsi.png', label: '微信小店 — 七泡盒装' },
  dual: { src: '/images/banjian-new/qr/wechat-shop-qicaizongsi.png', label: '微信小店 — 双茶8泡' },
  fourteen: { src: '/images/banjian-new/qr/banjian-tea-guide-wechat.jpg', label: '茶觉师微信 — 14天周期' },
};

export default function SampleSelectionCTASection({ selectedMethod }: SampleSelectionCTASectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const qrRef = useRef<HTMLDivElement>(null);

  // Animate QR code appearance when selection changes
  useEffect(() => {
    if (qrRef.current && selectedMethod) {
      gsap.fromTo(
        qrRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.3, ease: 'power2.out' }
      );
    }
  }, [selectedMethod]);

  useGSAP(() => {
    if (!sectionRef.current) return;

    const els = sectionRef.current.querySelectorAll('.cta-animate');
    gsap.fromTo(
      els,
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.1,
        scrollTrigger: { trigger: sectionRef.current, start: 'top 85%', toggleActions: 'play none none none' },
      }
    );
  }, { scope: sectionRef });

  const hasSelection = selectedMethod !== null;
  const qrInfo = selectedMethod ? qrMapping[selectedMethod] : null;

  return (
    <section
      ref={sectionRef}
      id="product-cta"
      className="relative w-full bg-archive-brown py-14 md:py-20"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <div className="text-center">
          <h2 className="cta-animate text-[clamp(1.25rem,3vw,1.75rem)] md:text-[clamp(1.75rem,2.5vw,2.5rem)] font-serif-zh text-warm-white leading-tight tracking-[0.015em]">
            扫码选择本次观察样本
          </h2>
          <p className="cta-animate mt-4 text-sm md:text-base text-warm-white-60 font-sans-zh">
            {hasSelection
              ? '扫描下方二维码，开始你的观察之旅。'
              : '选择上方的体验方式后，扫描对应二维码开始你的观察。'}
          </p>
        </div>

        {/* QR Display Area */}
        <div className="mt-10 flex justify-center">
          {qrInfo ? (
            <div ref={qrRef} className="text-center">
              <div className="inline-block bg-[#FAF9F7] p-2 rounded-lg">
                <img
                  src={qrInfo.src}
                  alt={qrInfo.label}
                  className="w-[160px] h-[160px] object-contain"
                  loading="lazy"
                 decoding="async"/>
              </div>
              <p className="mt-4 text-xs text-warm-white-50 font-sans-zh">
                {qrInfo.label}
              </p>
            </div>
          ) : (
            <div className="cta-animate text-center py-5">
              <p className="text-sm text-warm-white-40 font-sans-zh">
                请在上方的四种方式中选择一种体验
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Fixed Bottom Panel - slides up when QR is active */}
      {qrInfo && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-archive-brown border-t border-warm-white-10 p-4 transform transition-transform duration-300 translate-y-0">
          <div className="flex items-center gap-4">
            <div className="shrink-0 bg-[#FAF9F7] p-1 rounded">
              <img
                src={qrInfo.src}
                alt={qrInfo.label}
                className="w-16 h-16 object-contain"
                loading="lazy"
               decoding="async"/>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-warm-white font-sans-zh truncate">
                {qrInfo.label}
              </p>
              <p className="text-xs text-warm-white-50 mt-1">
                扫码选择本次观察样本
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
