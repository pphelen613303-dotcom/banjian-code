import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import { bysFourCards, bd001FourCards, type FourCard } from '@/data/fourCards';

gsap.registerPlugin(ScrollTrigger);

// ─── Single Card ───

function CardItem({ card, isBys }: { card: FourCard; isBys: boolean }) {
  const [expanded, setExpanded] = useState(false);
  const detailRef = useRef<HTMLDivElement>(null);

  const accentColor = isBys ? '#1B4332' : '#8B6239';
  const accentBg = isBys ? 'rgba(27,67,50,0.07)' : 'rgba(139,98,57,0.07)';
  const accentLight = isBys ? 'text-deep-green' : 'text-[#8B6239]';
  const accentBorder = isBys ? 'border-deep-green/20' : 'border-[#8B6239]/20';
  const topBar = isBys ? 'bg-deep-green' : 'bg-[#8B6239]';

  const handleToggle = () => {
    const ne = !expanded;
    setExpanded(ne);
    if (!detailRef.current) return;
    if (ne) {
      gsap.to(detailRef.current, { height: 'auto', opacity: 1, duration: 0.4, ease: 'power2.out' });
    } else {
      gsap.to(detailRef.current, { height: 0, opacity: 0, duration: 0.3, ease: 'power2.in' });
    }
  };

  return (
    <div
      className="relative rounded-xl overflow-hidden cursor-pointer transition-all duration-300 border border-archive-brown-10 hover:border-archive-brown-20 hover:shadow-md group h-full flex flex-col"
      onClick={handleToggle}
      role="button"
      aria-expanded={expanded}
    >
      {/* Product color top bar */}
      <div className={cn('h-[3px] w-full', topBar)} />

      {/* Background texture — subtle but present */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `url(${card.bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.18,
        }}
      />

      {/* Content */}
      <div className="relative z-10 p-5 md:p-6 flex flex-col flex-1">
        {/* Header */}
        <div className="flex items-baseline gap-3 mb-1">
          <span className="text-3xl md:text-4xl font-serif-zh text-archive-brown tracking-tight">
            {card.number}
          </span>
          <div>
            <h3 className="text-lg md:text-xl font-serif-zh text-archive-brown">{card.titleCn}</h3>
            <p className="text-[10px] font-sans-zh tracking-[0.12em] uppercase" style={{ color: accentColor }}>
              {card.titleEn}
            </p>
          </div>
        </div>

        {/* Intro */}
        <p className="text-sm font-sans-zh text-archive-brown-55 mb-4">{card.intro}</p>

        <div className="w-full h-[1px] mb-4" style={{ backgroundColor: isBys ? 'rgba(27,67,50,0.12)' : 'rgba(139,98,57,0.15)' }} />

        {/* Dimensions — rich visual treatment */}
        <div className="grid grid-cols-2 gap-3 flex-1">
          {card.dimensions.map((dim, di) => (
            <div key={dim.label} className="flex flex-col">
              <div className="flex items-center gap-1.5 mb-1">
                <span
                  className="flex items-center justify-center w-4 h-4 rounded-full text-[9px] font-mono-data text-warm-white shrink-0"
                  style={{ backgroundColor: accentColor }}
                >
                  {String(di + 1).padStart(2, '0')}
                </span>
                <span className="text-[11px] font-sans-zh font-medium" style={{ color: accentColor }}>
                  {dim.label}
                </span>
              </div>
              <p className="text-xs font-sans-zh text-archive-brown leading-relaxed pl-[22px]">
                {dim.summary}
              </p>
            </div>
          ))}
        </div>

        {/* Expandable detail */}
        <div ref={detailRef} className="overflow-hidden" style={{ height: 0, opacity: 0 }}>
          <div className="pt-4 mt-4" style={{ borderTop: `1px solid ${isBys ? 'rgba(27,67,50,0.1)' : 'rgba(139,98,57,0.12)'}` }}>
            <div className="space-y-3">
              {card.dimensions.map((dim) => (
                <div key={`d-${dim.label}`}>
                  <span className={cn('text-[11px] font-sans-zh font-medium', accentLight)}>{dim.label}</span>
                  <div className="mt-0.5 space-y-0.5">
                    {dim.lines.map((line, i) => (
                      <p key={i} className="text-xs font-sans-zh text-archive-brown-75 leading-relaxed">{line}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${isBys ? 'rgba(27,67,50,0.08)' : 'rgba(139,98,57,0.1)'}` }}>
              <p className={cn('text-xs font-serif-zh italic leading-relaxed', accentLight)}>{card.closing}</p>
            </div>
          </div>
        </div>

        {/* State label + expand hint — pushed to bottom */}
        <div className="mt-auto pt-4">
          {card.stateLabel && (
            <div className={cn('inline-block px-3 py-1 rounded text-[11px] font-sans-zh mb-2 border', accentBg, accentLight, accentBorder)}>
              {card.stateLabel}
            </div>
          )}
          <div className="flex items-center gap-1.5 text-archive-brown-25">
            <div className={cn('w-1.5 h-1.5 border-r border-b border-archive-brown-25 transition-transform duration-300', expanded ? 'rotate-[-135deg] -translate-y-0.5' : 'rotate-45')} />
            <span className="text-[10px] font-sans-zh">{expanded ? '收起' : '展开详情'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main ───

export default function FourCardSection({ activeProduct }: { activeProduct: 'bys' | 'bd001' }) {
  const sectionRef = useRef<HTMLElement>(null);
  const isBys = activeProduct === 'bys';
  const cards = isBys ? bysFourCards : bd001FourCards;

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.four-card-header > *', { opacity: 0, y: 30 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.four-card-header', start: 'top 85%', toggleActions: 'play none none none' },
    });
    gsap.fromTo('.four-card-item', { opacity: 0, y: 40 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.12, ease: 'power2.out',
      scrollTrigger: { trigger: '.four-card-grid', start: 'top 80%', toggleActions: 'play none none none' },
    });
  }, { scope: sectionRef, dependencies: [activeProduct] });

  return (
    <section ref={sectionRef} className="w-full py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Cards Grid — aligned with auto-rows */}
        <div className="four-card-grid grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6" style={{ gridAutoRows: '1fr' }}>
          {cards.map((card) => (
            <div key={card.id} className="four-card-item h-full">
              <CardItem card={card} isBys={isBys} />
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
