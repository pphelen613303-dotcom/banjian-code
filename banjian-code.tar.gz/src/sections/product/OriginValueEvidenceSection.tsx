import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { traceabilityData } from '@/data/traceability';

gsap.registerPlugin(ScrollTrigger);

interface OriginValueEvidenceSectionProps {
  activeProduct: 'bys' | 'bd001';
}

const bysDataCards = [
  { field: '山场', value: '白莺山 1800-2200m', explanation: '茶长在哪里，决定了它从什么样的土壤和气候里汲取味道' },
  { field: '工艺', value: '4-8天萎凋', explanation: '不同的处理方式让同样的叶子走向不同的身体入口' },
  { field: '鲜叶→干茶', value: '567.8kg → 100.1kg', explanation: '这不是库存数字，而是这批茶最初进入档案的生命总量' },
  { field: '出茶率', value: '5.7:1', explanation: '每5.7公斤鲜叶，经过萎凋后留下1公斤干茶' },
  { field: '总成本', value: '¥71,711.22', explanation: '档案的完整成本，包括从鲜叶到包装的所有环节' },
];

const bd001DataCards = [
  { field: '山场', value: '邦东 1650m', explanation: '茶长在哪里，决定了它从什么样的土壤和气候里汲取味道' },
  { field: '工艺', value: '65℃±3℃叶温', explanation: '不同的处理方式让同样的叶子走向不同的身体入口' },
  { field: '鲜叶→干茶', value: '179.28kg → 43.84kg', explanation: '这不是库存数字，而是这批茶最初进入档案的生命总量' },
  { field: '出茶率', value: '4.1:1', explanation: '每4.1公斤鲜叶，经过杀青后留下1公斤干茶' },
  { field: '总成本', value: '¥26,605.44', explanation: '档案的完整成本，包括从鲜叶到包装的所有环节' },
];

export default function OriginValueEvidenceSection({ activeProduct }: OriginValueEvidenceSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const dataCards = activeProduct === 'bys' ? bysDataCards : bd001DataCards;
  const traceability = traceabilityData.find(t => t.product_id === (activeProduct === 'bys' ? 'BYS001' : 'BD001'));

  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(contentRef.current, { opacity: 0 }, { opacity: 1, duration: 0.3, ease: 'power2.out' });
    }
  }, [activeProduct]);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo('.evidence-row', { opacity: 0, y: 16 }, {
        opacity: 1, y: 0, duration: 0.4, stagger: 0.08, ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="product-evidence" className="w-full bg-warm-cream py-14 md:py-20">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="mb-5 md:mb-7">
          <SectionEyebrow text="ORIGIN EVIDENCE" />
          <h2 className="text-[clamp(1.25rem,3vw,1.75rem)] font-serif-zh text-archive-brown leading-tight tracking-[0.015em]">
            每一个数字背后，都有解释。
          </h2>
        </div>

        <div ref={contentRef}>
          {/* Data as definition list — archival style */}
          <dl className="border-t border-archive-brown-6">
            {dataCards.map((card) => (
              <div
                key={`${activeProduct}-${card.field}`}
                className="evidence-row grid grid-cols-1 md:grid-cols-12 gap-1 md:gap-4 py-5 border-b border-archive-brown-6"
              >
                <dt className="md:col-span-2 text-xs uppercase tracking-[0.1em] text-archive-brown-50 font-sans-zh pt-1">
                  {card.field}
                </dt>
                <dd className="md:col-span-10">
                  <p className="text-lg md:text-xl font-mono-data text-archive-brown leading-tight">
                    {card.value}
                  </p>
                  <p className="mt-1 text-sm text-archive-brown-50 leading-relaxed font-sans-zh">
                    {card.explanation}
                  </p>
                </dd>
              </div>
            ))}
          </dl>

          {/* Value Flow Summary */}
          {traceability && (
            <div className="evidence-row mt-5 pt-6 border-t border-archive-brown-6">
              <p className="text-sm text-archive-brown-60 font-sans-zh">
                <span className="text-archive-brown font-medium">价值流向：</span>
                鲜叶 {traceability.value_flow.items[0].percent}% / 工费 {traceability.value_flow.items[1].percent}% / 
                固定成本 {traceability.value_flow.items[2].percent}% / 溯源 {traceability.value_flow.items[3].percent}% / 
                品牌 {traceability.value_flow.items[4].percent}% / 物流 {traceability.value_flow.items[5].percent}% / 
                生态 {traceability.value_flow.items[6].percent}% / 成本回收 {traceability.value_flow.items[7].percent}%
              </p>
              <p className="mt-2 text-xs text-archive-brown-50">
                完整价值流向请查看
                <Link to="/value" className="text-tea-gold hover:underline ml-1">价值页面</Link>
              </p>
            </div>
          )}

          {/* CTA */}
          <div className="evidence-row mt-10">
            <Link
              to={`/origin?product=${activeProduct}`}
              className="inline-flex items-center gap-2 text-sm font-sans-zh text-archive-brown hover:text-tea-gold transition-colors duration-200 group"
            >
              查看完整生命档案
              <span className="transition-transform duration-200 group-hover:translate-x-1">→</span>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
