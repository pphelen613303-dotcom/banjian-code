import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

interface BodyEntrySectionProps {
  activeProduct: 'bys' | 'bd001';
}

const bysData = {
  title: '白莺初霁',
  subtitle: '时间缓释结构',
  body: '缓释结构描述——身体安静、呼吸变长、时间感变慢。茶汤不急于一瞬间打开，而是在每一次冲泡中缓慢释放，让你有足够的时间去觉察身体的变化。',
  keywords: [
    { label: '清', desc: '身体安静，茶汤不急' },
    { label: '缓', desc: '呼吸变长，时间感变慢' },
    { label: '退', desc: '慢慢向后退，不急于判断' },
  ],
  color: '#1B4332',
  colorLight: 'rgba(27,67,50,0.1)',
};

const bd001Data = {
  title: '石界岩手',
  subtitle: '压力释放结构',
  body: '释放结构描述——口腔有支撑、结构清晰、空间感打开。入口即能感受到力量，岩韵穿透，回甘持久，身体内部逐渐发热，空间感随之展开。',
  keywords: [
    { label: '热', desc: '入口即感力量，身体逐渐发热' },
    { label: '压', desc: '口腔有支撑，岩韵穿透' },
    { label: '回', desc: '回甘持久，空间感打开' },
  ],
  color: '#C17B5F',
  colorLight: 'rgba(193,123,95,0.1)',
};

export default function BodyEntrySection({ activeProduct }: BodyEntrySectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const isBys = activeProduct === 'bys';
  const primary = isBys ? bysData : bd001Data;
  const secondary = isBys ? bd001Data : bysData;

  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(contentRef.current, { opacity: 0 }, { opacity: 1, duration: 0.3, ease: 'power2.out' });
    }
  }, [activeProduct]);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo('.body-entry-item', { opacity: 0, y: 20 }, {
        opacity: 1, y: 0, duration: 0.5, stagger: 0.1, ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="product-body" className="w-full bg-warm-cream py-14 md:py-20">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        <div ref={contentRef} className="grid grid-cols-1 md:grid-cols-2 gap-0">

          {/* Primary entry */}
          <div
            className="body-entry-item py-5 md:py-6 md:pr-12 border-b md:border-b-0 md:border-r border-archive-brown-6"
            style={{ borderLeftWidth: '3px', borderLeftColor: primary.color }}
          >
            <div className="pl-6 md:pl-8">
              <span className="text-xs font-mono-data tracking-wider" style={{ color: primary.color }}>
                {primary.subtitle}
              </span>
              <h3 className="mt-2 text-xl font-serif-zh text-archive-brown">
                {primary.title}
              </h3>
              <p className="mt-4 text-sm text-archive-brown-60 leading-relaxed max-w-[360px]">
                {primary.body}
              </p>
              <div className="mt-4 space-y-3">
                {primary.keywords.map((kw) => (
                  <div key={kw.label} className="flex items-start gap-3">
                    <span
                      className="shrink-0 inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-medium"
                      style={{ backgroundColor: primary.colorLight, color: primary.color }}
                    >
                      {kw.label}
                    </span>
                    <span className="text-sm text-archive-brown-60 leading-relaxed pt-1">
                      {kw.desc}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Secondary entry */}
          <div
            className="body-entry-item py-5 md:py-6 md:pl-12 border-b border-archive-brown-6"
            style={{ borderLeftWidth: '3px', borderLeftColor: secondary.color }}
          >
            <div className="pl-6 md:pl-8">
              <span className="text-xs font-mono-data tracking-wider" style={{ color: secondary.color }}>
                {secondary.subtitle}
              </span>
              <h3 className="mt-2 text-xl font-serif-zh text-archive-brown">
                {secondary.title}
              </h3>
              <p className="mt-4 text-sm text-archive-brown-60 leading-relaxed max-w-[360px]">
                {secondary.body}
              </p>
              <div className="mt-4 space-y-3">
                {secondary.keywords.map((kw) => (
                  <div key={kw.label} className="flex items-start gap-3">
                    <span
                      className="shrink-0 inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-medium"
                      style={{ backgroundColor: secondary.colorLight, color: secondary.color }}
                    >
                      {kw.label}
                    </span>
                    <span className="text-sm text-archive-brown-60 leading-relaxed pt-1">
                      {kw.desc}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
