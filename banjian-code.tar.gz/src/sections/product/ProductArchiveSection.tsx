import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { products } from '@/data/archive';

gsap.registerPlugin(ScrollTrigger);

interface ProductArchiveSectionProps {
  activeProduct: 'bys' | 'bd001';
}

export default function ProductArchiveSection({ activeProduct }: ProductArchiveSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const product = activeProduct === 'bys' ? products.BYS001 : products.BD001;

  const archiveFields = [
    { label: '编号', value: product.id },
    { label: '来源名', value: product.sourceName },
    { label: '产品名', value: product.name },
    { label: '核心句', value: product.coreSentence, isCore: true },
    { label: '生命结构', value: product.lifeStructure },
    { label: '产区', value: product.region },
    { label: '海拔', value: product.altitude },
    { label: '采摘时间', value: product.harvestTime },
    { label: '出茶率', value: `${product.yieldPercent}（${product.yieldRatio}）` },
    { label: '样本', value: product.sampleSize },
    { label: '观察路径', value: product.observationPath },
  ];

  // Crossfade on product switch
  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.3, ease: 'power2.out' }
      );
    }
  }, [activeProduct]);

  useGSAP(() => {
    if (!sectionRef.current) return;

    const dlItems = sectionRef.current.querySelectorAll('.dl-animate');
    gsap.fromTo(
      dlItems,
      { opacity: 0, x: -10 },
      {
        opacity: 1, x: 0, duration: 0.5, stagger: 0.06,
        scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', toggleActions: 'play none none none' },
      }
    );

    const img = sectionRef.current.querySelector('.archive-img-animate');
    if (img) {
      gsap.fromTo(
        img,
        { opacity: 0, scale: 0.98 },
        {
          opacity: 1, scale: 1, duration: 0.6, delay: 0.5,
          scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', toggleActions: 'play none none none' },
        }
      );
    }
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      id="product-archive"
      className="w-full bg-warm-white py-16 md:py-24"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="mb-6 md:mb-8">
          <SectionEyebrow text="LIVING ARCHIVE" />
          <h2 className="text-[clamp(1.25rem,3vw,1.75rem)] md:text-[clamp(1.75rem,2.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight tracking-[0.015em]">
            一套可以被拿起、阅读、冲泡和补完的档案。
          </h2>
        </div>

        {/* Content: DL + Image */}
        <div ref={contentRef} className="grid grid-cols-1 md:grid-cols-[55%_45%] gap-4 md:gap-6">
          {/* Definition List */}
          <dl className="space-y-0">
            {archiveFields.map((field) => (
              <div
                key={`${activeProduct}-${field.label}`}
                className="dl-animate py-4 border-b border-archive-brown-6 last:border-b-0"
              >
                <dt className="text-xs uppercase tracking-[0.1em] text-archive-brown-60 font-sans-zh">
                  {field.label}
                </dt>
                <dd
                  className={`mt-1 font-sans-zh font-medium text-archive-brown ${
                    field.isCore ? 'font-serif-zh text-lg text-archive-brown-80' : 'text-base'
                  }`}
                >
                  {field.value}
                </dd>
              </div>
            ))}
          </dl>

          {/* Archive Image */}
          <div className="archive-img-animate flex items-start">
            <img
              src={product.archiveImage}
              alt={`${product.name} 产品档案`}
              className="w-full h-auto rounded-lg object-cover"
              loading="lazy"
             decoding="async"/>
          </div>
        </div>
      </div>
    </section>
  );
}
