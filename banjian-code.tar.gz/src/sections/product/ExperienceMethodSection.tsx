import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { cn } from '@/lib/utils';
import SectionEyebrow from '@/components/SectionEyebrow';

gsap.registerPlugin(ScrollTrigger);

interface ExperienceMethodSectionProps {
  onSelect: (method: ExperienceMethod) => void;
  selected: ExperienceMethod | null;
}

export type ExperienceMethod = 'single' | 'seven' | 'dual' | 'fourteen';

const methods: {
  id: ExperienceMethod;
  num: string;
  name: string;
  desc: string;
  audience: string;
  cta: string;
  texture: string;
}[] = [
  {
    id: 'single',
    num: '01',
    name: '单品一泡',
    desc: '初次靠近，低门槛尝试',
    audience: '第一次接触',
    cta: '选择一泡体验',
    texture: '/images/banjian-new/brand/mountain-texture-bys.png',
  },
  {
    id: 'seven',
    num: '02',
    name: '七泡盒装',
    desc: '完整路径，深度观察',
    audience: '想完整体验',
    cta: '选择七泡体验',
    texture: '/images/banjian-new/brand/mountain-texture-bys.png',
  },
  {
    id: 'dual',
    num: '03',
    name: '双茶8泡',
    desc: '两款对照，比较观察',
    audience: '想对比两款',
    cta: '选择双茶对照',
    texture: '/images/banjian-new/brand/mountain-texture-bd001.png',
  },
  {
    id: 'fourteen',
    num: '04',
    name: '14天',
    desc: '更长周期观察',
    audience: '有长期习惯',
    cta: '选择长周期观察',
    texture: '/images/banjian-new/brand/mountain-texture-bd001.png',
  },
];

export default function ExperienceMethodSection({ onSelect, selected }: ExperienceMethodSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    const cards = sectionRef.current.querySelectorAll('.method-card-animate');
    gsap.fromTo(
      cards,
      { opacity: 0, y: 30 },
      {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.12,
        scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', toggleActions: 'play none none none' },
      }
    );
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      id="product-methods"
      className="w-full bg-warm-white py-16 md:py-24"
    >
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Header */}
        <div className="mb-6 md:mb-8">
          <SectionEyebrow text="CHOOSE YOUR EXPERIENCE" />
          <h2 className="text-[clamp(1.25rem,3vw,1.75rem)] md:text-[clamp(1.75rem,2.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight tracking-[0.015em]">
            四种方式，进入观察。
          </h2>
        </div>

        {/* 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {methods.map((method) => {
            const isSelected = selected === method.id;
            return (
              <button
                key={method.id}
                onClick={() => onSelect(method.id)}
                className={cn(
                  'method-card-animate relative text-left border-t border-archive-brown-6 py-6 md:py-5',
                  'transition-all duration-200 cursor-pointer overflow-hidden group',
                  'hover:border-tea-gold-30',
                  isSelected
                    ? 'border-tea-gold bg-[rgba(212,168,83,0.03)]'
                    : 'border-archive-brown-6'
                )}
              >
                {/* Mountain texture decoration */}
                <div
                  className="absolute right-0 bottom-0 w-[55%] h-[40%] pointer-events-none opacity-[0.05] group-hover:opacity-[0.09] transition-opacity duration-300"
                  style={{
                    backgroundImage: `url(${method.texture})`,
                    backgroundPosition: 'bottom right',
                    backgroundSize: 'contain',
                    backgroundRepeat: 'no-repeat',
                    mixBlendMode: 'multiply',
                  }}
                />
                <div className="relative z-10">
                <span className="block text-3xl font-serif-zh text-tea-gold">
                  {method.num}
                </span>
                <h3 className="mt-4 text-lg md:text-xl font-serif-zh text-archive-brown">
                  {method.name}
                </h3>
                <p className="mt-2 text-sm md:text-base text-archive-brown-60 leading-relaxed">
                  {method.desc}
                </p>
                <span className="inline-block mt-3 px-3 py-1 rounded text-xs bg-archive-brown-6 text-archive-brown-60">
                  {method.audience}
                </span>
                <div className="mt-4">
                  <span
                    className={cn(
                      'inline-flex items-center justify-center px-6 py-2.5 rounded text-sm font-medium',
                      'transition-all duration-200',
                      isSelected
                        ? 'bg-tea-gold text-archive-brown'
                        : 'bg-archive-brown text-warm-white hover:bg-tea-gold hover:text-archive-brown'
                    )}
                  >
                    {method.cta}
                  </span>
                </div>
                </div>{/* end content layer */}
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
