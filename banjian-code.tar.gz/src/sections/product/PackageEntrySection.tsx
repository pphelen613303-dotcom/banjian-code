import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import FourCardSection from './FourCardSection';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';

gsap.registerPlugin(ScrollTrigger);

interface PackageEntrySectionProps {
  activeProduct: 'bys' | 'bd001';
}

const productData = {
  bys: {
    name: '白莺初霁', id: 'BYS001', archiveNo: 'BYS-2026-0417-A01',
    category: '白茶', origin: '云南·白莺山',
    boxImage: '/images/banjian-new/product/bys-box-closed.jpg',
    material: '茶纤维纸 / 未涂布再生纸', weight: '约350g',
    textureDesc: '温灰白纸张，可见真实纤维',
    coreSentence: '有些变化，只能缓慢发生。',
    sevenCakes: [
      { num: '01', name: '初见', hint: '先别急着评价。喝完后，停五秒。只观察呼吸有没有变化。' },
      { num: '02', name: '渐开', hint: '香气开始慢慢打开。不要急着寻找香型。只观察身体有没有开始放松。' },
      { num: '03', name: '合光', hint: '汤感通常会开始变厚。注意口腔有没有被慢慢撑开。' },
      { num: '04', name: '湿明', hint: '很多变化，往往从这里开始出现。观察：呼吸有没有开始变长。' },
      { num: '05', name: '清和', hint: '甜有时候不会立刻出现。它可能会慢慢向后出现。' },
      { num: '06', name: '微云', hint: '香气不再继续向外扩散，开始慢慢向内收。' },
      { num: '07', name: '余韵', hint: '不要急着结束。停一会儿。记录：现在的身体，像什么状态？' },
    ],
    layers: [
      { title: '外层静默壳', desc: '档案封套式立体盒。第一眼只负责停顿，不负责解释。', detail: '正面仅保留品牌名、产品名、核心句与档案号。像一本等待被打开的观察档案。' },
      { title: '观察展开层', desc: '打开后先见卡片，不直接见茶。', detail: '观察页、时间记录卡、七泡体验卡、身体观察卡、数字入口卡——每一张都是一次观察的入口。' },
      { title: '茶本体层', desc: '7枚8g小圆饼，躺在植物纤维模塑内托中。', detail: '每枚独立编号，从01初见到07余韵。每一枚对应一次冲泡观察，不是七个SKU，而是一次观察的七个节点。' },
    ],
    craft: [
      { label: '纸张', value: '茶纤维纸 / 未涂布再生纸', detail: '可见真实纤维，低干预感' },
      { label: '工艺', value: '低墨量单色印刷 + 压凹', detail: '炭黑不过重，产品名与档案号可压凹' },
      { label: '结构', value: '档案封套式立体盒', detail: '无胶卡扣，可反复开合' },
      { label: '内托', value: '植物纤维模塑', detail: '7位圆饼孔，可再生、无塑' },
    ],
  },
  bd001: {
    name: '石界岩手', id: 'BD001', archiveNo: 'BD001-2026-0410-A01',
    category: '普洱生茶', origin: '云南·邦东',
    boxImage: '/images/banjian-new/product/bd001-box-closed.jpg',
    material: '再生矿物纤维纸 / 岩层压纹纸', weight: '约350g',
    textureDesc: '深矿岩灰，岩石层理纹理',
    coreSentence: '被压缩过的东西，才知道如何支撑。',
    sevenCakes: [
      { num: '01', name: '松动', hint: '先别急着判断它强不强。只观察口腔是否有初始收紧。' },
      { num: '02', name: '试探', hint: '香气可能开始上行。不要急着命名香型。' },
      { num: '03', name: '舒展', hint: '结构开始慢慢松动。观察口腔轮廓是否成形。' },
      { num: '04', name: '结构', hint: '岩韵可能开始穿透。观察喉部有没有被打开。' },
      { num: '05', name: '厚度', hint: '回甘有时会延迟出现。注意支撑感是否停留。' },
      { num: '06', name: '延展', hint: '内部可能慢慢升温。观察身体是否被托住。' },
      { num: '07', name: '沉静', hint: '不要急着结束。停一会儿，观察力量如何回收。' },
    ],
    layers: [
      { title: '外层静默壳', desc: '档案封套式立体盒，深矿岩灰。第一眼感到克制、稳定、有支撑。', detail: '正面只保留产品名、核心句与档案号。岩层线稿横向穿过中下部，不压迫主标题。' },
      { title: '结构观察层', desc: '打开后先进入"结构观察"——像揭开地层。', detail: '观察页、结构/工艺卡、产区与工艺卡、冲泡记录卡——让用户看见压力如何形成、结构如何打开。' },
      { title: '茶本体层', desc: '7枚8g小圆饼，错层内托排列。', detail: '从01松动到07沉静，每枚对应一次释放观察。错层排列模拟地层断裂结构。' },
    ],
    craft: [
      { label: '纸张', value: '再生矿物纤维纸 / 岩层压纹纸', detail: '深矿岩灰，可见岩石层理' },
      { label: '工艺', value: '岩层压纹 + 低墨量 + 盲压', detail: '结构线条盲压，产品名可压凹' },
      { label: '结构', value: '档案封套式立体盒', detail: '无胶卡扣，局部黑绳扣做开合记忆点' },
      { label: '内托', value: '植物纤维模塑，错层排列', detail: '模拟地层断裂结构，可再生' },
    ],
  },
};

export default function PackageEntrySection({ activeProduct }: PackageEntrySectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const data = productData[activeProduct];
  const isBys = activeProduct === 'bys';
  const [mobileHint, setMobileHint] = useState<{ open: boolean; name: string; hint: string } | null>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo('.pkg-header', { opacity: 0, y: 30 }, {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
        scrollTrigger: { trigger: '.pkg-header-wrap', start: 'top 85%' },
      });
      gsap.fromTo('.pkg-hero-img', { opacity: 0, scale: 0.97 }, {
        opacity: 1, scale: 1, duration: 0.9, ease: 'power2.out',
        scrollTrigger: { trigger: '.pkg-hero-img', start: 'top 85%' },
      });
      gsap.fromTo('.pkg-archive-bar', { opacity: 0, y: 16 }, {
        opacity: 1, y: 0, duration: 0.5, delay: 0.3, ease: 'power2.out',
        scrollTrigger: { trigger: '.pkg-archive-bar', start: 'top 90%' },
      });
      gsap.fromTo('.pkg-layer', { opacity: 0, x: -30 }, {
        opacity: 1, x: 0, duration: 0.6, stagger: 0.15, ease: 'power2.out',
        scrollTrigger: { trigger: '.pkg-layers-wrap', start: 'top 80%' },
      });
      gsap.fromTo('.pkg-cake', { opacity: 0, scale: 0.85, y: 20 }, {
        opacity: 1, scale: 1, y: 0, duration: 0.45, stagger: 0.08, ease: 'back.out(1.4)',
        scrollTrigger: { trigger: '.pkg-cakes-wrap', start: 'top 80%' },
      });
      gsap.fromTo('.pkg-craft', { opacity: 0, y: 20 }, {
        opacity: 1, y: 0, duration: 0.5, stagger: 0.1, ease: 'power2.out',
        scrollTrigger: { trigger: '.pkg-craft-wrap', start: 'top 85%' },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, { scope: sectionRef, dependencies: [activeProduct] });

  return (
    <section ref={sectionRef} id="product-package" className="w-full bg-warm-cream py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">

        {/* ===== HEADER ===== */}
        <div className="pkg-header-wrap mb-6 md:mb-8">
          <SectionEyebrow text="PACKAGE AS ENTRY" className="pkg-header" />
          <h2 className="pkg-header text-[clamp(1.25rem,3vw,1.75rem)] md:text-[clamp(1.75rem,2.5vw,2.5rem)] font-serif-zh text-archive-brown leading-tight tracking-[0.015em]">
            四张卡片，把一次观察拆成可以被拿起的内容。
          </h2>
          <p className="pkg-header mt-4 text-sm md:text-base text-archive-brown-60 leading-relaxed max-w-[640px]">
            半见的包装不是把产品包起来，而是把一次观察拆成可以拿起的顺序。
          </p>
        </div>

        {/* ===== HERO: Product Box ===== */}
        <div className="pkg-hero-img relative mb-6 rounded-xl overflow-hidden bg-[rgba(61,50,41,0.02)]">
          <div className="grid grid-cols-1 md:grid-cols-5">
            <div className="md:col-span-3 relative aspect-[4/3] md:aspect-auto">
              <img src={data.boxImage} alt={`${data.name} 档案封套式立体盒`} className="w-full h-full object-cover" loading="lazy"  decoding="async"/>
              <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: `url(${isBys ? '/images/banjian-new/brand/mountain-texture-bys.png' : '/images/banjian-new/brand/mountain-texture-bd001.png'})`, backgroundSize: 'cover', mixBlendMode: 'multiply' }} />
            </div>
            <div className="md:col-span-2 p-6 md:p-8 flex flex-col justify-center border-t md:border-t-0 md:border-l border-archive-brown-6">
              <span className="text-xs font-mono-data text-archive-brown-40 tracking-wider">{data.archiveNo}</span>
              <h3 className="mt-2 text-xl font-serif-zh text-archive-brown">半见｜{data.id} · {data.name}</h3>
              <p className="mt-1 text-sm text-archive-brown-60">{data.category} · {data.origin}</p>
              <p className="mt-4 text-base font-serif-zh text-archive-brown-80 italic leading-relaxed">"{data.coreSentence}"</p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-tea-gold" /><span className="text-xs text-archive-brown-60">7枚 × 8g 小圆饼 · 共56g</span></div>
                <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-tea-gold" /><span className="text-xs text-archive-brown-60">档案封套式立体盒</span></div>
                <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-tea-gold" /><span className="text-xs text-archive-brown-60">{data.material}</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Archive bar */}
        <div className="pkg-archive-bar mb-8 md:mb-12 flex flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3 border-t border-archive-brown-6 pt-5">
          <span className="text-xs font-mono-data text-archive-brown-40">档案号 {data.archiveNo}</span>
          <span className="hidden md:inline text-archive-brown-12">|</span>
          <span className="text-xs text-archive-brown-60">{data.material} · {data.weight}</span>
          <span className="hidden md:inline text-archive-brown-12">|</span>
          <span className="text-xs text-archive-brown-60">{data.textureDesc}</span>
        </div>

        {/* ===== FOUR CARD SYSTEM ===== */}
        <FourCardSection activeProduct={activeProduct} />

      </div>

      {/* ===== MOBILE HINT SHEET ===== */}
      <Sheet open={mobileHint?.open ?? false} onOpenChange={() => setMobileHint(null)}>
        <SheetContent side="bottom" className="h-auto rounded-t-2xl bg-[#FAF9F7] border-t border-archive-brown-6 p-6">
          {mobileHint && (
            <>
              <SheetHeader className="pb-3 mb-3 border-b border-archive-brown-6">
                <SheetTitle className="font-serif-zh text-lg text-archive-brown">第{mobileHint.name}泡</SheetTitle>
              </SheetHeader>
              <p className="text-sm text-archive-brown-70 leading-relaxed">{mobileHint.hint}</p>
            </>
          )}
        </SheetContent>
      </Sheet>
    </section>
  );
}
