import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import SectionEyebrow from '@/components/SectionEyebrow';
import { bysData, bd001Data } from '@/data/comparisonData';
import { Mountain, Leaf, Sun, Droplets, Layers, Wind, Timer, Anchor, Focus, TrendingDown, Maximize, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const originIcons = [Mountain, Layers, Droplets, Leaf, Wind];
const bysProcIcons = [Wind, Maximize, Sun, Timer, Layers, Sun, Leaf];
const bdProcIcons = [Timer, Sun, Wind, Droplets, Sun, Layers, Mountain];
const bysExpIcons = [Wind, Focus, TrendingDown, Maximize];
const bdExpIcons = [Mountain, Anchor, Focus, Mountain];

// ─── Hero Header with full-bleed image ───
function HeroHeader() {
  return (
    <div className="relative w-full overflow-hidden" style={{ height: 'clamp(300px, 38vw, 440px)' }}>
      <img src="/images/banjian-new/comparison-hero-bg.jpg" alt="" className="absolute inset-0 w-full h-full object-cover" loading="eager"  decoding="async"/>
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 65% 55% at 50% 35%, rgba(250,249,247,0.9) 0%, rgba(250,249,247,0.6) 50%, rgba(250,249,247,0.25) 100%)' }} />
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-6 text-center">
        <p className="text-[10px] font-sans-zh tracking-[0.25em] text-archive-brown-50 mb-3">TWO DIRECTIONS</p>
        <h2 className="text-[clamp(1.75rem,4vw,3rem)] font-serif-zh text-archive-brown leading-tight mb-4">两种方向，两种进入身体的方式</h2>
        <p className="text-sm font-sans-zh text-archive-brown-60 max-w-xl leading-relaxed">同一片云南山地，因地质、生态与工艺的不同，生成两种完全不同的身体体验。</p>
      </div>
    </div>
  );
}

// ─── Product Badges (restored) ───
function ProductBadges() {
  return (
    <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-12 py-10 border-b border-archive-brown-12">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: bysData.color }}>
          <Leaf size={18} className="text-warm-white" />
        </div>
        <div className="text-left">
          <p className="text-sm font-serif-zh text-archive-brown">{bysData.name} <span className="text-archive-brown-40 font-mono-data text-xs">{bysData.id}</span></p>
          <p className="text-xs font-sans-zh" style={{ color: bysData.color }}>{bysData.system}｜{bysData.tagline}</p>
        </div>
      </div>
      <span className="hidden sm:block text-archive-brown-20 text-lg">VS</span>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: bd001Data.color }}>
          <Mountain size={18} className="text-warm-white" />
        </div>
        <div className="text-left">
          <p className="text-sm font-serif-zh text-archive-brown">{bd001Data.name} <span className="text-archive-brown-40 font-mono-data text-xs">{bd001Data.id}</span></p>
          <p className="text-xs font-sans-zh" style={{ color: bd001Data.color }}>{bd001Data.system}｜{bd001Data.tagline}</p>
        </div>
      </div>
    </div>
  );
}

// ─── Origin Module ───
function OriginModule() {
  return (
    <div className="comparison-origin relative py-12 md:py-16">
      <SectionEyebrow text="ORIGIN · 生态来源" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 mt-8">
        <div className="p-6 rounded-xl border" style={{ borderColor: 'rgba(27,67,50,0.1)', backgroundColor: 'rgba(250,249,247,0.92)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Leaf size={15} className="text-deep-green" />
            <span className="text-sm font-serif-zh text-deep-green">{bysData.name}｜{bysData.system}</span>
          </div>
          <p className="text-base font-serif-zh text-archive-brown italic leading-relaxed mb-5">"{bysData.origin.quote}"</p>
          <div className="space-y-3">
            {bysData.origin.points.map((p, i) => { const Icon = originIcons[i] || Leaf; return (
              <div key={i} className="flex items-start gap-3">
                <Icon size={14} className="text-deep-green mt-0.5 shrink-0" />
                <span className="text-sm font-sans-zh text-archive-brown-75">{p}</span>
              </div>
            ); })}
          </div>
        </div>
        <div className="p-6 rounded-xl border" style={{ borderColor: 'rgba(139,98,57,0.1)', backgroundColor: 'rgba(250,249,247,0.88)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Mountain size={15} style={{ color: bd001Data.color }} />
            <span className="text-sm font-serif-zh" style={{ color: bd001Data.color }}>{bd001Data.name}｜{bd001Data.system}</span>
          </div>
          <p className="text-base font-serif-zh text-archive-brown italic leading-relaxed mb-5">"{bd001Data.origin.quote}"</p>
          <div className="space-y-3">
            {bd001Data.origin.points.map((p, i) => { const Icon = originIcons[i] || Mountain; return (
              <div key={i} className="flex items-start gap-3">
                <Icon size={14} className="mt-0.5 shrink-0" style={{ color: bd001Data.color }} />
                <span className="text-sm font-sans-zh text-archive-brown-75">{p}</span>
              </div>
            ); })}
          </div>
        </div>
      </div>
      <p className="text-center text-sm font-sans-zh text-archive-brown-50 mt-8 italic">同一片云南山地，不同的地质与生态，生成两种完全不同的系统。</p>
    </div>
  );
}

// ─── Process Module ───
function ProcessModule() {
  return (
    <div className="comparison-process py-12 md:py-16 border-t border-archive-brown-12">
      <SectionEyebrow text="CRAFT · 工艺转化" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 mt-8">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Timer size={15} className="text-deep-green" />
            <span className="text-sm font-serif-zh text-deep-green">{bysData.name}</span>
            <span className="text-xs font-sans-zh text-archive-brown-50 ml-1">{bysData.process.label}</span>
          </div>
          <div className="flex flex-wrap items-center gap-1">
            {bysData.process.steps.map((step, i) => { const Icon = bysProcIcons[i] || Leaf; return (
              <div key={i} className="flex items-center">
                <div className="flex flex-col items-center px-2 py-2 rounded-lg" style={{ backgroundColor: 'rgba(27,67,50,0.06)' }}>
                  <Icon size={14} className="text-deep-green mb-1" />
                  <span className="text-xs font-sans-zh font-medium text-archive-brown">{step.name}</span>
                  <span className="text-[10px] font-sans-zh text-archive-brown-50">{step.body}</span>
                </div>
                {i < bysData.process.steps.length - 1 && <ArrowRight size={12} className="text-archive-brown-20 mx-0.5 shrink-0" />}
              </div>
            ); })}
          </div>
          <div className="mt-4 p-3 rounded-lg border border-deep-green/15" style={{ backgroundColor: 'rgba(27,67,50,0.05)' }}>
            <p className="text-sm font-serif-zh text-deep-green font-medium">工艺抵达：{bysData.process.result}</p>
          </div>
          <p className="text-xs font-sans-zh text-archive-brown-60 mt-3 leading-relaxed">{bysData.process.summary}</p>
        </div>
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Mountain size={15} style={{ color: bd001Data.color }} />
            <span className="text-sm font-serif-zh" style={{ color: bd001Data.color }}>{bd001Data.name}</span>
            <span className="text-xs font-sans-zh text-archive-brown-50 ml-1">{bd001Data.process.label}</span>
          </div>
          <div className="flex flex-wrap items-center gap-1">
            {bd001Data.process.steps.map((step, i) => { const Icon = bdProcIcons[i] || Mountain; return (
              <div key={i} className="flex items-center">
                <div className="flex flex-col items-center px-2 py-2 rounded-lg" style={{ backgroundColor: 'rgba(139,98,57,0.06)' }}>
                  <Icon size={14} className="mb-1" style={{ color: bd001Data.color }} />
                  <span className="text-xs font-sans-zh font-medium text-archive-brown">{step.name}</span>
                  <span className="text-[10px] font-sans-zh text-archive-brown-50">{step.body}</span>
                </div>
                {i < bd001Data.process.steps.length - 1 && <ArrowRight size={12} className="text-archive-brown-20 mx-0.5 shrink-0" />}
              </div>
            ); })}
          </div>
          <div className="mt-4 p-3 rounded-lg border" style={{ borderColor: 'rgba(139,98,57,0.15)', backgroundColor: 'rgba(139,98,57,0.05)' }}>
            <p className="text-sm font-serif-zh font-medium" style={{ color: bd001Data.color }}>工艺抵达：{bd001Data.process.result}</p>
          </div>
          <p className="text-xs font-sans-zh text-archive-brown-60 mt-3 leading-relaxed">{bd001Data.process.summary}</p>
        </div>
      </div>
      <p className="text-center text-sm font-sans-zh text-archive-brown-50 mt-8 italic">低温让时间缓慢转化，高温让结构稳定释放。</p>
    </div>
  );
}

// ─── Experience Module ───
function ExperienceModule() {
  return (
    <div className="comparison-experience py-12 md:py-16 border-t border-archive-brown-12">
      <SectionEyebrow text="BODY · 身体体验" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 mt-8">
        <div className="p-6 rounded-xl border" style={{ borderColor: 'rgba(27,67,50,0.1)', backgroundColor: 'rgba(250,249,247,0.92)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Leaf size={15} className="text-deep-green" />
            <span className="text-sm font-serif-zh text-deep-green">{bysData.name}｜{bysData.system}</span>
          </div>
          <p className="text-sm font-sans-zh text-archive-brown-60 mb-5">{bysData.experience.quote}</p>
          <div className="grid grid-cols-2 gap-4 mb-6">
            {bysData.experience.points.map((pt, i) => { const Icon = bysExpIcons[i] || Wind; return (
              <div key={i} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: 'rgba(27,67,50,0.1)' }}>
                  <Icon size={14} className="text-deep-green" />
                </div>
                <div>
                  <p className="text-sm font-sans-zh font-medium text-archive-brown">{pt.label}</p>
                  <p className="text-xs font-sans-zh text-archive-brown-50">{pt.desc}</p>
                </div>
              </div>
            ); })}
          </div>
          <div className="pt-4 border-t" style={{ borderColor: 'rgba(27,67,50,0.1)' }}>
            <p className="text-sm font-serif-zh text-deep-green italic">{bysData.experience.closing}</p>
            <p className="text-xs font-sans-zh text-archive-brown-60 mt-2">{bysData.experience.essence}</p>
          </div>
        </div>
        <div className="p-6 rounded-xl border" style={{ borderColor: 'rgba(139,98,57,0.1)', backgroundColor: 'rgba(250,249,247,0.88)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Mountain size={15} style={{ color: bd001Data.color }} />
            <span className="text-sm font-serif-zh" style={{ color: bd001Data.color }}>{bd001Data.name}｜{bd001Data.system}</span>
          </div>
          <p className="text-sm font-sans-zh text-archive-brown-60 mb-5">{bd001Data.experience.quote}</p>
          <div className="grid grid-cols-2 gap-4 mb-6">
            {bd001Data.experience.points.map((pt, i) => { const Icon = bdExpIcons[i] || Mountain; return (
              <div key={i} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: 'rgba(139,98,57,0.1)' }}>
                  <Icon size={14} style={{ color: bd001Data.color }} />
                </div>
                <div>
                  <p className="text-sm font-sans-zh font-medium text-archive-brown">{pt.label}</p>
                  <p className="text-xs font-sans-zh text-archive-brown-50">{pt.desc}</p>
                </div>
              </div>
            ); })}
          </div>
          <div className="pt-4 border-t" style={{ borderColor: 'rgba(139,98,57,0.1)' }}>
            <p className="text-sm font-serif-zh italic" style={{ color: bd001Data.color }}>{bd001Data.experience.closing}</p>
            <p className="text-xs font-sans-zh text-archive-brown-60 mt-2">{bd001Data.experience.essence}</p>
          </div>
        </div>
      </div>
    </div>
  );
}



// ─── Main ───

interface ComparisonSectionProps {
  activeProduct: 'bys' | 'bd001';
  onSwitch: (product: 'bys' | 'bd001') => void;
}

export default function ComparisonSection({ activeProduct, onSwitch }: ComparisonSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const isBys = activeProduct === 'bys';

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.comparison-hero > *', { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out',
      scrollTrigger: { trigger: '.comparison-hero', start: 'top 85%' },
    });
    gsap.fromTo('.comparison-badges > *', { opacity: 0, y: 20 }, {
      opacity: 1, y: 0, duration: 0.5, stagger: 0.08, ease: 'power2.out',
      scrollTrigger: { trigger: '.comparison-badges', start: 'top 90%' },
    });
    ['.comparison-origin', '.comparison-process', '.comparison-experience', '.comparison-closing'].forEach((cls) => {
      gsap.fromTo(`${cls} > *`, { opacity: 0, y: 24 }, {
        opacity: 1, y: 0, duration: 0.5, stagger: 0.08, ease: 'power2.out',
        scrollTrigger: { trigger: cls, start: 'top 85%' },
      });
    });
  }, { scope: sectionRef, dependencies: [activeProduct] });

  return (
    <section ref={sectionRef} className="w-full bg-warm-white">
      {/* Hero header */}
      <div className="comparison-hero">
        <HeroHeader />
      </div>

      <div className="max-w-6xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16">
        {/* Product badges — restored */}
        <div className="comparison-badges">
          <ProductBadges />
        </div>

        {/* Desktop: both products */}
        <div className="hidden lg:block">
          <OriginModule />
          <ProcessModule />
          <ExperienceModule />
        </div>

        {/* Mobile: single product */}
        <div className="lg:hidden">
          <OriginModule />
          <ProcessModule />
          <ExperienceModule />
          {/* Mobile switcher */}
          <div className="flex items-center justify-center gap-6 py-6 border-t border-archive-brown-12">
            <button onClick={() => onSwitch('bys')} className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-sans-zh transition-all ${isBys ? 'bg-deep-green text-warm-white' : 'bg-archive-brown-8 text-archive-brown-60'}`}>
              <Leaf size={14} />白莺初霁
            </button>
            <button onClick={() => onSwitch('bd001')} className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-sans-zh transition-all ${!isBys ? 'text-warm-white' : 'bg-archive-brown-8 text-archive-brown-60'}`} style={!isBys ? { backgroundColor: bd001Data.color } : {}}>
              <Mountain size={14} />石界岩手
            </button>
          </div>
        </div>


      </div>
    </section>
  );
}
