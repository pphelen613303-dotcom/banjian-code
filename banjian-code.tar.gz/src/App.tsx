import { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router';
import Layout from './components/Layout';

/* ═══════════════════════════════════════════
   Code-split page components — each page
   loads on demand, reducing initial bundle
   from ~768KB to ~200-300KB + page chunks
   ═══════════════════════════════════════════ */

const Home = lazy(() => import('./pages/Home'));
const Product = lazy(() => import('./pages/Product'));
const Observe = lazy(() => import('./pages/Observe'));
const Origin = lazy(() => import('./pages/Origin'));
const Value = lazy(() => import('./pages/Value'));
const About = lazy(() => import('./pages/About'));

/** Minimal fallback — no visual change, just prevents React
 *  from throwing while the chunk loads. The page transition
 *  feels instant because chunks are small. */
function PageFallback() {
  return (
    <div className="min-h-[50dvh] flex items-center justify-center">
      <div className="w-6 h-6 border-2 border-archive-brown-12 border-t-tea-gold rounded-full animate-spin" />
    </div>
  );
}

export default function App() {
  return (
    <Layout>
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/product" element={<Product />} />
          <Route path="/observe" element={<Observe />} />
          <Route path="/origin" element={<Origin />} />
          <Route path="/value" element={<Value />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}
