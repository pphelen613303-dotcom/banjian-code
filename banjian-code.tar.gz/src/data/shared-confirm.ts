import type { ConfirmPerson } from '@/types';

export const sharedConfirmPeople: ConfirmPerson[] = [
  {
    role: '采摘确认',
    name: '财源',
    responsibility: '确认鲜叶来源、采摘批次与现场重量',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: undefined,
  },
  {
    role: '工艺确认',
    name: '黄德彪',
    responsibility: '确认萎凋、杀青等关键工艺状态',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: '30年/晒青白茶红茶S级',
  },
  {
    role: '揉捻与协作',
    name: '陆贵平',
    responsibility: '确认揉捻、摊晾、晒青等现场执行',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: '年限+等级',
  },
  {
    role: '监匠确认',
    name: '严庄',
    responsibility: '确认整批茶的工艺判断与品质边界',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: '30年/晒青白茶红茶S级',
  },
  {
    role: '记录确认',
    name: '张东冬',
    responsibility: '确认现场记录、起堆、复核与档案提交',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: '年限+等级',
  },
  {
    role: '品牌确认',
    name: '半见',
    responsibility: '确认产品档案、价值流向与用户入口保持一致',
    confirmStatus: 'confirmed',
    confirmTime: '2026年春',
    archive: undefined,
  },
];

export const confirmSummary = {
  totalPeople: 6,
  totalNodes: 7,
  totalEvidence: 12,
};
