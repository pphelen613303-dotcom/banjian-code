/**
 * 半见茶觉七天观察 — 每日引导数据
 * 来源：半见茶觉七天观察_海报引流_H5承接执行文档_V1.md
 *
 * 核心理念：每天一杯茶，只观察一件事
 */

export interface DayGuide {
  day: number;
  theme: string;           // 主题：香气/滋味/...
  title: string;           // 引导标题
  plainTip: string;        // 白话提示（核心观察问题）
  keywords: string[];      // 重点词（用于视觉强化）
  recordPrompt: string;    // 一句话记录提示
  examples: string[];      // 记录示例
  warmReminder?: string;   // 温和提醒（Day4专用）
}

export const dayGuides: DayGuide[] = [
  {
    day: 1,
    theme: '香气',
    title: '先别急着喝，看看这杯茶是怎么靠近你的',
    plainTip: '闻起来，你想不想继续喝？',
    keywords: ['香气', '靠近', '想不想'],
    recordPrompt: '这杯茶的香气，让我感觉……',
    examples: [
      '闻起来有点甜，我想继续喝。',
      '香气很明显，但闻久了有点累。',
    ],
  },
  {
    day: 2,
    theme: '滋味',
    title: '第一口，不只是好不好喝',
    plainTip: '第一口，是舒服，还是刺激？',
    keywords: ['第一口', '舒服', '刺激'],
    recordPrompt: '第一口最明显的是……它让我……',
    examples: [
      '第一口有点苦，但不讨厌，后面有一点甜。',
      '入口先是苦，舌面有一点涩，但咽下去以后没有卡住。',
    ],
  },
  {
    day: 3,
    theme: '喉咙与汤感',
    title: '有些茶，是嘴巴喜欢；有些茶，是身体愿意',
    plainTip: '咽下去以后，顺不顺？干不干？',
    keywords: ['咽下去', '顺', '干'],
    recordPrompt: '这杯茶经过喉咙时，我感觉……',
    examples: [
      '咽下去挺顺的，喉咙没有干，还想喝。',
      '入口甜，但咽下去以后喉咙有点紧，身体没那么想继续。',
    ],
  },
  {
    day: 4,
    theme: '身体',
    title: '别急着问别人好不好，先问身体接住了吗',
    plainTip: '喝完以后，身体是松了，还是更紧了？',
    keywords: ['身体', '松', '紧'],
    recordPrompt: '这杯茶，我的身体接住了吗？为什么？',
    examples: [
      '喝完身体有点暖，肩膀松了一点。',
      '前两泡舒服，第三泡以后头有点浮，感觉今天不适合喝太浓。',
    ],
    warmReminder: '如果喝完明显不舒服，可以少喝、淡喝、不要空腹喝。半见茶觉只做身体观察，不做健康诊断。',
  },
  {
    day: 5,
    theme: '情绪',
    title: '一杯茶，不一定解决问题；但它能让你慢慢回来',
    plainTip: '喝完以后，人有没有安静一点？',
    keywords: ['安静', '回来', '情绪'],
    recordPrompt: '喝茶前我……喝完后我……',
    examples: [
      '喝之前有点烦，喝完安静了一点。',
      '喝到第四泡时，突然不太想说话，心里没有那么急了。',
    ],
  },
  {
    day: 6,
    theme: '七泡时间',
    title: '真正的好茶，不只在第一口',
    plainTip: '喝到后面，它还有没有东西留下？',
    keywords: ['后面', '留下', '七泡'],
    recordPrompt: '喝到后面，它还留下了……',
    examples: [
      '前面香，后面淡了，但第七泡还是舒服。',
      '第一泡很轻，第三泡开始有力量，第五泡变柔，第七泡虽然淡，但喉咙里还有一点甜。',
    ],
  },
  {
    day: 7,
    theme: '复盘',
    title: '七天以后，不急着懂茶；先看看自己变得更清楚了吗',
    plainTip: '这七天，你更了解自己一点了吗？',
    keywords: ['七天', '了解自己', '清楚'],
    recordPrompt: '这七天，我通过茶看见了自己……',
    examples: [
      '这七天我发现，我以前只注意香不香，很少注意身体舒不舒服。',
      '我发现自己最容易被第一口吸引，但真正让我安静的是后面的几泡。',
    ],
  },
];

export function getDayGuide(day: number): DayGuide {
  return dayGuides.find((g) => g.day === day) || dayGuides[0];
}
