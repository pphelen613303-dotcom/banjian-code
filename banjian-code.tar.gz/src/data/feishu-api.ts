/**
 * 半见茶觉 - 飞书数据桥接API
 * 后端地址: https://feishu-bridge-dlfmkddnhg.cn-hangzhou.fcapp.run
 */

const BASE_URL = 'https://feishu-bridge-dlfmkddnhg.cn-hangzhou.fcapp.run';
const API_KEY = 'banjian_query_key_2024';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export interface DailyRecordPayload {
  user_id: string;
  day: number;
  tea_type: 'bys' | 'bd001' | 'custom';
  custom_tea_name?: string;  // user-defined tea name when tea_type is 'custom'
  infusion?: number;
  body_feeling: string;
  feeling_tags: string[];
  content?: string;
  timestamp: string;
}

export interface WeeklyReviewPayload {
  user_id: string;
  overall_feeling: string;
  most_impressed_day: number;
  body_changes: string;
  continue_observation: boolean;
  suggestions?: string;
  timestamp: string;
}

export interface ApiResponse {
  success: boolean;
  service: string;
  version: string;
  // backend may return additional fields
  data?: unknown;
  message?: string;
}

/* ------------------------------------------------------------------ */
/*  User ID management                                                 */
/* ------------------------------------------------------------------ */

const USER_ID_KEY = 'banjian_user_id';

export function getUserId(): string {
  let uid: string | null = null;
  try { uid = localStorage.getItem(USER_ID_KEY); } catch { /* ignore */ }
  if (!uid) {
    // Generate anonymous user ID: banjian_{timestamp}_{random}
    uid = `banjian_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    try { localStorage.setItem(USER_ID_KEY, uid); } catch { /* ignore */ }
  }
  return uid;
}

export function clearUserId(): void {
  try { localStorage.removeItem(USER_ID_KEY); } catch { /* ignore */ }
}

/* ------------------------------------------------------------------ */
/*  API helpers                                                        */
/* ------------------------------------------------------------------ */

async function post<T>(endpoint: string, body: T): Promise<ApiResponse> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return res.json() as Promise<ApiResponse>;
}

/* ------------------------------------------------------------------ */
/*  API functions                                                      */
/* ------------------------------------------------------------------ */

/** Submit a daily observation record */
export async function submitDailyRecord(payload: Omit<DailyRecordPayload, 'user_id' | 'timestamp'>): Promise<ApiResponse> {
  return post('/daily-record/create', {
    ...payload,
    user_id: getUserId(),
    timestamp: new Date().toISOString(),
  });
}

/** Submit a weekly (7-day) review */
export async function submitWeeklyReview(payload: Omit<WeeklyReviewPayload, 'user_id' | 'timestamp'>): Promise<ApiResponse> {
  return post('/weekly-review/create', {
    ...payload,
    user_id: getUserId(),
    timestamp: new Date().toISOString(),
  });
}

/** Check backend health */
export async function checkHealth(): Promise<ApiResponse> {
  const res = await fetch(`${BASE_URL}/health`);
  return res.json() as Promise<ApiResponse>;
}

/** Query report — NOTE: backend has a routing bug, may not work directly */
export async function queryReport(identifier: string, type: 'user_id' | 'round_id' = 'user_id'): Promise<ApiResponse> {
  const url = new URL(`${BASE_URL}/query-report`);
  url.searchParams.set('identifier', identifier);
  url.searchParams.set('type', type);

  const res = await fetch(url.toString(), {
    headers: { 'X-API-Key': API_KEY },
  });
  return res.json() as Promise<ApiResponse>;
}

/** WeChat auth */
export async function wxAuth(code: string): Promise<ApiResponse> {
  return post('/wx-auth', { code });
}
