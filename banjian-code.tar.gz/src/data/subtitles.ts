import type { SubtitleSegment } from '@/types';

// Day 1: 香气
export const day1Segments: SubtitleSegment[] = [
  { id: 1, text: '很多人喝茶一上来就急着问：这茶好不好，香不香，值不值。', keywords: ['判断'] },
  { id: 2, text: '但半见茶觉的第一天，我们先不急着判断。今天只做一件事：观察香气。', keywords: ['香气'] },
  { id: 3, text: '香气，是一杯茶靠近你的第一种方式。', keywords: ['靠近'] },
  { id: 4, text: '人的嗅觉比味觉灵敏一万倍。茶还没入口，香气已经在告诉你的大脑：这杯茶你想不想靠近。', keywords: ['嗅觉'] },
  { id: 5, text: '有些香气很直接，一下子就冲到你面前。有些香气很轻，像山里的雾，慢慢打开。', keywords: ['香气类型'] },
  { id: 6, text: '中国茶的观察，不是从判断开始的，而是从感受开始。', keywords: ['感受'] },
  { id: 7, text: '今天你只需要记住一句很简单的话：闻起来我想不想继续喝。', keywords: ['prompt'] },
  { id: 8, text: '真实，就已经足够。', keywords: ['真实'] },
];

// Day 2: 滋味
export const day2Segments: SubtitleSegment[] = [
  { id: 1, text: '茶觉第二天，我们开始观察第一口茶汤。', keywords: ['滋味'] },
  { id: 2, text: '很多人喝茶最容易注意到的是滋味：甜不甜、苦不苦、涩不涩、厚不厚。', keywords: ['口感'] },
  { id: 3, text: '不要只问它是什么味道，还要问这些味道之间有没有秩序。', keywords: ['秩序'] },
  { id: 4, text: '苦是尖锐地顶出来，还是干净地出现又慢慢化开。', keywords: ['苦'] },
  { id: 5, text: '涩是卡在嘴里，还是很快转成回甘。', keywords: ['涩', '回甘'] },
  { id: 6, text: '真正高级的甜，从来不一定是直接给你的。有些甜需要时间慢慢转回来。', keywords: ['回甘'] },
  { id: 7, text: '今天只需要写一句：第一口最明显的是什么？它让我……', keywords: ['记录'] },
];

// Day 3: 咽喉与汤感
export const day3Segments: SubtitleSegment[] = [
  { id: 1, text: '第三天，我们从嘴巴往下走一点，观察喉咙。', keywords: ['咽喉'] },
  { id: 2, text: '一杯茶真正能不能被身体接住，喉咙常常会先告诉你。', keywords: ['身体'] },
  { id: 3, text: '茶汤经过喉咙时，茶多酚和生物碱会直接刺激黏膜。顺滑还是发干，是身体最诚实的反馈。', keywords: ['茶多酚'] },
  { id: 4, text: '有些茶入口很好喝，但咽下去以后喉咙发干发紧。', keywords: ['发干'] },
  { id: 5, text: '有些茶不那么张扬，但很顺。它经过喉咙的时候是润的，是打开的。', keywords: ['顺滑'] },
  { id: 6, text: '喉咙，常常是"嘴巴喜欢"和"身体愿意"之间的第一道门。', keywords: ['觉察'] },
];

// Day 4: 观察身体
export const day4Segments: SubtitleSegment[] = [
  { id: 1, text: '第四天，我们进入半见茶觉里很重要的一步：观察身体。', keywords: ['身体'] },
  { id: 2, text: '不是为了把茶说得神秘，只是诚实地问自己：喝之前我的身体是什么状态？喝完以后有没有变化？', keywords: ['变化'] },
  { id: 3, text: '茶汤中的咖啡碱、茶氨酸、芳香物质进入血液后，会通过循环系统影响全身。', keywords: ['咖啡碱'] },
  { id: 4, text: '有些茶让人暖，有些茶让胃里舒服，有些茶让呼吸变深，有些茶让肩颈慢慢松下来。', keywords: ['暖', '松'] },
  { id: 5, text: '但也有些茶会让人心慌、发虚浮起来。这些都不是对错，只是身体在告诉你发生了什么。', keywords: ['浮', '紧'] },
  { id: 6, text: '半见茶觉想请你先问身体：我有没有接住它？', keywords: ['接住'] },
];

// Day 5: 观察情绪
export const day5Segments: SubtitleSegment[] = [
  { id: 1, text: '第五天，我们观察情绪。', keywords: ['情绪'] },
  { id: 2, text: '有些茶喝完，人会安静一点。有些茶喝到后面，心会柔一点。', keywords: ['安静'] },
  { id: 3, text: '生活里很多时候，我们不是缺一个答案，而是太快了、太满了、太紧了。', keywords: ['慢'] },
  { id: 4, text: '茶氨酸能穿过血脑屏障，促进α脑波生成，让人放松而不困倦。这不是感觉，是科学。', keywords: ['茶氨酸'] },
  { id: 5, text: '所以喝完茶，人是真的会安静一点。', keywords: ['安静'] },
  { id: 6, text: '茶不一定替你解决问题，但有时候它能让你不那么散地面对自己。', keywords: ['面对'] },
];

// Day 6: 七泡时间
export const day6Segments: SubtitleSegment[] = [
  { id: 1, text: '第六天，我们做一次七泡观察。这是半见茶觉里非常核心的一天。', keywords: ['七泡'] },
  { id: 2, text: '很多人喝茶只追前几泡，但一杯中国茶真正的秩序往往要喝到后面才看得出来。', keywords: ['秩序'] },
  { id: 3, text: '前段看它如何出现，中段看它如何展开，后段看它是否稳定。', keywords: ['节奏'] },
  { id: 4, text: '每一泡释放的物质不同。芳香物质最先析出，茶多酚和咖啡碱在中段释放，氨基酸和糖类则持续到后段。', keywords: ['内含物'] },
  { id: 5, text: '中国原叶茶的完整性，从来不只是为了好看。叶片完整，内含物才会按照自然的节律一层一层释放出来。', keywords: ['完整'] },
  { id: 6, text: '你尊重它的完整，它便用完整回馈你。', keywords: ['尊重'] },
];

// Day 7: 七天复盘
export const day7Segments: SubtitleSegment[] = [
  { id: 1, text: '第七天，我们不急着学习新的东西。今天只回头看一看。', keywords: ['复盘'] },
  { id: 2, text: '看看这七天里，一杯茶是怎么一点一点把你带回自己身上的。', keywords: ['自己'] },
  { id: 3, text: '你可能没有得到一个标准答案，但也许你已经知道：什么茶让我舒服，什么时刻我最需要茶。', keywords: ['发现'] },
  { id: 4, text: '真正的茶觉，不是先学会说对，而是先学会听见自己。', keywords: ['听见'] },
  { id: 5, text: '连续七天观察身体和情绪，是在练习一种叫"内感受"的能力。', keywords: ['内感受'] },
  { id: 6, text: '七天不一定让你立刻变得专业，但它可能让你第一次发现：原来身体一直在回答，只是以前我没有认真听。', keywords: ['觉察'] },
];

// All segments combined
export const allSegments: Record<number, SubtitleSegment[]> = {
  1: day1Segments,
  2: day2Segments,
  3: day3Segments,
  4: day4Segments,
  5: day5Segments,
  6: day6Segments,
  7: day7Segments,
};
