/**
 * 古树茶五维生命图 — 维度数据
 * 位置基于无字版图 percentage 坐标
 */

export interface TreeDimension {
  id: string;
  num: string;
  name: string;
  color: string;
  coreJudgment: string;
  description: string;
  // 标签位置（左右两侧）
  label: {
    side: 'left' | 'right';
    top: string; // percentage
  };
  // 树上热区位置
  hotspot: {
    left: string;
    top: string;
    width: string;
    height: string;
  };
}

export const treeDimensions: TreeDimension[] = [
  {
    id: 'sensory',
    num: '01',
    name: '感官活力',
    color: '#D4A853',
    coreJudgment: '它怎样一泡一泡打开',
    description:
      '感官活力不是第一口有多惊艳，而是这杯茶能不能一泡一泡继续展开。香气、滋味、汤感如果有层次、有变化，感官就不只是刺激，而会把人慢慢带进更深的感受里。真正的好茶，不急着证明自己，而是让你愿意继续喝下去。',
    label: { side: 'left', top: '18%' },
    hotspot: { left: '26%', top: '12%', width: '22%', height: '28%' },
  },
  {
    id: 'body',
    num: '02',
    name: '身体根基',
    color: '#1B4332',
    coreJudgment: '身体是否愿意接住',
    description:
      '身体根基问的不是"好不好喝"，而是这杯茶进入身体以后，你是更稳了，还是更散了。有些茶入口讨喜，却让喉咙发紧、心神发浮；有些茶不抢味道，却让呼吸慢一点，肩膀松一点。身体比评价更诚实，它会告诉你，这杯茶值不值得继续靠近。',
    label: { side: 'left', top: '42%' },
    hotspot: { left: '34%', top: '38%', width: '16%', height: '26%' },
  },
  {
    id: 'information',
    num: '03',
    name: '信息密度',
    color: '#C17B5F',
    coreJudgment: '来处是否可以追问',
    description:
      '信息密度不是故事多不多，而是这杯茶的来处、过程和关系，能不能被继续追问。它从哪里来，经过谁的手，如何进入你手中，这些不是附加说明，而是茶的生命履历。看得见的来处，会让信任不再悬空，也让一杯茶重新从商品变回生命。',
    label: { side: 'right', top: '22%' },
    hotspot: { left: '54%', top: '14%', width: '20%', height: '26%' },
  },
  {
    id: 'cultural',
    num: '04',
    name: '文化身份',
    color: '#3D3229',
    coreJudgment: '谁的判断在里面',
    description:
      '文化身份不是给茶贴上几个好听的标签，而是看这杯茶里，是否真的有人的判断、手艺和分寸。什么时候等，什么时候收，什么时候不再用力，这些选择让茶拥有了性格。文化如果只停在话术里，就是包装；文化进入动作和判断，才会成为这杯茶真正的身份。',
    label: { side: 'right', top: '46%' },
    hotspot: { left: '58%', top: '44%', width: '22%', height: '24%' },
  },
  {
    id: 'ethics',
    num: '05',
    name: '系统伦理',
    color: '#5B7B6F',
    coreJudgment: '价值是否回到土地与人',
    description:
      '系统伦理关心的，不只是你买到一杯茶，更是这杯茶创造的价值去了哪里。它有没有回到茶农、手艺、土地、记录与未来，而不是只停在消费终点。半见不是用它来宣称完美公平，而是让价值关系先被看见。看见之后，才可能更负责任地继续选择。',
    label: { side: 'right', top: '72%' },
    hotspot: { left: '30%', top: '74%', width: '40%', height: '18%' },
  },
];
