import type { ValueFlowItem } from '@/types';

export const bysValueFlow: ValueFlowItem[] = [
  { name: '鲜叶', percent: 24.1, amount: 8.89, actor: '茶农财源', meaning: '茶农获得公平报酬', icon: 'leaf' },
  { name: '工费', percent: 7.3, amount: 2.69, actor: '工艺团队', meaning: '制茶师的劳动被尊重', icon: 'wrench' },
  { name: '固定成本', percent: 7.0, amount: 2.58, actor: '生产系统', meaning: '设备和场地持续运转', icon: 'building' },
  { name: '溯源开销', percent: 12.4, amount: 4.58, actor: '溯源团队', meaning: '每一步都被记录和验证', icon: 'clipboard-check' },
  { name: '品牌运营', percent: 14.9, amount: 5.50, actor: '半见团队', meaning: '品牌让好茶被看见', icon: 'sparkles' },
  { name: '物流售后', percent: 7.0, amount: 2.58, actor: '物流伙伴', meaning: '茶安全到达你手中', icon: 'truck' },
  { name: '生态回流', percent: 9.0, amount: 3.32, actor: '生态基金', meaning: '古茶园被持续保护', icon: 'tree-pine' },
  { name: '成本回收', percent: 18.3, amount: 6.73, actor: '再生产', meaning: '让下一季的茶成为可能', icon: 'refresh-cw' },
];

export const bd001ValueFlow: ValueFlowItem[] = [
  { name: '鲜叶', percent: 18.1, amount: 5.41, actor: '茶农财源', meaning: '茶农获得公平报酬', icon: 'leaf' },
  { name: '工费', percent: 13.4, amount: 4.01, actor: '工艺团队', meaning: '制茶师的劳动被尊重', icon: 'wrench' },
  { name: '固定成本', percent: 4.7, amount: 1.42, actor: '生产系统', meaning: '设备和场地持续运转', icon: 'building' },
  { name: '溯源开销', percent: 8.1, amount: 2.43, actor: '溯源团队', meaning: '每一步都被记录和验证', icon: 'clipboard-check' },
  { name: '品牌运营', percent: 18.1, amount: 5.41, actor: '半见团队', meaning: '品牌让好茶被看见', icon: 'sparkles' },
  { name: '物流售后', percent: 7.0, amount: 2.09, actor: '物流伙伴', meaning: '茶安全到达你手中', icon: 'truck' },
  { name: '生态回流', percent: 9.0, amount: 2.69, actor: '生态基金', meaning: '古茶园被持续保护', icon: 'tree-pine' },
  { name: '成本回收', percent: 21.5, amount: 6.42, actor: '再生产', meaning: '让下一季的茶成为可能', icon: 'refresh-cw' },
];

export const valueFlowByProduct: Record<string, { price: number; items: ValueFlowItem[] }> = {
  BYS001: { price: 36.9, items: bysValueFlow },
  BD001: { price: 29.9, items: bd001ValueFlow },
};

export const getValueFlowByProductId = (id: 'BYS001' | 'BD001') => valueFlowByProduct[id];
