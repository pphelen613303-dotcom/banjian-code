// ───────────────────────────────────────────────
// Four Card System Data — 完整文案版
// ───────────────────────────────────────────────

export interface Dimension {
  label: string;
  summary: string;
  lines: string[];
}

export interface FourCard {
  id: string;
  number: string;
  titleCn: string;
  titleEn: string;
  intro: string;
  stateLabel: string;
  dimensions: Dimension[];
  closing: string;
  bgImage: string;
}

// ─── BYS 白莺初霁 ───
export const bysFourCards: FourCard[] = [
  {
    id: 'observation',
    number: '01',
    titleCn: '观察卡',
    titleEn: 'Observation Card',
    intro: '身体在这一杯茶中如何变化',
    stateLabel: '轻缓延展态',
    dimensions: [
      {
        label: '呼吸',
        summary: '从外部节奏，慢慢转向内部节奏',
        lines: ['从外部节奏，慢慢转向内部节奏', '呼吸变长，但变轻，不再急促'],
      },
      {
        label: '注意力',
        summary: '从"看外界"变成"感受身体"',
        lines: ['从"看外界"变成"感受身体"', '注意力开始向内收拢'],
      },
      {
        label: '身体状态',
        summary: '肩颈松开，身体边界变柔',
        lines: ['肩颈开始松开', '胸口压力下降', '身体边界变柔'],
      },
      {
        label: '时间感',
        summary: '时间不再是线性流动',
        lines: ['时间不再是线性流动', '而是"慢慢展开的空间感"'],
      },
    ],
    closing: '身体正在进入一种"慢下来但更清晰"的状态',
    bgImage: '/images/banjian-new/cards/bys-observation-bg.png',
  },
  {
    id: 'structure',
    number: '02',
    titleCn: '结构卡',
    titleEn: 'Structure Card',
    intro: '为什么这杯茶会让身体变慢',
    stateLabel: '慢释放风味结构',
    dimensions: [
      {
        label: '地质系统',
        summary: '白莺山位于澜沧江断裂带',
        lines: ['白莺山位于澜沧江断裂带', '多岩层混合结构（灰岩 / 花岗岩 / 砂岩）'],
      },
      {
        label: '土壤系统',
        summary: '高矿物复杂度土壤',
        lines: ['高矿物复杂度土壤', '酸性来源多重叠加，不是单一酸性'],
      },
      {
        label: '生态系统',
        summary: '菌丝网络极其发达',
        lines: ['菌丝网络极其发达', '茶树与微生物形成共享营养系统'],
      },
      {
        label: '茶树系统',
        summary: '有性繁殖导致高度分化',
        lines: ['有性繁殖导致高度分化', '每一棵茶树都是独立表达'],
      },
    ],
    closing: '复杂生境 → 慢释放风味结构',
    bgImage: '/images/banjian-new/cards/bys-structure-bg.png',
  },
  {
    id: 'origin',
    number: '03',
    titleCn: '溯源卡',
    titleEn: 'Origin Card',
    intro: '这杯茶从哪里生成',
    stateLabel: '',
    dimensions: [
      {
        label: '地质起源',
        summary: '喜马拉雅构造延伸带',
        lines: ['喜马拉雅构造延伸带', '长期板块碰撞形成破碎山体'],
      },
      {
        label: '生态起源',
        summary: '森林边缘 → 半野生过渡区',
        lines: ['森林边缘 → 半野生过渡区 → 人工极低干预'],
      },
      {
        label: '人类起源',
        summary: '山地居群的"有性繁殖种植方式"',
        lines: ['山地居群的"有性繁殖种植方式"', '决定茶树非标准化生长'],
      },
      {
        label: '茶树起源',
        summary: '野生型 + 过渡型 + 栽培型',
        lines: ['野生型 + 过渡型 + 栽培型混合共存'],
      },
    ],
    closing: '这不是产地，这是"持续生成的系统"',
    bgImage: '/images/banjian-new/cards/bys-origin-bg.png',
  },
  {
    id: 'brewing',
    number: '04',
    titleCn: '冲泡卡',
    titleEn: 'Brewing Card',
    intro: '如何进入这个系统',
    stateLabel: '',
    dimensions: [
      {
        label: '投茶',
        summary: '8g',
        lines: ['8g'],
      },
      {
        label: '水温',
        summary: '90–95°C',
        lines: ['90–95°C'],
      },
      {
        label: '注水方式',
        summary: '缓慢注水',
        lines: ['缓慢注水，让茶汤逐渐展开'],
      },
      {
        label: '时间结构',
        summary: '1–2泡感知启动 → 3–5泡稳定 → 6泡后延展',
        lines: ['1–2泡：感知启动', '3–5泡：身体进入稳定慢状态', '6泡以后：时间感明显拉长'],
      },
    ],
    closing: '冲泡不是方法，是进入身体状态的开关',
    bgImage: '/images/banjian-new/cards/bys-brewing-bg.png',
  },
];

// ─── BD001 石界岩手 ───
export const bd001FourCards: FourCard[] = [
  {
    id: 'observation',
    number: '01',
    titleCn: '观察卡',
    titleEn: 'Observation Card',
    intro: '身体在这一杯茶中如何变化',
    stateLabel: '稳定支撑态',
    dimensions: [
      {
        label: '呼吸',
        summary: '呼吸更深，节奏变稳定',
        lines: ['呼吸更深', '但节奏变稳定，不再起伏'],
      },
      {
        label: '注意力',
        summary: '不再分散，单点稳定聚焦',
        lines: ['不再分散', '变成单点稳定聚焦'],
      },
      {
        label: '身体状态',
        summary: '下沉感增强，身体重心变低',
        lines: ['下沉感增强', '身体重心变低', '更"有支撑感"'],
      },
      {
        label: '时间感',
        summary: '时间变成结构化单位',
        lines: ['时间变成结构化单位', '更清晰、更可感知'],
      },
    ],
    closing: '身体进入一种"稳定但更清醒"的状态',
    bgImage: '/images/banjian-new/cards/bd-observation-bg.png',
  },
  {
    id: 'structure',
    number: '02',
    titleCn: '结构卡',
    titleEn: 'Structure Card',
    intro: '为什么这杯茶会让身体变稳',
    stateLabel: '稳定风味生成系统',
    dimensions: [
      {
        label: '地质系统',
        summary: '花岗岩侵入体结构',
        lines: ['花岗岩侵入体结构', '岩层密度高，结构稳定'],
      },
      {
        label: '矿物系统',
        summary: '钠角闪石 / 辉石丰富',
        lines: ['钠角闪石 / 辉石丰富', '天然钠离子来源'],
      },
      {
        label: '土壤系统',
        summary: '薄层土壤 + 岩缝结构',
        lines: ['薄层土壤 + 岩缝结构', '茶树深入岩体生长'],
      },
      {
        label: '水文系统',
        summary: '水流路径长',
        lines: ['水流路径长', '矿物充分溶解'],
      },
    ],
    closing: '岩石结构 → 稳定风味生成系统',
    bgImage: '/images/banjian-new/cards/bd-structure-bg.png',
  },
  {
    id: 'origin',
    number: '03',
    titleCn: '溯源卡',
    titleEn: 'Origin Card',
    intro: '这杯茶从哪里生成',
    stateLabel: '',
    dimensions: [
      {
        label: '地质起源',
        summary: '深成花岗岩长期抬升暴露',
        lines: ['深成花岗岩长期抬升暴露'],
      },
      {
        label: '风化路径',
        summary: '岩石 → 破碎 → 微粒化',
        lines: ['岩石 → 破碎 → 微粒化 → 溶出矿物'],
      },
      {
        label: '离子路径',
        summary: '矿物 → 微生物 → 土壤',
        lines: ['矿物 → 微生物 → 土壤 → 茶树根系'],
      },
      {
        label: '人类路径',
        summary: '低干预采摘',
        lines: ['低干预采摘', '几乎保持原始矿物系统'],
      },
    ],
    closing: '味道来自"地球释放过程"，不是加工结果',
    bgImage: '/images/banjian-new/cards/bd-origin-bg.png',
  },
  {
    id: 'brewing',
    number: '04',
    titleCn: '冲泡卡',
    titleEn: 'Brewing Card',
    intro: '如何启动这个系统',
    stateLabel: '',
    dimensions: [
      {
        label: '投茶',
        summary: '8g',
        lines: ['8g'],
      },
      {
        label: '水温',
        summary: '95–100°C',
        lines: ['95–100°C'],
      },
      {
        label: '注水方式',
        summary: '短冲 + 停顿',
        lines: ['短冲 + 停顿（结构式注水）'],
      },
      {
        label: '时间结构',
        summary: '1–2泡结构打开 → 3–5泡稳定 → 6泡后深层支撑',
        lines: ['1–2泡：结构打开', '3–5泡：身体稳定增强', '6泡以后：进入深层支撑感'],
      },
    ],
    closing: '冲泡是"激活结构"，不是冲泡茶叶',
    bgImage: '/images/banjian-new/cards/bd-brewing-bg.png',
  },
];
