import type { ProductInfo } from '@/types';

export const products: Record<string, ProductInfo> = {
  BYS001: {
    id: 'BYS001',
    name: '白莺初霁',
    sourceName: '白芽子',
    coreSentence: '有些变化，只能缓慢发生。',
    lifeStructure: '时间缓释结构',
    lifeStructureTag: '时间缓释结构',
    category: '白茶',
    region: '云南·临沧·白莺山',
    altitude: '1800-2200m',
    harvestTime: '2026年春',
    freshLeafKg: 567.8,
    dryTeaKg: 100.1,
    yieldRatio: '5.7:1',
    yieldPercent: '17.63%',
    sampleSize: '7枚×8g',
    observationPath: '七泡观察',
    keywords: ['清', '缓', '退'],
    processSteps: ['萎凋', '摊薄', '揉捻', '摊晾', '并筛', '晒青', '干燥'],
    processDetail: '4-8天萎凋，24h观察动态',
    heroImage: '/images/banjian-new/product/product-bys-hero-01-temp-final.png',
    archiveImage: '/images/banjian-new/product/product-bys-archive-01-temp-final.png',
  },
  BD001: {
    id: 'BD001',
    name: '石界岩手',
    sourceName: '邦东紫芽',
    coreSentence: '被压缩过的东西，才知道如何支撑。',
    lifeStructure: '压力释放结构',
    lifeStructureTag: '压力释放结构',
    category: '普洱生茶',
    region: '云南·临沧·邦东',
    altitude: '1650m',
    harvestTime: '2026年春',
    freshLeafKg: 179.28,
    dryTeaKg: 43.84,
    yieldRatio: '4.1:1',
    yieldPercent: '24.45%',
    sampleSize: '7枚×8g',
    observationPath: '七泡观察',
    keywords: ['热', '压', '回'],
    processSteps: ['萎凋', '杀青', '揉捻', '晒青', '起堆'],
    processDetail: '65℃±3℃叶温，31锅手工淬炼',
    heroImage: '/images/banjian-new/product/product-bd001-hero-01-temp-final.png',
    archiveImage: '/images/banjian-new/product/product-bd001-archive-01-temp-final.png',
  },
};

export const bysProduct = products.BYS001;
export const bd001Product = products.BD001;

export const productList = [bysProduct, bd001Product];
