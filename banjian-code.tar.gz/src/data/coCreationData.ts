// ───────────────────────────────────────────────
// Co-Creation Data
// 共创系统：人物 + 价值流向 + 七节点
// ───────────────────────────────────────────────

export interface Person {
  name: string;
  role: string;
  desc: string;
  image: string;
}

export interface ValueFlowItem {
  label: string;
  percent: number;
  amount: number;
  color: string;
}

export interface ProductionNode {
  number: string;
  title: string;
  icon: string;
}

export interface CultureItem {
  icon: string;
  title: string;
  desc: string;
}

// ─── 5位共创参与者 ───
export const coCreationPeople: Person[] = [
  {
    name: '财源',
    role: '茶农',
    desc: '守护山场的人',
    image: '/images/banjian-new/people/cai-yuan.jpg',
  },
  {
    name: '黄德彪',
    role: '制茶师',
    desc: '决定茶性格的人',
    image: '/images/banjian-new/people/huang-debiao.jpg',
  },
  {
    name: '严庄',
    role: '监匠',
    desc: '守住标准的人',
    image: '/images/banjian-new/people/yan-zhuang.jpg',
  },
  {
    name: '陆贵平',
    role: '揉捻协作',
    desc: '手感与力度的人',
    image: '/images/banjian-new/people/lu-guiping.jpg',
  },
  {
    name: '张东冬',
    role: '记录确认',
    desc: '让过程被留下的人',
    image: '/images/banjian-new/people/zhang-dongdong.jpg',
  },
];

// ─── 8项价值流向（白莺初霁 BYS001 ¥36.9/泡）───
export const bysValueFlow: ValueFlowItem[] = [
  { label: '鲜叶', percent: 24.1, amount: 8.89, color: '#1B4332' },
  { label: '工费', percent: 7.3, amount: 2.69, color: '#2D5A45' },
  { label: '固定成本', percent: 7.0, amount: 2.58, color: '#3D7A5A' },
  { label: '溯源', percent: 12.4, amount: 4.58, color: '#D4A853' },
  { label: '品牌', percent: 14.9, amount: 5.50, color: '#C17B5F' },
  { label: '物流', percent: 7.0, amount: 2.58, color: '#B5ADA3' },
  { label: '生态', percent: 9.0, amount: 3.32, color: '#8B6239' },
  { label: '回收', percent: 18.3, amount: 6.73, color: '#6B4F3A' },
];

// ─── 8项价值流向（石界岩手 BD001 ¥29.9/泡）───
export const bd001ValueFlow: ValueFlowItem[] = [
  { label: '鲜叶', percent: 18.1, amount: 5.41, color: '#1B4332' },
  { label: '工费', percent: 13.4, amount: 4.01, color: '#2D5A45' },
  { label: '固定成本', percent: 4.7, amount: 1.42, color: '#3D7A5A' },
  { label: '溯源', percent: 8.1, amount: 2.43, color: '#D4A853' },
  { label: '品牌', percent: 18.1, amount: 5.41, color: '#C17B5F' },
  { label: '物流', percent: 7.0, amount: 2.09, color: '#B5ADA3' },
  { label: '生态', percent: 9.0, amount: 2.69, color: '#8B6239' },
  { label: '回收', percent: 21.5, amount: 6.42, color: '#6B4F3A' },
];

// ─── 7个生产节点 ───
export const productionNodes: ProductionNode[] = [
  { number: '01', title: '古茶树保护', icon: 'TreePine' },
  { number: '02', title: '春茶采摘', icon: 'Hand' },
  { number: '03', title: '初制工艺', icon: 'Flame' },
  { number: '04', title: '产品生产', icon: 'Package' },
  { number: '05', title: '数字存证', icon: 'Lock' },
  { number: '06', title: '七泡观察', icon: 'Eye' },
  { number: '07', title: '价值回流', icon: 'RefreshCw' },
];

// ─── 4个文化增长项 ───
export const cultureItems: CultureItem[] = [
  {
    icon: 'Flame',
    title: '技艺被保留',
    desc: '萎凋、杀青、揉捻……不是被标准化，而是被记录和传承',
  },
  {
    icon: 'Users',
    title: '人的能力提升',
    desc: '茶农、制茶师、监匠在系统里持续成长',
  },
  {
    icon: 'TreePine',
    title: '古茶树被保护',
    desc: '每季持续保护，让下一季还有可能',
  },
  {
    icon: 'BookOpen',
    title: '经验被沉淀',
    desc: '每批茶的记录，成为下一季的参考',
  },
];
