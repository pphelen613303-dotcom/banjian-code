export interface ProcessStep { name: string; body: string; }
export interface BodyExp { label: string; desc: string; }
export interface ProductComp {
  name: string; id: string; system: string; tagline: string;
  color: string; accentBg: string;
  origin: { quote: string; points: string[] };
  process: { label: string; steps: ProcessStep[]; result: string; summary: string };
  experience: { quote: string; points: BodyExp[]; closing: string; essence: string };
}
export const bysData: ProductComp = {
  name: '白莺初霁', id: 'BYS001', system: '时间系统', tagline: '时间被拉长，身体被舒展',
  color: '#1B4332', accentBg: 'rgba(27,67,50,0.08)',
  origin: { quote: '这不是一杯茶，而是一种时间被拉长的方式。', points: ['白莺山高海拔生态 1600-1900m','多岩层混合地质','高湿度森林环境','有性繁殖茶树群落','菌丝共生网络'] },
  process: { label: '低干预 · 缓慢转化', steps: [{name:'萎凋',body:'打开呼吸'},{name:'摊薄',body:'释放孔隙'},{name:'揉捻',body:'延展界面'},{name:'摊晾',body:'慢养内质'},{name:'并筛',body:'聚拢活性'},{name:'晒青',body:'日光渗透'},{name:'结构保留',body:'内质完整'}], result: '时间被拉长', summary: '低温、低干预，让茶中的活性物质缓慢转化，形成时间感延展的体验。' },
  experience: { quote: '当你饮用它时，发生的是：', points: [{label:'呼吸变长',desc:'节奏舒缓'},{label:'注意力收回',desc:'思绪沉静'},{label:'身体变轻',desc:'紧绷释放'},{label:'时间感被拉开',desc:'空间被打开'}], closing: '不是茶在变化，而是"时间在被重新组织"', essence: '时间不是流动的，是被拉长的空间' },
};
export const bd001Data: ProductComp = {
  name: '石界岩手', id: 'BD001', system: '结构系统', tagline: '结构被激活，身体被稳定',
  color: '#8B6239', accentBg: 'rgba(139,98,57,0.08)',
  origin: { quote: '这不是一杯茶，而是一种结构被激活的方式。', points: ['邦东花岗岩断裂带 1650m','花岗岩地质结构','钠角闪石与辉石矿物','岩缝水系统','深层矿物渗透结构'] },
  process: { label: '高温激活 · 结构释放', steps: [{name:'摊晾',body:'积蓄张力'},{name:'杀青',body:'高温定格'},{name:'摊凉',body:'复酶以待'},{name:'揉捻',body:'润壁塑形'},{name:'晒青',body:'光热固结'},{name:'起堆',body:'内聚平衡'},{name:'结构稳定',body:'内质融合'}], result: '结构被强化', summary: '高温激活与结构控制，让矿物与茶多酚深度结合，形成稳定而有力量的体验。' },
  experience: { quote: '当你饮用它时，发生的是：', points: [{label:'呼吸变深',desc:'气息沉稳'},{label:'身体下沉',desc:'重心稳定'},{label:'注意力集中',desc:'清晰有力'},{label:'结构感增强',desc:'支撑与安全'}], closing: '不是茶在变化，而是"身体结构被重新组织"', essence: '结构不是存在的，是被激活的' },
};
