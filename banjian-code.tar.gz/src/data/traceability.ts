import type { TraceabilityData } from '@/types';

export const traceabilityData: TraceabilityData[] = [
  {
    product_id: 'BYS001',
    product_name: '白莺初霁',
    core_sentence: '有些变化，只能缓慢发生。',
    life_structure: '时间缓释结构',
    trace: {
      region: '云南·临沧·白莺山',
      altitude: '1800-2200m',
      harvest_time: '2026年春',
      fresh_leaf_kg: 567.8,
      dry_tea_kg: 100.1,
      yield_ratio: '5.7:1',
      yield_percent: '17.63%',
      total_cost: 71711.22,
      cost_per_kg: 716.40,
      cost_breakdown: {
        freshLeaf: 22712.00,
        labor: 13400.00,
        fixed: 12868.03,
        equipment: 22731.19,
      },
      process: {
        steps: ['萎凋', '摊薄', '揉捻', '摊晾', '并筛', '晒青', '干燥'],
        detail: '4-8天萎凋，24h观察动态',
      },
    },
    value_flow: {
      price_per_serving: 36.9,
      items: [
        { name: '鲜叶', percent: 24.1, amount: 8.89, actor: '茶农财源', meaning: '茶农获得公平报酬', icon: '🌱' },
        { name: '工费', percent: 7.3, amount: 2.69, actor: '工艺团队', meaning: '制茶师的劳动被尊重', icon: '👷' },
        { name: '固定成本', percent: 7.0, amount: 2.58, actor: '生产系统', meaning: '设备和场地持续运转', icon: '🏭' },
        { name: '溯源开销', percent: 12.4, amount: 4.58, actor: '溯源团队', meaning: '每一步都被记录和验证', icon: '📋' },
        { name: '品牌运营', percent: 14.9, amount: 5.50, actor: '半见团队', meaning: '品牌让好茶被看见', icon: '✦' },
        { name: '物流售后', percent: 7.0, amount: 2.58, actor: '物流伙伴', meaning: '茶安全到达你手中', icon: '📦' },
        { name: '生态回流', percent: 9.0, amount: 3.32, actor: '生态基金', meaning: '古茶园被持续保护', icon: '🌿' },
        { name: '成本回收', percent: 18.3, amount: 6.73, actor: '再生产', meaning: '让下一季的茶成为可能', icon: '♻️' },
      ],
    },
  },
  {
    product_id: 'BD001',
    product_name: '石界岩手',
    core_sentence: '被压缩过的东西，才知道如何支撑。',
    life_structure: '压力释放结构',
    trace: {
      region: '云南·临沧·邦东',
      altitude: '1650m',
      harvest_time: '2026年春',
      fresh_leaf_kg: 179.28,
      dry_tea_kg: 43.84,
      yield_ratio: '4.1:1',
      yield_percent: '24.45%',
      total_cost: 26605.44,
      cost_per_kg: 606.88,
      cost_breakdown: {
        freshLeaf: 13128.00,
        labor: 5441.00,
        fixed: 3048.60,
        equipment: 4987.84,
      },
      process: {
        steps: ['萎凋', '杀青', '揉捻', '晒青', '起堆'],
        detail: '65℃±3℃叶温，31锅手工淬炼',
      },
    },
    value_flow: {
      price_per_serving: 29.9,
      items: [
        { name: '鲜叶', percent: 18.1, amount: 5.41, actor: '茶农财源', meaning: '茶农获得公平报酬', icon: '🌱' },
        { name: '工费', percent: 13.4, amount: 4.01, actor: '工艺团队', meaning: '制茶师的劳动被尊重', icon: '👷' },
        { name: '固定成本', percent: 4.7, amount: 1.42, actor: '生产系统', meaning: '设备和场地持续运转', icon: '🏭' },
        { name: '溯源开销', percent: 8.1, amount: 2.43, actor: '溯源团队', meaning: '每一步都被记录和验证', icon: '📋' },
        { name: '品牌运营', percent: 18.1, amount: 5.41, actor: '半见团队', meaning: '品牌让好茶被看见', icon: '✦' },
        { name: '物流售后', percent: 7.0, amount: 2.09, actor: '物流伙伴', meaning: '茶安全到达你手中', icon: '📦' },
        { name: '生态回流', percent: 9.0, amount: 2.69, actor: '生态基金', meaning: '古茶园被持续保护', icon: '🌿' },
        { name: '成本回收', percent: 21.5, amount: 6.42, actor: '再生产', meaning: '让下一季的茶成为可能', icon: '♻️' },
      ],
    },
  },
];

export const getTraceabilityByProductId = (id: 'BYS001' | 'BD001'): TraceabilityData | undefined =>
  traceabilityData.find((t) => t.product_id === id);
