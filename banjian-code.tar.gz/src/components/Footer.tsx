import { Link } from 'react-router';
import { Leaf } from 'lucide-react';
import QRCard from './QRCard';

const navLinks = [
  { label: '基准茶', path: '/product' },
  { label: '观察', path: '/observe' },
  { label: '档案', path: '/origin' },
  { label: '价值', path: '/value' },
  { label: '关于', path: '/about' },
];

const experienceLinks = [
  { label: '七泡观察', path: '/observe' },
  { label: '七天茶觉', path: '/observe?track=7day' },
  { label: '生命档案', path: '/origin' },
  { label: '价值流向', path: '/value' },
];

export default function Footer() {
  return (
    <footer className="bg-archive-brown text-warm-white">
      <div className="max-w-7xl mx-auto px-4 xs:px-6 md:px-8 lg:px-16 py-16 md:py-24">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <img
                src="/images/banjian-new/brand/banjian-logo-transparent.png"
                alt="半见 BANJIAN"
                className="h-8 w-auto brightness-0 invert"
               decoding="async"/>
            </Link>
            <p className="text-sm text-warm-white/70 leading-relaxed max-w-xs font-sans-zh">
              用一杯茶，帮助现代人重新建立对时间、身体、生态和劳动关系的观察能力。
            </p>
          </div>

          {/* Navigation Column */}
          <div>
            <h4 className="text-sm font-medium font-sans-zh mb-4 text-warm-white/90">导航</h4>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-warm-white/60 hover:text-tea-gold transition-colors duration-200 font-sans-zh"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Experience Column */}
          <div>
            <h4 className="text-sm font-medium font-sans-zh mb-4 text-warm-white/90">体验</h4>
            <ul className="space-y-3">
              {experienceLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-warm-white/60 hover:text-tea-gold transition-colors duration-200 font-sans-zh"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact / QR Column */}
          <div>
            <h4 className="text-sm font-medium font-sans-zh mb-4 text-warm-white/90">联系</h4>
            <div className="grid grid-cols-3 gap-3">
              <QRCard
                src="/images/banjian-new/qr/wechat-shop-qicaizongsi.png"
                label="微信小店"
              />
              <QRCard
                src="/images/banjian-new/qr/banjian-7day-miniprogram-qr.png"
                label="7天小程序"
              />
              <QRCard
                src="/images/banjian-new/qr/banjian-tea-guide-wechat.jpg"
                label="茶觉师"
              />
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-warm-white/10 flex flex-col xs:flex-row items-center justify-between gap-4">
          <p className="text-xs text-warm-white/40 font-sans-zh flex items-center gap-1">
            <Leaf size={12} strokeWidth={1.5} />
            半见 BANJIAN — 用一杯茶，慢慢看见自己
          </p>
          <p className="text-xs text-warm-white/40 font-sans-zh">
            &copy; {new Date().getFullYear()} 半见 BANJIAN. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
