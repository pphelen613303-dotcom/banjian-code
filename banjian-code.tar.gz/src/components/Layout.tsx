import { useEffect } from 'react';
import { useLocation } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './Navbar';
import Footer from './Footer';
import WebVitals from './WebVitals';

gsap.registerPlugin(ScrollTrigger);

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();

  // Initialize Lenis smooth scroll — sync with GSAP ScrollTrigger
  useEffect(() => {
    let lenis: any = null;

    const initLenis = async () => {
      try {
        const Lenis = (await import('lenis')).default;
        lenis = new Lenis({
          lerp: 0.08,
          duration: 1.2,
          smoothWheel: true,
        });

        // Sync Lenis with GSAP ScrollTrigger
        lenis.on('scroll', ScrollTrigger.update);
        gsap.ticker.add((time: number) => {
          lenis.raf(time * 1000);
        });
        gsap.ticker.lagSmoothing(0);

      } catch {
        document.documentElement.style.scrollBehavior = 'smooth';
      }
    };

    // Check for hardware capability — disable on low-end devices
    const cores = navigator.hardwareConcurrency || 4;
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (cores >= 4 && !prefersReduced) {
      initLenis();
    } else {
      document.documentElement.style.scrollBehavior = 'smooth';
    }

    return () => {
      if (lenis) {
        gsap.ticker.remove(lenis.raf);
        lenis.destroy();
      }
    };
  }, []);

  // Scroll to top on route change — use native scroll (Lenis handles smoothing)
  useEffect(() => {
    window.scrollTo(0, 0);
    ScrollTrigger.refresh();
  }, [location.pathname]);

  return (
    <div className="min-h-[100dvh] flex flex-col relative">
      {/* Global subtle paper grain texture */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-[0.035]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`,
          backgroundSize: '200px 200px',
        }}
      />

      {/* Subtle horizontal mountain contour lines */}
      <div
        className="fixed inset-x-0 bottom-0 pointer-events-none z-0 opacity-[0.025] h-[40vh]"
        style={{
          background: `linear-gradient(to top, rgba(61,50,41,0.06) 0%, transparent 100%)`,
        }}
      />

      <div className="relative z-10 flex flex-col flex-1">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </div>
      <WebVitals />
    </div>
  );
}
