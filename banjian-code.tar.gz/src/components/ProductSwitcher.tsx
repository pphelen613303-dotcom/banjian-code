import { useRef } from 'react';
import { useSearchParams } from 'react-router';
import gsap from 'gsap';
import { cn } from '@/lib/utils';

interface ProductSwitcherProps {
  activeProduct: 'bys' | 'bd001';
  onSwitch: (product: 'bys' | 'bd001') => void;
  className?: string;
}

export default function ProductSwitcher({ activeProduct, onSwitch, className }: ProductSwitcherProps) {
  const [, setSearchParams] = useSearchParams();
  const contentRef = useRef<HTMLDivElement>(null);

  const handleSwitch = (product: 'bys' | 'bd001') => {
    if (product === activeProduct) return;

    // Animate out
    if (contentRef.current) {
      gsap.to(contentRef.current, {
        opacity: 0,
        duration: 0.15,
        onComplete: () => {
          onSwitch(product);
          setSearchParams({ product });
          try { localStorage.setItem('activeProduct', product); } catch { /* ignore */ }
          // Animate in after state update
          requestAnimationFrame(() => {
            if (contentRef.current) {
              gsap.to(contentRef.current, {
                opacity: 1,
                duration: 0.3,
                ease: 'power2.out',
              });
            }
          });
        },
      });
    } else {
      onSwitch(product);
      setSearchParams({ product });
      try { localStorage.setItem('activeProduct', product); } catch { /* ignore */ }
    }
  };

  return (
    <div className={cn('w-full', className)}>
      {/* Tab Buttons */}
      <div className="flex border-b-2 border-archive-brown-12">
        <button
          onClick={() => handleSwitch('bys')}
          className={cn(
            'flex-1 py-3 text-base font-serif-zh transition-all duration-200',
            'border-b-2 -mb-[2px]',
            activeProduct === 'bys'
              ? 'border-tea-gold text-archive-brown'
              : 'border-transparent text-archive-brown-60 hover:text-archive-brown'
          )}
        >
          白莺初霁
        </button>
        <button
          onClick={() => handleSwitch('bd001')}
          className={cn(
            'flex-1 py-3 text-base font-serif-zh transition-all duration-200',
            'border-b-2 -mb-[2px]',
            activeProduct === 'bd001'
              ? 'border-tea-gold text-archive-brown'
              : 'border-transparent text-archive-brown-60 hover:text-archive-brown'
          )}
        >
          石界岩手
        </button>
      </div>
      {/* Animated Content Wrapper */}
      <div ref={contentRef} />
    </div>
  );
}

export function useActiveProduct() {
  const [searchParams] = useSearchParams();
  const urlProduct = searchParams.get('product');
  let storedProduct: string | null = null;
  try { storedProduct = localStorage.getItem('activeProduct'); } catch { /* ignore */ }

  if (urlProduct === 'bys' || urlProduct === 'bd001') {
    return urlProduct;
  }
  if (storedProduct === 'bys' || storedProduct === 'bd001') {
    return storedProduct;
  }
  return 'bys';
}
