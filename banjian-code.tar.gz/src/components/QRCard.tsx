interface QRCardProps {
  src: string;
  label: string;
  className?: string;
}

export default function QRCard({ src, label, className }: QRCardProps) {
  return (
    <div className={`flex flex-col items-center gap-2 ${className || ''}`}>
      <div className="w-28 h-28 xs:w-32 xs:h-32 bg-white p-2 rounded-lg border border-archive-brown-12">
        <img
          src={src}
          alt={label}
          className="w-full h-full object-contain"
          loading="lazy"
         decoding="async"/>
      </div>
      <span className="text-xs text-warm-white/70 font-sans-zh">{label}</span>
    </div>
  );
}
