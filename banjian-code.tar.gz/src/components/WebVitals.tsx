import { useEffect } from 'react';

type WebVitalName = 'CLS' | 'LCP' | 'FID' | 'FCP' | 'TTFB' | 'INP';

interface WebVitalMetric {
  name: WebVitalName;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  delta: number;
  entries: PerformanceEntry[];
}

const RATING_THRESHOLDS: Record<WebVitalName, { good: number; poor: number }> = {
  CLS: { good: 0.1, poor: 0.25 },
  LCP: { good: 2500, poor: 4000 },
  FID: { good: 100, poor: 300 },
  FCP: { good: 1800, poor: 3000 },
  TTFB: { good: 800, poor: 1800 },
  INP: { good: 200, poor: 500 },
};

function getRating(name: WebVitalName, value: number): WebVitalMetric['rating'] {
  const t = RATING_THRESHOLDS[name];
  if (value <= t.good) return 'good';
  if (value <= t.poor) return 'needs-improvement';
  return 'poor';
}

function logWebVital(metric: WebVitalMetric) {
  // eslint-disable-next-line no-console
  console.log(
    `%c[WebVitals] %c${metric.name}%c = %c${metric.value.toFixed(2)} %c(${metric.rating})`,
    'color: #B5ADA3',
    'color: #3D3229; font-weight: 600',
    'color: #3D3229',
    metric.rating === 'good'
      ? 'color: #1B4332; font-weight: 600'
      : metric.rating === 'poor'
        ? 'color: #C17B5F; font-weight: 600'
        : 'color: #D4A853; font-weight: 600',
    'color: #999'
  );
}

/**
 * Lightweight Web Vitals monitor — tracks CLS, LCP, FCP, TTFB
 * using native PerformanceObserver. No external dependency.
 */
export default function WebVitals() {
  useEffect(() => {
    if (typeof PerformanceObserver === 'undefined') return;

    const metrics: Partial<Record<WebVitalName, WebVitalMetric>> = {};

    // CLS — Cumulative Layout Shift
    let clsValue = 0;
    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!(entry as any).hadRecentInput) {
          clsValue += (entry as any).value;
        }
      }
    });
    try {
      clsObserver.observe({ type: 'layout-shift', buffered: true });
    } catch { /* unsupported */ }

    // LCP — Largest Contentful Paint
    let lcpValue = 0;
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      lcpValue = (lastEntry as any).startTime;
    });
    try {
      lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
    } catch { /* unsupported */ }

    // FCP — First Contentful Paint
    const fcpObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.name === 'first-contentful-paint') {
          const m: WebVitalMetric = {
            name: 'FCP',
            value: entry.startTime,
            rating: getRating('FCP', entry.startTime),
            delta: entry.startTime,
            entries: [entry],
          };
          metrics.FCP = m;
          logWebVital(m);
        }
      }
    });
    try {
      fcpObserver.observe({ type: 'paint', buffered: true });
    } catch { /* unsupported */ }

    // Report on page hide
    const report = () => {
      // CLS
      if (clsValue > 0 && !metrics.CLS) {
        const m: WebVitalMetric = {
          name: 'CLS',
          value: clsValue,
          rating: getRating('CLS', clsValue),
          delta: clsValue,
          entries: [],
        };
        metrics.CLS = m;
        logWebVital(m);
      }
      // LCP
      if (lcpValue > 0 && !metrics.LCP) {
        const m: WebVitalMetric = {
          name: 'LCP',
          value: lcpValue,
          rating: getRating('LCP', lcpValue),
          delta: lcpValue,
          entries: [],
        };
        metrics.LCP = m;
        logWebVital(m);
      }
      // TTFB
      const navEntry = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;
      if (navEntry && !metrics.TTFB) {
        const ttfb = navEntry.responseStart - navEntry.startTime;
        const m: WebVitalMetric = {
          name: 'TTFB',
          value: ttfb,
          rating: getRating('TTFB', ttfb),
          delta: ttfb,
          entries: [navEntry],
        };
        metrics.TTFB = m;
        logWebVital(m);
      }
    };

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') report();
    });

    // Fallback: report after 10s
    const timer = setTimeout(report, 10000);

    return () => {
      clearTimeout(timer);
      clsObserver.disconnect();
      lcpObserver.disconnect();
      fcpObserver.disconnect();
    };
  }, []);

  return null; // Render nothing
}
