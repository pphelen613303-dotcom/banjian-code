import { Component, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

/**
 * Global Error Boundary — catches React render errors
 * and shows a minimal branded fallback instead of white screen.
 */
export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.hash = '/';
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          className="min-h-[100dvh] flex flex-col items-center justify-center px-6 text-center"
          style={{ backgroundColor: '#FAF9F7' }}
        >
          <p
            className="text-[10px] font-mono-data tracking-[0.25em] uppercase mb-4"
            style={{ color: 'rgba(61,50,41,0.4)' }}
          >
            SOMETHING WENT WRONG
          </p>
          <h1
            className="text-2xl font-serif-zh mb-3"
            style={{ color: '#3D3229' }}
          >
            页面遇到了一点问题
          </h1>
          <p
            className="text-sm mb-8 max-w-sm leading-relaxed"
            style={{ color: 'rgba(61,50,41,0.6)' }}
          >
            可能是网络波动或临时加载异常，刷新一下通常就好了。
          </p>
          <div className="flex flex-col xs:flex-row gap-3">
            <button
              onClick={this.handleReload}
              className="px-8 py-3 rounded-full text-sm font-medium font-sans-zh tracking-[0.05em] transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ backgroundColor: '#3D3229', color: '#FAF9F7' }}
            >
              刷新页面
            </button>
            <button
              onClick={this.handleGoHome}
              className="px-8 py-3 rounded-full text-sm font-medium font-sans-zh tracking-[0.05em] border transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ borderColor: 'rgba(61,50,41,0.2)', color: '#3D3229' }}
            >
              回到首页
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
