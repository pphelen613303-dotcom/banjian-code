import { cn } from '@/lib/utils';

interface ObservationCardProps {
  stepNumber: string;
  title: string;
  description: string;
  className?: string;
}

export default function ObservationCard({ stepNumber, title, description, className }: ObservationCardProps) {
  return (
    <div
      className={cn(
        'border-t border-archive-brown-6 py-6 xs:py-8 transition-all duration-200',
        'hover:border-tea-gold-40 hover:shadow-[0_2px_12px_rgba(0,0,0,0.04)]',
        className
      )}
    >
      <span className="block text-4xl font-serif-zh text-tea-gold mb-3">{stepNumber}</span>
      <h3 className="text-lg font-semibold font-serif-zh text-archive-brown mb-2">{title}</h3>
      <p className="text-sm text-archive-brown-60 font-sans-zh leading-relaxed">{description}</p>
    </div>
  );
}
