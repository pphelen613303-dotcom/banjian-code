import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const navLinks = [
  { label: '首页', path: '/' },
  { label: '基准茶', path: '/product' },
  { label: '观察', path: '/observe' },
  { label: '档案', path: '/origin' },
  { label: '价值', path: '/value' },
  { label: '关于', path: '/about' },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  /* lock body scroll when drawer open */
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 h-14 transition-all duration-200',
          'bg-warm-white/95 backdrop-blur-[12px]',
          'border-b border-archive-brown/[0.06]',
          scrolled && 'shadow-[0_1px_8px_rgba(0,0,0,0.04)]'
        )}
      >
        <div className="max-w-7xl mx-auto h-full flex items-center justify-between px-4 xs:px-6 md:px-8 lg:px-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0 z-50 relative">
            <img
              src="/images/banjian-new/brand/banjian-logo-transparent.png"
              alt="半见 BANJIAN"
              className="h-7 w-auto"
             decoding="async"/>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  'text-sm font-sans-zh transition-colors duration-200 relative py-1',
                  isActive(link.path)
                    ? 'text-tea-gold'
                    : 'text-archive-brown hover:text-tea-gold'
                )}
              >
                {link.label}
                {isActive(link.path) && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-tea-gold rounded-full" />
                )}
              </Link>
            ))}
          </nav>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden relative z-[60] flex items-center justify-center w-10 h-10 text-archive-brown"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? '关闭菜单' : '打开菜单'}
          >
            {mobileOpen ? <X size={24} strokeWidth={1.5} /> : <Menu size={24} strokeWidth={1.5} />}
          </button>
        </div>
      </header>

      {/* ===== MOBILE FULL-SCREEN OVERLAY ===== */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-[55] bg-warm-white">
          {/* Close button area at top */}
          <div className="h-14" />

          {/* Nav links — vertically centered */}
          <nav className="flex flex-col items-start px-8 pt-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  'py-4 text-2xl font-sans-zh tracking-wide transition-colors duration-200',
                  isActive(link.path)
                    ? 'text-tea-gold'
                    : 'text-archive-brown hover:text-tea-gold'
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Bottom brand mark */}
          <div className="absolute bottom-8 left-8 right-8">
            <div className="border-t border-archive-brown-6 pt-4">
              <span className="text-xs font-mono-data text-archive-brown-30 tracking-[0.2em]">
                BANJIAN LIVING ARCHIVE
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Spacer for fixed header */}
      <div className="h-14" />
    </>
  );
}
