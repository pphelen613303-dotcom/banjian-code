import { cn } from '@/lib/utils';

interface SectionEyebrowProps {
  text: string;
  className?: string;
  variant?: 'light' | 'dark';
}

export default function SectionEyebrow({ text, className, variant = 'light' }: SectionEyebrowProps) {
  return (
    <span
      className={cn(
        'block text-xs font-medium tracking-[0.15em] uppercase font-sans-zh mb-4',
        variant === 'light' ? 'text-archive-brown-60' : 'text-tea-gold',
        className
      )}
    >
      {text}
    </span>
  );
}
