// ===== Product / Archive Types =====

export interface ProductInfo {
  id: 'BYS001' | 'BD001';
  name: string;              // 白莺初霁 / 石界岩手
  sourceName: string;        // 白芽子 / 邦东紫芽
  coreSentence: string;      // 有些变化，只能缓慢发生。/ 被压缩过的东西，才知道如何支撑。
  lifeStructure: string;     // 时间缓释结构 / 压力释放结构
  lifeStructureTag: string;  // deep-green tag text
  category: string;          // 白茶 / 普洱生茶
  region: string;            // 云南·临沧·白莺山 / 云南·临沧·邦东
  altitude: string;          // 1800-2200m / 1650m
  harvestTime: string;       // 2026年春
  freshLeafKg: number;
  dryTeaKg: number;
  yieldRatio: string;        // 5.7:1 / 4.1:1
  yieldPercent: string;      // 17.63% / 24.45%
  sampleSize: string;        // 7枚×8g
  observationPath: string;   // 七泡观察
  keywords: string[];        // 清/缓/退 或 热/压/回
  processSteps: string[];
  processDetail: string;
  heroImage: string;
  archiveImage: string;
}

// ===== Traceability Types =====

export interface CostBreakdown {
  freshLeaf: number;
  labor: number;
  fixed: number;
  equipment: number;
}

export interface ProcessInfo {
  steps: string[];
  detail: string;
}

export interface TraceabilityData {
  product_id: 'BYS001' | 'BD001';
  product_name: string;
  core_sentence: string;
  life_structure: string;
  trace: {
    region: string;
    altitude: string;
    harvest_time: string;
    fresh_leaf_kg: number;
    dry_tea_kg: number;
    yield_ratio: string;
    yield_percent: string;
    total_cost: number;
    cost_per_kg: number;
    cost_breakdown: CostBreakdown;
    process: ProcessInfo;
  };
  value_flow: {
    price_per_serving: number;
    items: ValueFlowItem[];
  };
}

export interface ValueFlowItem {
  name: string;
  percent: number;
  amount: number;    // ¥/serving
  actor: string;
  meaning: string;
  icon: string;
}

// ===== Experience / Observation Types =====

export interface SubtitleSegment {
  id: number;
  text: string;
  keywords: string[];
}

export interface TeaObserveDay {
  day: number;
  title: string;
  subtitle: string;
  keywords: string[];
  prompt: string;
  scienceNote?: string;
  audioUrl: string;
  duration: number;   // seconds
  segments: SubtitleSegment[];
}

// ===== Seven Infusion Types =====

export interface InfusionStep {
  step: number;
  title: string;
  guidance: string;
  keyword: string;    // for hover/tooltip
}

// ===== Shared Confirm Types =====

export interface ConfirmPerson {
  role: string;
  name: string;
  responsibility: string;
  confirmStatus: 'confirmed' | 'pending';
  confirmTime?: string;
  archive?: string;   // 监匠档案 e.g. "30年/晒青白茶红茶S级"
}

// ===== Observation Record Types =====

export interface ObservationRecord {
  id: string;
  source: 'seven-infusion' | 'seven-day';
  teaType: 'bys' | 'bd001' | 'custom';
  customTeaName?: string;  // user-defined tea name when teaType is 'custom'
  dayNumber?: number;
  infusionStep?: number;
  bodyFeeling: string;
  feelingTags: string[];
  status: 'local-preview' | 'submitted' | 'syncing';
  createdAt: string;
  deviceType: 'mobile' | 'desktop';
  screenWidth: number;
  sourcePage: 'observe' | 'product' | 'wechat';
  sessionId: string;
  feishuRecordId?: string;
  syncStatus: 'local-only' | 'synced' | 'sync-failed';
  syncTimestamp?: string;
}

// ===== CoCreation Types =====

export interface CoCreationElement {
  id: string;
  keyword: string;
  phrase: string;
  icon: string;  // lucide icon name
}

// ===== Evidence Types =====

export type EvidenceStatus = 'verified' | 'pending' | 'incomplete';

export interface EvidenceItem {
  id: string;
  type: 'image' | 'form' | 'video' | 'signature' | 'weight';
  title: string;
  status: EvidenceStatus;
  description?: string;
  url?: string;
}

export interface TimelineNode {
  nodeNumber: number;
  title: string;
  evidence: EvidenceItem[];
  // Legacy fields (optional for backward compat)
  happened?: string;
  actors?: string;
  forTea?: string;
  forUser?: string;
  evidenceSummary?: { brief: string; detail: string };
  items?: { title: string; body: string }[];
}

// ===== Five Dimension Types =====

export interface FiveDimension {
  id: string;
  name: string;
  publicExpression: string;
  professionalName?: string;
  bodySignal?: string;
}
