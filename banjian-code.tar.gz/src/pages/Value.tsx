import ValueHeroSection from '@/sections/value/ValueHeroSection';
import FiveDimensionSection from '@/sections/value/FiveDimensionSection';
import FiveDimensionExpand from '@/sections/value/FiveDimensionExpand';
import EightValueFlowSection from '@/sections/value/EightValueFlowSection';
import ValueBottomCTA from '@/sections/value/ValueBottomCTA';

export default function Value() {
  return (
    <>
      <ValueHeroSection />
      <FiveDimensionSection />
      <FiveDimensionExpand />
      <EightValueFlowSection />
      <ValueBottomCTA />
    </>
  );
}
