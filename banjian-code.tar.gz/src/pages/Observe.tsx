import { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router';
import { teaObserveDays } from '@/data/experience';
import TodayEntrySection from '@/sections/observe/TodayEntrySection';
import AudioPlayer from '@/sections/observe/AudioPlayer';
import SevenDayCalendar from '@/sections/observe/SevenDayCalendar';
import RecordFormSection from '@/sections/observe/RecordFormSection';
import AdvancedContentSection from '@/sections/observe/AdvancedContentSection';
import BodyEntrySelector from '@/sections/home/BodyEntrySelector';
import SevenInfusionEntry from '@/sections/home/SevenInfusionEntry';

const TEA_TYPE_KEY = 'banjian_tea_type';
const CUSTOM_TEA_KEY = 'banjian_custom_tea';

export default function Observe() {
  const [searchParams, setSearchParams] = useSearchParams();
  const dayParam = searchParams.get('day');
  const initialDay = dayParam ? parseInt(dayParam, 10) : 1;
  const [currentDay, setCurrentDay] = useState(
    initialDay >= 1 && initialDay <= 7 ? initialDay : 1
  );

  // Tea type state — persisted in localStorage (safe wrapper)
  const [teaType, setTeaType] = useState<'bys' | 'bd001' | 'custom'>(() => {
    try {
      const saved = localStorage.getItem(TEA_TYPE_KEY);
      if (saved === 'bys' || saved === 'bd001' || saved === 'custom') return saved;
    } catch { /* ignore */ }
    return 'bys';
  });
  const [customTeaName, setCustomTeaName] = useState(() => {
    try { return localStorage.getItem(CUSTOM_TEA_KEY) || ''; } catch { return ''; }
  });

  const recordRef = useRef<HTMLDivElement>(null);

  // Persist tea selections
  useEffect(() => {
    try { localStorage.setItem(TEA_TYPE_KEY, teaType); } catch { /* ignore */ }
  }, [teaType]);
  useEffect(() => {
    try { localStorage.setItem(CUSTOM_TEA_KEY, customTeaName); } catch { /* ignore */ }
  }, [customTeaName]);

  // Sync URL param with state
  useEffect(() => {
    const dp = searchParams.get('day');
    if (dp) {
      const d = parseInt(dp, 10);
      if (d >= 1 && d <= 7 && d !== currentDay) {
        setCurrentDay(d);
      }
    }
  }, [searchParams, currentDay]);

  // Handle day switch
  const handleDayClick = useCallback(
    (day: number) => {
      setCurrentDay(day);
      const newParams = new URLSearchParams(searchParams);
      newParams.set('day', String(day));
      setSearchParams(newParams, { replace: true });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [searchParams, setSearchParams]
  );

  const handleRecordClick = useCallback(() => {
    recordRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const currentDayData =
    teaObserveDays.find((d) => d.day === currentDay) || teaObserveDays[0];

  return (
    <main className="min-h-[80dvh] bg-warm-white">
      {/* Layer 1: Primary Experience */}

      {/* Today Entry: Hero with tea selection */}
      <TodayEntrySection
        key={`entry-${currentDay}`}
        teaType={teaType}
        customTeaName={customTeaName}
        onTeaTypeChange={setTeaType}
        onCustomTeaNameChange={setCustomTeaName}
      />

      {/* Audio Player + Today Focus Guide */}
      <AudioPlayer
        day={currentDayData}
        isDay6={currentDay === 6}
        onRecordClick={handleRecordClick}
      />

      {/* Seven Day Calendar */}
      <SevenDayCalendar
        currentDay={currentDay}
        onDayClick={handleDayClick}
      />

      {/* Record Entry */}
      <div ref={recordRef}>
        <RecordFormSection
          currentDay={currentDay}
          teaType={teaType}
          customTeaName={customTeaName}
          onTeaTypeChange={setTeaType}
          onCustomTeaNameChange={setCustomTeaName}
        />
      </div>

      {/* Layer 2: Advanced Content */}
      <AdvancedContentSection currentDay={currentDay} />

      {/* Body Entry Selector — temporarily moved from home page */}
      <BodyEntrySelector />

      {/* Seven Infusion Entry — moved from home page */}
      <SevenInfusionEntry />
    </main>
  );
}
