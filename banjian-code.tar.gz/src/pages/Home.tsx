import HomeHeroSection from '@/sections/home/HomeHeroSection';
import BodyEntrySelector from '@/sections/home/BodyEntrySelector';
import ValueOriginEntry from '@/sections/home/ValueOriginEntry';
import PeopleGallery from '@/sections/shared/PeopleGallery';
import CoCreationSection from '@/sections/home/CoCreationSection';

export default function Home() {
  return (
    <>
      <HomeHeroSection />
      <BodyEntrySelector />
      <ValueOriginEntry />
      <PeopleGallery />
      <CoCreationSection />
    </>
  );
}
