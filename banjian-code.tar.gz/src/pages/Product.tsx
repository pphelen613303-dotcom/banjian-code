import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router';
import ProductHeroSection from '@/sections/product/ProductHeroSection';
import PackageEntrySection from '@/sections/product/PackageEntrySection';
import ComparisonSection from '@/sections/product/ComparisonSection';
import ExperienceMethodSection from '@/sections/product/ExperienceMethodSection';
import type { ExperienceMethod } from '@/sections/product/ExperienceMethodSection';

export default function Product() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedMethod, setSelectedMethod] = useState<ExperienceMethod | null>(null);

  // Determine active product from URL or localStorage (safe wrapper)
  const getActiveProduct = (): 'bys' | 'bd001' => {
    const urlProduct = searchParams.get('product');
    if (urlProduct === 'bys' || urlProduct === 'bd001') return urlProduct;
    try {
      const storedProduct = localStorage.getItem('activeProduct');
      if (storedProduct === 'bys' || storedProduct === 'bd001') return storedProduct;
    } catch { /* localStorage unavailable (privacy mode) */ }
    return 'bys';
  };

  const [activeProduct, setActiveProduct] = useState<'bys' | 'bd001'>(getActiveProduct);

  // Sync URL params with localStorage when product changes
  const handleSwitch = (product: 'bys' | 'bd001') => {
    setActiveProduct(product);
    setSearchParams({ product });
    try { localStorage.setItem('activeProduct', product); } catch { /* ignore */ }
    // Scroll to top after switch
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Listen for URL changes
  useEffect(() => {
    const urlProduct = searchParams.get('product');
    if (urlProduct === 'bys' || urlProduct === 'bd001') {
      setActiveProduct(urlProduct);
    }
  }, [searchParams]);

  return (
    <div>
      <ProductHeroSection activeProduct={activeProduct} onSwitch={handleSwitch} />
      <PackageEntrySection activeProduct={activeProduct} />
      <ComparisonSection activeProduct={activeProduct} onSwitch={handleSwitch} />
      <ExperienceMethodSection onSelect={setSelectedMethod} selected={selectedMethod} />
    </div>
  );
}
