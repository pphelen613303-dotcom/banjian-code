import AboutHeroSection from '@/sections/about/AboutHeroSection';
import CoCreationHero from '@/sections/about/CoCreationHero';
import ProductionLayer from '@/sections/about/ProductionLayer';
import RegenerationLayer from '@/sections/about/RegenerationLayer';
import CultureLayer from '@/sections/about/CultureLayer';
import EvidenceCTA from '@/sections/about/EvidenceCTA';
import RootQuestionSection from '@/sections/about/RootQuestionSection';
import CharacterProfilesSection from '@/sections/about/CharacterProfilesSection';
import VisionSection from '@/sections/about/VisionSection';

export default function About() {
  return (
    <>
      <AboutHeroSection />
      <CoCreationHero />
      <ProductionLayer />
      <RegenerationLayer />
      <CultureLayer />
      <EvidenceCTA />
      <RootQuestionSection />
      <CharacterProfilesSection />
      <VisionSection />
    </>
  );
}
