import { useState, useCallback } from 'react';
import gsap from 'gsap';
import OriginHeroSection from '@/sections/origin/OriginHeroSection';
import ProductArchiveSection from '@/sections/origin/ProductArchiveSection';
import TimelineSection from '@/sections/origin/TimelineSection';
import ValueFlowSection from '@/sections/origin/ValueFlowSection';
import CoCreationConfirmSection from '@/sections/origin/CoCreationConfirmSection';
import OriginBottomCTA from '@/sections/origin/OriginBottomCTA';
import ProductQuickSwitch from '@/sections/origin/ProductQuickSwitch';

/**
 * Determine initial active product from localStorage (safe)
 */
function getInitialProduct(): 'bys' | 'bd001' {
  try {
    const stored = localStorage.getItem('originActiveProduct');
    if (stored === 'bys' || stored === 'bd001') return stored;
  } catch { /* ignore */ }
  return 'bys';
}

export default function Origin() {
  const [activeProduct, setActiveProduct] = useState<'bys' | 'bd001'>(getInitialProduct);

  const handleSwitch = useCallback((product: 'bys' | 'bd001') => {
    if (product === activeProduct) return;

    // Smooth fade out → switch → fade in (both archive and timeline)
    const targets = [
      document.getElementById('origin-archive'),
      document.getElementById('origin-timeline'),
    ].filter(Boolean);

    if (targets.length > 0) {
      gsap.to(targets, {
        opacity: 0, y: 15, duration: 0.25, ease: 'power2.in',
        onComplete: () => {
          setActiveProduct(product);
          try { localStorage.setItem('originActiveProduct', product); } catch { /* ignore */ }
          requestAnimationFrame(() => {
            gsap.fromTo(targets, { opacity: 0, y: -15 }, {
              opacity: 1, y: 0, duration: 0.4, ease: 'power2.out',
            });
          });
        },
      });
    } else {
      setActiveProduct(product);
      try { localStorage.setItem('originActiveProduct', product); } catch { /* ignore */ }
    }
  }, [activeProduct]);

  return (
    <>
      <OriginHeroSection />
      <ProductArchiveSection activeProduct={activeProduct} onSwitch={handleSwitch} />
      <TimelineSection activeProduct={activeProduct} />
      <ValueFlowSection />
      <CoCreationConfirmSection />
      <OriginBottomCTA />
      <ProductQuickSwitch activeProduct={activeProduct} onSwitch={handleSwitch} />
    </>
  );
}
